import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../api/client';
import { useNotifications } from '../../context/NotificationContext';
import {
  Stethoscope,
  HeartPulse,
  Pill,
  FlaskConical,
  Plus,
  Trash2,
  CheckCircle,
  AlertTriangle,
  User,
  Clock,
  ArrowRight
} from 'lucide-react';

export default function ConsultationRoom() {
  const { showToast } = useNotifications();
  const navigate = useNavigate();

  const [queueTokens, setQueueTokens] = useState([]);
  const [selectedToken, setSelectedToken] = useState(null);
  const [medicines, setMedicines] = useState([]);
  const [labTests, setLabTests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // EMR Form State
  const [symptoms, setSymptoms] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [bloodPressure, setBloodPressure] = useState('120/80');
  const [heartRate, setHeartRate] = useState('75');
  const [temperature, setTemperature] = useState('98.6');
  const [weight, setWeight] = useState('70');
  const [doctorNotes, setDoctorNotes] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  const [generalAdvice, setGeneralAdvice] = useState('');

  // Prescription Items Array
  const [prescriptionItems, setPrescriptionItems] = useState([
    {
      medicineId: '',
      medicineName: '',
      dosage: '1 tablet',
      frequency: '1-0-1 (Twice daily)',
      durationDays: 5,
      quantity: 10,
      instructions: 'After food with water'
    }
  ]);

  // Selected Lab Tests to Order
  const [selectedLabTestIds, setSelectedLabTestIds] = useState([]);

  useEffect(() => {
    async function loadData() {
      try {
        const [qRes, medRes, labRes] = await Promise.all([
          api.get('/queue/live'),
          api.get('/pharmacy/medicines'),
          api.get('/lab/tests')
        ]);

        if (qRes.data.success) {
          const toks = qRes.data.data.tokens || [];
          setQueueTokens(toks);
          // Auto select currently serving or first waiting token
          const current = qRes.data.data.currentlyServing || toks.find(t => t.status === 'waiting') || toks[0];
          if (current) {
            setSelectedToken(current);
            if (current.appointment?.reason) {
              setSymptoms(current.appointment.reason);
            }
          }
        }

        if (medRes.data.success) setMedicines(medRes.data.data);
        if (labRes.data.success) setLabTests(labRes.data.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const handleSelectToken = (tok) => {
    setSelectedToken(tok);
    if (tok.appointment?.reason) {
      setSymptoms(tok.appointment.reason);
    }
  };

  // Prescription Items Helper
  const handleAddItem = () => {
    setPrescriptionItems([
      ...prescriptionItems,
      {
        medicineId: '',
        medicineName: '',
        dosage: '1 tablet',
        frequency: '1-0-1 (Twice daily)',
        durationDays: 5,
        quantity: 10,
        instructions: 'After meals'
      }
    ]);
  };

  const handleRemoveItem = (index) => {
    setPrescriptionItems(prescriptionItems.filter((_, i) => i !== index));
  };

  const handleItemChange = (index, field, value) => {
    const updated = [...prescriptionItems];
    updated[index][field] = value;

    if (field === 'medicineId' && value) {
      const med = medicines.find(m => m.id === parseInt(value, 10));
      if (med) {
        updated[index].medicineName = `${med.name} (${med.strength || ''})`;
      }
    }

    setPrescriptionItems(updated);
  };

  const toggleLabTest = (testId) => {
    if (selectedLabTestIds.includes(testId)) {
      setSelectedLabTestIds(selectedLabTestIds.filter(id => id !== testId));
    } else {
      setSelectedLabTestIds([...selectedLabTestIds, testId]);
    }
  };

  const handleFinalizeConsultation = async (e) => {
    e.preventDefault();
    if (!selectedToken) {
      showToast('Please select a patient to consult.', 'error');
      return;
    }

    if (!diagnosis || !symptoms) {
      showToast('Symptoms and Diagnosis are required to create an EMR record.', 'error');
      return;
    }

    // Filter valid prescription items
    const validPrescriptions = prescriptionItems.filter(p => p.medicineName.trim() !== '');

    try {
      setSaving(true);

      // 1. Submit Medical Record & Prescription
      const res = await api.post('/records', {
        appointmentId: selectedToken.appointmentId,
        patientId: selectedToken.patientId,
        symptoms,
        diagnosis,
        bloodPressure,
        heartRate: heartRate ? parseInt(heartRate, 10) : null,
        temperature: temperature ? parseFloat(temperature) : null,
        weight: weight ? parseFloat(weight) : null,
        doctorNotes,
        followUpDate: followUpDate || null,
        generalAdvice,
        prescriptionItems: validPrescriptions
      });

      // 2. Order selected Lab Tests
      if (selectedLabTestIds.length > 0) {
        for (const testId of selectedLabTestIds) {
          await api.post('/lab/order', {
            testId,
            patientId: selectedToken.patientId,
            appointmentId: selectedToken.appointmentId,
            technicianNotes: `Ordered during OPD consultation for: ${diagnosis}`
          });
        }
      }

      // 3. Mark Queue Token as completed
      await api.put(`/queue/${selectedToken.id}/status`, { status: 'completed' });

      showToast(`Consultation for ${selectedToken.patient?.user?.name} finalized successfully!`);
      navigate('/doctor/queue');
    } catch (err) {
      showToast(err.response?.data?.message || 'Failed to finalize consultation', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="page-body" style={{ textAlign: 'center', padding: '3rem' }}>
        <p style={{ color: 'var(--text-muted)' }}>Loading consultation room...</p>
      </div>
    );
  }

  const patient = selectedToken?.patient;

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Clinical Consultation Room</h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            Examine patient, record vital signs, formulate diagnosis, write digital prescriptions, and order diagnostics.
          </p>
        </div>
      </div>

      {/* Select Patient From Today's Queue */}
      <div className="card" style={{ marginBottom: '1.5rem', padding: '1rem 1.25rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
          <span style={{ fontWeight: '700', fontSize: '0.85rem', color: 'var(--navy-dark)' }}>
            Select Active Patient:
          </span>
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', flex: 1 }}>
            {queueTokens.map((tok) => (
              <button
                key={tok.id}
                type="button"
                onClick={() => handleSelectToken(tok)}
                className="btn btn-sm"
                style={{
                  backgroundColor: selectedToken?.id === tok.id ? 'var(--primary)' : 'var(--bg-subtle)',
                  color: selectedToken?.id === tok.id ? 'white' : 'var(--text-primary)',
                  fontWeight: selectedToken?.id === tok.id ? '700' : '500',
                  border: selectedToken?.id === tok.id ? '1px solid var(--primary)' : '1px solid var(--border-color)'
                }}
              >
                #{tok.tokenNumber}: {tok.patient?.user?.name} ({tok.status})
              </button>
            ))}
          </div>
        </div>
      </div>

      {selectedToken && (
        <form onSubmit={handleFinalizeConsultation}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.5rem', alignItems: 'start' }}>
            {/* Left Column: Patient Profile & Vitals */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {/* Patient EHR Summary Card */}
              <div className="card" style={{ borderLeft: '4px solid var(--primary)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                  <div>
                    <h3 style={{ fontSize: '1.25rem', color: 'var(--navy-dark)' }}>{patient?.user?.name}</h3>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                      Code: <strong>{patient?.patientCode}</strong> • Gender: <strong>{patient?.gender}</strong> • DOB: <strong>{patient?.dob || 'N/A'}</strong>
                    </div>
                  </div>
                  <span className="badge badge-primary">
                    Token #{selectedToken.tokenNumber}
                  </span>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px', fontSize: '0.85rem', backgroundColor: 'var(--bg-subtle)', padding: '10px', borderRadius: '8px', marginBottom: '10px' }}>
                  <div>Blood Group: <strong>{patient?.bloodGroup || 'Unknown'}</strong></div>
                  <div>Phone: <strong>{patient?.user?.phone || 'N/A'}</strong></div>
                  <div>Insurance: <strong>{patient?.insuranceProvider || 'None'}</strong></div>
                  <div>Policy: <strong>{patient?.insurancePolicyNumber || 'N/A'}</strong></div>
                </div>

                {patient?.allergies && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.8rem', color: '#991b1b', backgroundColor: '#fee2e2', padding: '6px 10px', borderRadius: '6px', marginBottom: '6px' }}>
                    <AlertTriangle size={14} /> <strong>Allergies:</strong> {patient.allergies}
                  </div>
                )}

                {patient?.chronicConditions && (
                  <div style={{ fontSize: '0.8rem', color: '#92400e', backgroundColor: '#fef3c7', padding: '6px 10px', borderRadius: '6px' }}>
                    <strong>Chronic Conditions:</strong> {patient.chronicConditions}
                  </div>
                )}
              </div>

              {/* Recorded Vital Signs */}
              <div className="card">
                <h4 style={{ fontSize: '1rem', color: 'var(--navy-dark)', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <HeartPulse size={18} style={{ color: 'var(--primary)' }} /> Vital Signs Triage
                </h4>

                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Blood Pressure (mmHg)</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="120/80"
                      value={bloodPressure}
                      onChange={(e) => setBloodPressure(e.target.value)}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Heart Rate (bpm)</label>
                    <input
                      type="number"
                      className="form-control"
                      placeholder="72"
                      value={heartRate}
                      onChange={(e) => setHeartRate(e.target.value)}
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Temperature (°F)</label>
                    <input
                      type="number"
                      step="0.1"
                      className="form-control"
                      placeholder="98.6"
                      value={temperature}
                      onChange={(e) => setTemperature(e.target.value)}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Weight (kg)</label>
                    <input
                      type="number"
                      step="0.5"
                      className="form-control"
                      placeholder="70"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Order Lab Tests */}
              <div className="card">
                <h4 style={{ fontSize: '1rem', color: 'var(--navy-dark)', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <FlaskConical size={18} style={{ color: '#0ea5e9' }} /> Order Diagnostic Investigations
                </h4>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>
                  Select required lab tests; fees will be appended to the patient invoice automatically:
                </p>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '8px' }}>
                  {labTests.map((t) => {
                    const isChecked = selectedLabTestIds.includes(t.id);
                    return (
                      <label
                        key={t.id}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '8px',
                          padding: '8px 10px',
                          border: isChecked ? '1px solid var(--primary)' : '1px solid var(--border-color)',
                          backgroundColor: isChecked ? 'var(--primary-light)' : 'white',
                          borderRadius: '6px',
                          fontSize: '0.85rem',
                          cursor: 'pointer'
                        }}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleLabTest(t.id)}
                        />
                        <div>
                          <div style={{ fontWeight: isChecked ? '700' : '500' }}>{t.name}</div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>₹{parseFloat(t.standardFee).toFixed(0)}</div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Right Column: Symptoms, Diagnosis, Prescription Items */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {/* Clinical Assessment Form */}
              <div className="card">
                <h4 style={{ fontSize: '1.1rem', color: 'var(--navy-dark)', marginBottom: '1rem' }}>
                  Clinical Assessment & Diagnosis
                </h4>

                <div className="form-group">
                  <label className="form-label">Presenting Symptoms *</label>
                  <textarea
                    className="form-control"
                    placeholder="Patient complaints, duration, severity..."
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Definitive / Provisional Diagnosis *</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="e.g. Acute Bronchitis, Essential Hypertension Stage 1"
                    value={diagnosis}
                    onChange={(e) => setDiagnosis(e.target.value)}
                    required
                  />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Doctor's Clinical Notes</label>
                    <textarea
                      className="form-control"
                      placeholder="Examination findings, lifestyle recommendations..."
                      value={doctorNotes}
                      onChange={(e) => setDoctorNotes(e.target.value)}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Recommended Follow-up Date</label>
                    <input
                      type="date"
                      className="form-control"
                      value={followUpDate}
                      onChange={(e) => setFollowUpDate(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Digital E-Prescription Builder */}
              <div className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                  <h4 style={{ fontSize: '1.1rem', color: 'var(--navy-dark)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <Pill size={18} style={{ color: 'var(--primary)' }} /> Digital Prescription (Rx)
                  </h4>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="btn btn-secondary btn-sm"
                  >
                    <Plus size={14} /> Add Medicine
                  </button>
                </div>

                {prescriptionItems.map((item, idx) => (
                  <div
                    key={idx}
                    style={{
                      backgroundColor: 'var(--bg-subtle)',
                      border: '1px solid var(--border-color)',
                      borderRadius: '8px',
                      padding: '12px',
                      marginBottom: '10px'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                      <span style={{ fontSize: '0.8rem', fontWeight: '700', color: 'var(--primary)' }}>
                        Medicine #{idx + 1}
                      </span>
                      {prescriptionItems.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer' }}
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                    </div>

                    <div className="form-row" style={{ marginBottom: '8px' }}>
                      <div className="form-group" style={{ marginBottom: 0 }}>
                        <label className="form-label" style={{ fontSize: '0.75rem' }}>Select From Pharmacy</label>
                        <select
                          className="form-control"
                          value={item.medicineId}
                          onChange={(e) => handleItemChange(idx, 'medicineId', e.target.value)}
                        >
                          <option value="">-- Choose Catalog Medicine or Type Below --</option>
                          {medicines.map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.name} ({m.dosageForm} - ₹{parseFloat(m.unitPrice).toFixed(1)})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="form-group" style={{ marginBottom: 0 }}>
                        <label className="form-label" style={{ fontSize: '0.75rem' }}>Medicine Name / Salt</label>
                        <input
                          type="text"
                          className="form-control"
                          placeholder="e.g. Paracetamol 650mg"
                          value={item.medicineName}
                          onChange={(e) => handleItemChange(idx, 'medicineName', e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(110px, 1fr))', gap: '8px' }}>
                      <div>
                        <label style={{ fontSize: '0.75rem', fontWeight: '600' }}>Dosage</label>
                        <input
                          type="text"
                          className="form-control"
                          style={{ padding: '6px' }}
                          placeholder="1 tab"
                          value={item.dosage}
                          onChange={(e) => handleItemChange(idx, 'dosage', e.target.value)}
                        />
                      </div>
                      <div>
                        <label style={{ fontSize: '0.75rem', fontWeight: '600' }}>Frequency</label>
                        <input
                          type="text"
                          className="form-control"
                          style={{ padding: '6px' }}
                          placeholder="1-0-1"
                          value={item.frequency}
                          onChange={(e) => handleItemChange(idx, 'frequency', e.target.value)}
                        />
                      </div>
                      <div>
                        <label style={{ fontSize: '0.75rem', fontWeight: '600' }}>Days</label>
                        <input
                          type="number"
                          className="form-control"
                          style={{ padding: '6px' }}
                          value={item.durationDays}
                          onChange={(e) => handleItemChange(idx, 'durationDays', e.target.value)}
                        />
                      </div>
                      <div>
                        <label style={{ fontSize: '0.75rem', fontWeight: '600' }}>Quantity</label>
                        <input
                          type="number"
                          className="form-control"
                          style={{ padding: '6px' }}
                          value={item.quantity}
                          onChange={(e) => handleItemChange(idx, 'quantity', e.target.value)}
                        />
                      </div>
                    </div>

                    <div style={{ marginTop: '8px' }}>
                      <input
                        type="text"
                        className="form-control"
                        style={{ padding: '6px 8px', fontSize: '0.8rem' }}
                        placeholder="Instructions (e.g. After food with lukewarm water)"
                        value={item.instructions}
                        onChange={(e) => handleItemChange(idx, 'instructions', e.target.value)}
                      />
                    </div>
                  </div>
                ))}

                <div className="form-group" style={{ marginTop: '1rem', marginBottom: 0 }}>
                  <label className="form-label">General Advice for Patient</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Dietary precautions, hydration advice..."
                    value={generalAdvice}
                    onChange={(e) => setGeneralAdvice(e.target.value)}
                  />
                </div>
              </div>

              {/* Submit Consultation Button */}
              <button
                type="submit"
                className="btn btn-primary btn-lg"
                style={{ padding: '1rem', width: '100%', fontSize: '1.05rem', backgroundColor: '#059669', borderColor: '#047857' }}
                disabled={saving}
              >
                <CheckCircle size={22} />
                <span>{saving ? 'Finalizing EMR & Prescriptions...' : 'Finalize Consultation & Complete Visit'}</span>
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}
