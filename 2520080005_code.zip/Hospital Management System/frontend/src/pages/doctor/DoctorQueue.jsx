import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api/client';
import StatusBadge from '../../components/StatusBadge';
import { useNotifications } from '../../context/NotificationContext';
import {
  Clock,
  Play,
  CheckCircle,
  SkipForward,
  RefreshCw,
  User,
  Stethoscope,
  Phone
} from 'lucide-react';

export default function DoctorQueue() {
  const { showToast } = useNotifications();
  const [queueData, setQueueData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [callingNext, setCallingNext] = useState(false);

  const fetchQueue = async () => {
    try {
      const res = await api.get('/queue/live');
      if (res.data.success) {
        setQueueData(res.data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQueue();
    const interval = setInterval(fetchQueue, 15000); // 15s refresh
    return () => clearInterval(interval);
  }, []);

  const handleCallNext = async () => {
    try {
      setCallingNext(true);
      const res = await api.post('/queue/call-next', {});
      if (res.data.success) {
        if (res.data.data) {
          showToast(`Now serving Token #${res.data.data.tokenNumber} (${res.data.data.patient?.user?.name})!`);
        } else {
          showToast(res.data.message || 'No more waiting patients.', 'warning');
        }
        fetchQueue();
      }
    } catch (e) {
      showToast(e.response?.data?.message || 'Failed to call next patient', 'error');
    } finally {
      setCallingNext(false);
    }
  };

  const handleUpdateStatus = async (tokenId, status) => {
    try {
      const res = await api.put(`/queue/${tokenId}/status`, { status });
      if (res.data.success) {
        showToast(`Token status updated to ${status}`);
        fetchQueue();
      }
    } catch (e) {
      showToast('Status update failed', 'error');
    }
  };

  const tokens = queueData?.tokens || [];
  const serving = queueData?.currentlyServing;

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Outpatient Department (OPD) Queue Control</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Manage live consultation queues, call next patients, and update token statuses.</p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button onClick={fetchQueue} className="btn btn-secondary btn-sm">
            <RefreshCw size={16} />
            <span>Refresh</span>
          </button>
          <button
            onClick={handleCallNext}
            className="btn btn-primary"
            style={{ backgroundColor: '#10b981', borderColor: '#059669', padding: '0.65rem 1.5rem', fontSize: '1rem' }}
            disabled={callingNext}
          >
            <Play size={18} />
            <span>{callingNext ? 'Calling Patient...' : '📢 Call Next Patient'}</span>
          </button>
        </div>
      </div>

      {/* Serving Now Spotlight */}
      <div
        className="card"
        style={{
          marginBottom: '2rem',
          backgroundColor: serving ? '#f0fdf4' : 'white',
          borderColor: serving ? '#bbf7d0' : 'var(--border-color)',
          borderLeft: `6px solid ${serving ? '#10b981' : '#94a3b8'}`
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <span className="badge" style={{ backgroundColor: serving ? '#dcfce7' : '#f1f5f9', color: serving ? '#15803d' : '#64748b', marginBottom: '6px' }}>
              {serving ? 'Now in Consultation Room' : 'Room is Idle'}
            </span>
            {serving ? (
              <>
                <h2 style={{ fontSize: '1.6rem', color: '#166534', margin: '4px 0' }}>
                  Token #{serving.tokenNumber}: {serving.patient?.user?.name}
                </h2>
                <p style={{ color: '#15803d', fontSize: '0.9rem' }}>
                  Phone: {serving.patient?.user?.phone || 'N/A'} • Reason: <strong>{serving.appointment?.reason || 'Consultation'}</strong>
                </p>
              </>
            ) : (
              <>
                <h3 style={{ fontSize: '1.3rem', color: 'var(--navy-dark)', margin: '4px 0' }}>No Patient Currently Serving</h3>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
                  Click <strong>"Call Next Patient"</strong> to notify the next waiting patient in line via SMS and call them to your room.
                </p>
              </>
            )}
          </div>

          {serving && (
            <div style={{ display: 'flex', gap: '0.75rem' }}>
              <Link to="/doctor/consultation" className="btn btn-primary">
                <Stethoscope size={18} />
                <span>Open EMR & Prescribe</span>
              </Link>
              <button
                onClick={() => handleUpdateStatus(serving.id, 'completed')}
                className="btn btn-secondary"
              >
                <CheckCircle size={16} /> Mark Done
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Queue Token List */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="card-header" style={{ padding: '1.25rem 1.5rem', margin: 0, display: 'flex', justifyContent: 'space-between' }}>
          <h3 className="card-title">Today's Token Roster ({tokens.length} Total)</h3>
          <div style={{ display: 'flex', gap: '1rem', fontSize: '0.85rem' }}>
            <span>Waiting: <strong>{queueData?.waitingCount || 0}</strong></span>
            <span>Completed: <strong>{queueData?.completedCount || 0}</strong></span>
          </div>
        </div>

        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Token #</th>
                <th>Patient Details</th>
                <th>Estimated Time</th>
                <th>Appointment #</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading queue roster...
                  </td>
                </tr>
              ) : tokens.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
                    No tokens booked for your OPD today.
                  </td>
                </tr>
              ) : (
                tokens.map((tok) => (
                  <tr
                    key={tok.id}
                    style={{
                      backgroundColor: tok.status === 'serving' ? '#f0fdf4' : 'transparent',
                      fontWeight: tok.status === 'serving' ? '600' : 'normal'
                    }}
                  >
                    <td>
                      <span
                        style={{
                          fontSize: '1.2rem',
                          fontWeight: '800',
                          color: tok.status === 'serving' ? '#059669' : 'var(--navy-dark)',
                          fontFamily: 'Outfit'
                        }}
                      >
                        #{tok.tokenNumber}
                      </span>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{tok.tokenCode}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: '600', color: 'var(--navy-dark)' }}>{tok.patient?.user?.name}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <Phone size={12} /> {tok.patient?.user?.phone || 'No phone'}
                      </div>
                    </td>
                    <td>{tok.estimatedTime || tok.appointment?.timeSlot || '-'}</td>
                    <td>{tok.appointment?.appointmentNumber || '-'}</td>
                    <td>
                      <StatusBadge status={tok.status} />
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'flex', gap: '6px', justifyContent: 'flex-end' }}>
                        {tok.status === 'waiting' && (
                          <button
                            onClick={() => handleUpdateStatus(tok.id, 'serving')}
                            className="btn btn-secondary btn-sm"
                            title="Call to room"
                          >
                            <Play size={14} /> Call
                          </button>
                        )}
                        {tok.status === 'serving' && (
                          <Link to="/doctor/consultation" className="btn btn-primary btn-sm">
                            <Stethoscope size={14} /> Consult
                          </Link>
                        )}
                        {tok.status !== 'completed' && tok.status !== 'cancelled' && (
                          <button
                            onClick={() => handleUpdateStatus(tok.id, 'skipped')}
                            className="btn btn-secondary btn-sm"
                            style={{ color: '#f59e0b' }}
                            title="Skip patient"
                          >
                            <SkipForward size={14} /> Skip
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
