import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import api from '../../api/client';
import StatCard from '../../components/StatCard';
import StatusBadge from '../../components/StatusBadge';
import { formatDoctorName } from '../../utils/formatters';
import {
  Calendar,
  Clock,
  Users,
  CheckCircle,
  Stethoscope,
  ArrowRight,
  PlayCircle
} from 'lucide-react';

export default function DoctorDashboard() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [queueData, setQueueData] = useState(null);
  const [loading, setLoading] = useState(true);

  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    async function loadDoctorData() {
      try {
        const [aptRes, queueRes] = await Promise.all([
          api.get(`/appointments?date=${todayStr}`),
          api.get('/queue/live')
        ]);

        if (aptRes.data.success) setAppointments(aptRes.data.data);
        if (queueRes.data.success) setQueueData(queueRes.data.data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadDoctorData();
  }, [todayStr]);

  const servingToken = queueData?.currentlyServing;
  const waitingCount = queueData?.waitingCount || 0;
  const completedCount = queueData?.completedCount || 0;

  return (
    <div className="page-body">
      {/* Doctor Header Banner */}
      <div
        style={{
          background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
          borderRadius: 'var(--radius-lg)',
          padding: '2rem',
          color: 'white',
          marginBottom: '2rem',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '1.5rem'
        }}
      >
        <div>
          <span className="badge" style={{ backgroundColor: '#0d9488', color: 'white', marginBottom: '8px' }}>
            Clinical Console • {user.doctorProfile?.department}
          </span>
          <h1 style={{ color: 'white', fontSize: '1.85rem', margin: '4px 0 8px' }}>
            Welcome, {formatDoctorName(user?.name || 'Doctor')} 🩺
          </h1>
          <p style={{ color: '#94a3b8', fontSize: '0.95rem' }}>
            Room: <strong>{user.doctorProfile?.roomNumber || 'OPD-101'}</strong> • Specialization: <strong>{user.doctorProfile?.specialization}</strong>
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <Link to="/doctor/queue" className="btn btn-primary" style={{ backgroundColor: 'var(--primary)' }}>
            <Clock size={18} />
            <span>Manage OPD Queue</span>
          </Link>
          <Link to="/doctor/consultation" className="btn btn-secondary" style={{ backgroundColor: 'white', color: 'var(--navy-dark)' }}>
            <Stethoscope size={18} />
            <span>Open Consultation Room</span>
          </Link>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="stat-grid">
        <StatCard
          label="Today's Appointments"
          value={appointments.length}
          icon={Calendar}
          color="#0d9488"
          subtext="Outpatient schedule"
        />
        <StatCard
          label="Currently Serving"
          value={servingToken ? `#${servingToken.tokenNumber}` : 'Idle'}
          icon={PlayCircle}
          color="#3b82f6"
          subtext={servingToken ? servingToken.patient?.user?.name : 'Ready for next patient'}
        />
        <StatCard
          label="Waiting in Queue"
          value={waitingCount}
          icon={Clock}
          color="#f59e0b"
          subtext="In waiting lounge"
        />
        <StatCard
          label="Completed Today"
          value={completedCount}
          icon={CheckCircle}
          color="#10b981"
          subtext="Consultations closed"
        />
      </div>

      {/* Currently Serving Banner / Action */}
      {servingToken ? (
        <div className="card" style={{ marginBottom: '2rem', borderLeft: '5px solid #10b981', backgroundColor: '#f0fdf4' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <span className="badge badge-success" style={{ marginBottom: '4px' }}>Now in Room</span>
              <h3 style={{ fontSize: '1.3rem', color: '#166534' }}>
                Token #{servingToken.tokenNumber}: {servingToken.patient?.user?.name}
              </h3>
              <p style={{ fontSize: '0.85rem', color: '#15803d' }}>
                Contact: {servingToken.patient?.user?.phone} • Reason: {servingToken.appointment?.reason || 'General checkup'}
              </p>
            </div>
            <Link to="/doctor/consultation" className="btn btn-success btn-lg">
              <Stethoscope size={20} />
              <span>Proceed to Consultation Room</span>
            </Link>
          </div>
        </div>
      ) : (
        <div className="card" style={{ marginBottom: '2rem', borderLeft: '5px solid #0284c7' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <h3 style={{ fontSize: '1.2rem' }}>Consultation Room is Idle</h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                {waitingCount > 0 ? `There are ${waitingCount} patients waiting in the queue.` : 'No patients currently waiting in queue.'}
              </p>
            </div>
            <Link to="/doctor/queue" className="btn btn-primary">
              <Clock size={16} />
              <span>Call Next Patient</span>
            </Link>
          </div>
        </div>
      )}

      {/* Today's Appointments Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="card-header" style={{ padding: '1.25rem 1.5rem', margin: 0 }}>
          <h3 className="card-title">Today's Appointment Schedule ({todayStr})</h3>
          <Link to="/doctor/appointments" style={{ fontSize: '0.85rem', color: 'var(--primary)', fontWeight: '600' }}>
            View Full Calendar
          </Link>
        </div>

        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Time Slot</th>
                <th>Patient Name</th>
                <th>Contact</th>
                <th>OPD Token</th>
                <th>Status</th>
                <th>Reason</th>
                <th style={{ textAlign: 'right' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading schedule...
                  </td>
                </tr>
              ) : appointments.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                    No appointments booked for today.
                  </td>
                </tr>
              ) : (
                appointments.map((apt) => (
                  <tr key={apt.id}>
                    <td>
                      <strong>{apt.timeSlot}</strong>
                    </td>
                    <td>
                      <div style={{ fontWeight: '600' }}>{apt.patient?.user?.name}</div>
                    </td>
                    <td>{apt.patient?.user?.phone || 'N/A'}</td>
                    <td>
                      {apt.queueToken ? (
                        <span className="badge badge-info">
                          #{apt.queueToken.tokenNumber}
                        </span>
                      ) : '-'}
                    </td>
                    <td>
                      <StatusBadge status={apt.status} />
                    </td>
                    <td style={{ maxWidth: '240px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {apt.reason}
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <Link to="/doctor/consultation" className="btn btn-secondary btn-sm">
                        <Stethoscope size={14} /> Consult
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
