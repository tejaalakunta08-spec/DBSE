import React, { useState, useEffect } from 'react';
import api from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import {
  Calendar,
  Clock,
  Save,
  CheckCircle,
  Settings
} from 'lucide-react';

export default function DoctorSchedule() {
  const { user } = useAuth();
  const { showToast } = useNotifications();

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    async function loadDoctorSchedule() {
      if (!user?.doctorProfile?.id) {
        setLoading(false);
        return;
      }
      try {
        const res = await api.get(`/doctors/${user.doctorProfile.id}`);
        if (res.data.success && res.data.data.schedules) {
          const existing = res.data.data.schedules;
          // Merge with default 7 days
          const fullWeek = daysOfWeek.map(day => {
            const found = existing.find(s => s.dayOfWeek === day);
            if (found) return found;
            return {
              dayOfWeek: day,
              startTime: '09:00:00',
              endTime: '17:00:00',
              slotDurationMinutes: 20,
              maxPatients: 25,
              isAvailable: day !== 'Sunday'
            };
          });
          setSchedules(fullWeek);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadDoctorSchedule();
  }, [user]);

  const handleChange = (index, field, value) => {
    const updated = [...schedules];
    updated[index][field] = value;
    setSchedules(updated);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const res = await api.put(`/doctors/${user.doctorProfile?.id}/schedule`, {
        schedules
      });
      if (res.data.success) {
        showToast('OPD Schedule updated successfully!');
      }
    } catch (err) {
      showToast('Failed to update schedule', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="page-body" style={{ textAlign: 'center', padding: '3rem' }}>
        <p style={{ color: 'var(--text-muted)' }}>Loading doctor schedule...</p>
      </div>
    );
  }

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Outpatient Department (OPD) Schedule</h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            Configure your active weekly consultation days, clinic operating hours, and patient slot intervals.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="btn btn-primary"
          disabled={saving}
        >
          <Save size={18} />
          <span>{saving ? 'Saving...' : 'Save Schedule'}</span>
        </button>
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Day of Week</th>
                <th>OPD Status</th>
                <th>Shift Start Time</th>
                <th>Shift End Time</th>
                <th>Slot Duration (Mins)</th>
                <th>Daily Patient Quota</th>
              </tr>
            </thead>
            <tbody>
              {schedules.map((item, idx) => (
                <tr key={item.dayOfWeek} style={{ backgroundColor: item.isAvailable ? 'white' : '#f8fafc' }}>
                  <td>
                    <strong style={{ color: item.isAvailable ? 'var(--navy-dark)' : 'var(--text-muted)' }}>
                      {item.dayOfWeek}
                    </strong>
                  </td>
                  <td>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={item.isAvailable}
                        onChange={(e) => handleChange(idx, 'isAvailable', e.target.checked)}
                      />
                      <span style={{ fontSize: '0.85rem', fontWeight: item.isAvailable ? '700' : 'normal', color: item.isAvailable ? 'var(--primary)' : 'var(--text-muted)' }}>
                        {item.isAvailable ? 'Available' : 'Day Off'}
                      </span>
                    </label>
                  </td>
                  <td>
                    <input
                      type="time"
                      className="form-control"
                      style={{ padding: '6px', width: '130px' }}
                      disabled={!item.isAvailable}
                      value={item.startTime ? item.startTime.slice(0, 5) : '09:00'}
                      onChange={(e) => handleChange(idx, 'startTime', `${e.target.value}:00`)}
                    />
                  </td>
                  <td>
                    <input
                      type="time"
                      className="form-control"
                      style={{ padding: '6px', width: '130px' }}
                      disabled={!item.isAvailable}
                      value={item.endTime ? item.endTime.slice(0, 5) : '17:00'}
                      onChange={(e) => handleChange(idx, 'endTime', `${e.target.value}:00`)}
                    />
                  </td>
                  <td>
                    <select
                      className="form-control"
                      style={{ padding: '6px', width: '130px' }}
                      disabled={!item.isAvailable}
                      value={item.slotDurationMinutes}
                      onChange={(e) => handleChange(idx, 'slotDurationMinutes', parseInt(e.target.value, 10))}
                    >
                      <option value={15}>15 Minutes</option>
                      <option value={20}>20 Minutes</option>
                      <option value={30}>30 Minutes</option>
                      <option value={45}>45 Minutes</option>
                    </select>
                  </td>
                  <td>
                    <input
                      type="number"
                      className="form-control"
                      style={{ padding: '6px', width: '110px' }}
                      disabled={!item.isAvailable}
                      value={item.maxPatients}
                      onChange={(e) => handleChange(idx, 'maxPatients', parseInt(e.target.value, 10))}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
