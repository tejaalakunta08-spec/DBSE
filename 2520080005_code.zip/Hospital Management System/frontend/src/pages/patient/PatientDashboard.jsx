import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import api from '../../api/client';
import StatCard from '../../components/StatCard';
import StatusBadge from '../../components/StatusBadge';
import { formatDoctorName } from '../../utils/formatters';
import {
  Calendar,
  Clock,
  FileText,
  CreditCard,
  PlusCircle,
  Stethoscope,
  AlertCircle,
  ArrowRight
} from 'lucide-react';

export default function PatientDashboard() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [tokenStatus, setTokenStatus] = useState(null);
  const [bills, setBills] = useState([]);
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const promises = [
          api.get('/appointments').catch(err => ({ error: err })),
          api.get('/queue/my-status').catch(err => ({ error: err })),
          api.get('/billing').catch(err => ({ error: err })),
          user?.patientProfile?.id ? api.get(`/records/patient/${user.patientProfile.id}`).catch(err => ({ error: err })) : Promise.resolve({ data: { success: true, data: [] } })
        ];

        const [aptRes, queueRes, billRes, recordRes] = await Promise.all(promises);

        if (aptRes?.data?.success) setAppointments(aptRes.data.data);
        if (queueRes?.data?.success) setTokenStatus(queueRes.data.data);
        if (billRes?.data?.success) setBills(billRes.data.data.bills || []);
        if (recordRes?.data?.success) setRecords(recordRes.data.data || []);
      } catch (err) {
        console.error('Failed to load patient dashboard:', err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [user]);

  const upcomingApt = appointments.find(a => a.status === 'confirmed' || a.status === 'in_consultation');
  const unpaidBills = bills.filter(b => b.paymentStatus !== 'paid');

  if (loading) {
    return (
      <div style={{ padding: '3rem', textAlign: 'center' }}>
        <p style={{ color: 'var(--text-muted)' }}>Loading your patient profile & appointments...</p>
      </div>
    );
  }

  return (
    <div className="page-body">
      {/* Welcome Greeting Banner */}
      <div
        style={{
          background: 'linear-gradient(135deg, #0d9488 0%, #0284c7 100%)',
          borderRadius: 'var(--radius-lg)',
          padding: '2rem',
          color: 'white',
          marginBottom: '2rem',
          boxShadow: 'var(--shadow-md)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '1.5rem'
        }}
      >
        <div>
          <div style={{ fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '0.05em', opacity: 0.9 }}>
            Patient ID: {user?.patientProfile?.patientCode || 'PAT-0001'}
          </div>
          <h1 style={{ color: 'white', fontSize: '1.85rem', margin: '4px 0 8px' }}>
            Hello, {user?.name || 'Patient'} 👋
          </h1>
          <p style={{ opacity: 0.95, fontSize: '0.95rem' }}>
            Blood Group: <strong>{user?.patientProfile?.bloodGroup || 'N/A'}</strong> • Insurance: <strong>{user?.patientProfile?.insuranceProvider || 'Direct Cash'}</strong>
          </p>
        </div>

        <Link to="/patient/book" className="btn btn-secondary" style={{ backgroundColor: 'white', color: 'var(--primary)', fontWeight: '700' }}>
          <PlusCircle size={18} />
          <span>Book New Appointment</span>
        </Link>
      </div>

      {/* KPI Stats */}
      <div className="stat-grid">
        <StatCard
          label="Total Appointments"
          value={appointments.length}
          icon={Calendar}
          color="#0d9488"
          subtext="History & upcoming"
        />
        <StatCard
          label="Live OPD Token"
          value={tokenStatus?.myToken ? `#${tokenStatus.myToken.tokenNumber}` : 'None Today'}
          icon={Clock}
          color="#0284c7"
          subtext={tokenStatus?.myToken ? `Serving: #${tokenStatus.currentlyServingTokenNumber || '-'}` : 'No active queue'}
        />
        <StatCard
          label="Medical Records"
          value={records.length}
          icon={FileText}
          color="#8b5cf6"
          subtext="Digital EMR visits"
        />
        <StatCard
          label="Pending Invoices"
          value={unpaidBills.length}
          icon={CreditCard}
          color={unpaidBills.length > 0 ? '#ef4444' : '#10b981'}
          subtext={unpaidBills.length > 0 ? 'Requires settlement' : 'All bills settled'}
        />
      </div>

      {/* Active Queue Card if today */}
      {tokenStatus?.myToken && (
        <div className="card" style={{ marginBottom: '2rem', borderLeft: '5px solid #0284c7' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <span className="badge badge-info" style={{ marginBottom: '8px' }}>Today’s Live Token</span>
              <h3 style={{ fontSize: '1.3rem' }}>
                {formatDoctorName(tokenStatus.myToken.doctor?.user?.name)} ({tokenStatus.myToken.doctor?.department})
              </h3>
              <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                Your Token Number: <strong style={{ color: 'var(--navy-dark)' }}>#{tokenStatus.myToken.tokenNumber}</strong> ({tokenStatus.myToken.tokenCode})
                {tokenStatus.patientsAhead > 0 ? ` • ${tokenStatus.patientsAhead} patients ahead of you.` : ' • It is your turn! Please proceed to the room.'}
              </p>
            </div>
            <Link to="/patient/queue" className="btn btn-primary">
              <Clock size={16} />
              <span>Track Live Queue</span>
            </Link>
          </div>
        </div>
      )}

      {/* Upcoming Appointment & Recent Medical Records */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '1.5rem' }}>
        {/* Next Appointment */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Next Scheduled Visit</h3>
            <Link to="/patient/appointments" style={{ fontSize: '0.85rem', color: 'var(--primary)', fontWeight: '600' }}>
              View All
            </Link>
          </div>

          {upcomingApt ? (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '1rem' }}>
                <div style={{ width: '48px', height: '48px', borderRadius: '12px', backgroundColor: '#e0f2fe', color: '#0369a1', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Stethoscope size={24} />
                </div>
                <div>
                  <h4 style={{ fontSize: '1.1rem' }}>{formatDoctorName(upcomingApt.doctor?.user?.name)}</h4>
                  <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                    {upcomingApt.doctor?.specialization} • Room {upcomingApt.doctor?.roomNumber || 'OPD'}
                  </p>
                </div>
              </div>

              <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-md)', padding: '12px', display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
                <div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Date</span>
                  <div style={{ fontWeight: '700', fontSize: '0.9rem' }}>{upcomingApt.appointmentDate}</div>
                </div>
                <div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Time Slot</span>
                  <div style={{ fontWeight: '700', fontSize: '0.9rem' }}>{upcomingApt.timeSlot}</div>
                </div>
                <div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Status</span>
                  <div><StatusBadge status={upcomingApt.status} /></div>
                </div>
              </div>

              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                <strong>Reason:</strong> {upcomingApt.reason}
              </p>
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
              <Calendar size={36} style={{ margin: '0 auto 0.5rem', opacity: 0.5 }} />
              <p>No upcoming appointments scheduled.</p>
              <Link to="/patient/book" className="btn btn-secondary btn-sm" style={{ marginTop: '0.75rem' }}>
                Schedule Visit
              </Link>
            </div>
          )}
        </div>

        {/* Recent EMR Record */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Recent Clinical Records</h3>
            <Link to="/patient/records" style={{ fontSize: '0.85rem', color: 'var(--primary)', fontWeight: '600' }}>
              Full EMR
            </Link>
          </div>

          {records.length > 0 ? (
            <div>
              {records.slice(0, 2).map((rec) => (
                <div key={rec.id} style={{ padding: '10px 0', borderBottom: '1px solid #f1f5f9' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                    <span style={{ fontWeight: '700', fontSize: '0.95rem' }}>{rec.diagnosis}</span>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{rec.visitDate}</span>
                  </div>
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                    Doctor: {formatDoctorName(rec.doctor?.user?.name)}
                  </p>
                  <div style={{ display: 'flex', gap: '1rem', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    {rec.bloodPressure && <span>BP: <strong>{rec.bloodPressure}</strong></span>}
                    {rec.heartRate && <span>Pulse: <strong>{rec.heartRate} bpm</strong></span>}
                    {rec.prescription && <span style={{ color: 'var(--primary)', fontWeight: '600' }}>Rx Prescribed</span>}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
              <FileText size={36} style={{ margin: '0 auto 0.5rem', opacity: 0.5 }} />
              <p>No medical records on file yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
