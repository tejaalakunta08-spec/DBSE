import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../api/client';
import { useNotifications } from '../../context/NotificationContext';
import Modal from '../../components/Modal';
import { formatDoctorName } from '../../utils/formatters';
import {
  Calendar,
  Clock,
  User,
  Stethoscope,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Info
} from 'lucide-react';

export default function BookAppointment() {
  const { showToast } = useNotifications();
  const navigate = useNavigate();

  const [departments, setDepartments] = useState([]);
  const [selectedDept, setSelectedDept] = useState('All');
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  // Form states
  const todayStr = new Date().toISOString().split('T')[0];
  const [appointmentDate, setAppointmentDate] = useState(todayStr);
  const [slotsData, setSlotsData] = useState(null);
  const [selectedSlot, setSelectedSlot] = useState('');
  const [reason, setReason] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [notes, setNotes] = useState('');

  const [loadingDocs, setLoadingDocs] = useState(false);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [bookingSuccessModal, setBookingSuccessModal] = useState(null);

  // 1. Fetch departments
  useEffect(() => {
    async function loadDepts() {
      try {
        const res = await api.get('/doctors/departments');
        if (res.data.success) {
          setDepartments(res.data.data);
        }
      } catch (e) {
        console.error(e);
      }
    }
    loadDepts();
  }, []);

  // 2. Fetch doctors based on department
  useEffect(() => {
    async function loadDoctors() {
      setLoadingDocs(true);
      try {
        const url = selectedDept === 'All' ? '/doctors' : `/doctors?department=${encodeURIComponent(selectedDept)}`;
        const res = await api.get(url);
        if (res.data.success) {
          setDoctors(res.data.data);
          if (res.data.data.length > 0) {
            setSelectedDoctorId(res.data.data[0].id);
            setSelectedDoctor(res.data.data[0]);
          } else {
            setSelectedDoctorId('');
            setSelectedDoctor(null);
          }
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoadingDocs(false);
      }
    }
    loadDoctors();
  }, [selectedDept]);

  // 3. Update selected doctor object
  useEffect(() => {
    if (selectedDoctorId && doctors.length > 0) {
      const doc = doctors.find(d => d.id === parseInt(selectedDoctorId, 10));
      setSelectedDoctor(doc || null);
    }
  }, [selectedDoctorId, doctors]);

  // 4. Fetch slots when doctor and date change
  useEffect(() => {
    async function fetchSlots() {
      if (!selectedDoctorId || !appointmentDate) return;
      setLoadingSlots(true);
      setSelectedSlot('');
      try {
        const res = await api.get(`/doctors/${selectedDoctorId}/slots?date=${appointmentDate}`);
        if (res.data.success) {
          setSlotsData(res.data.data);
          // auto-select first available slot
          const firstAvailable = res.data.data.slots?.find(s => !s.isBooked);
          if (firstAvailable) {
            setSelectedSlot(firstAvailable.timeSlot);
          }
        }
      } catch (e) {
        console.error('Failed to fetch doctor slots:', e);
      } finally {
        setLoadingSlots(false);
      }
    }
    fetchSlots();
  }, [selectedDoctorId, appointmentDate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedDoctorId || !appointmentDate || !selectedSlot || !reason) {
      showToast('Please fill out all required appointment fields.', 'error');
      return;
    }

    try {
      setSubmitting(true);
      const res = await api.post('/appointments', {
        doctorId: selectedDoctorId,
        appointmentDate,
        timeSlot: selectedSlot,
        reason,
        symptoms,
        notes
      });

      if (res.data.success) {
        setBookingSuccessModal(res.data.data);
        showToast('Appointment and OPD Token confirmed!');
      }
    } catch (err) {
      showToast(err.response?.data?.message || 'Failed to book appointment', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="page-body">
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Schedule an OPD Appointment</h1>
        <p style={{ color: 'var(--text-secondary)' }}>
          Select a clinical specialty, choose an attending physician, and book an available time slot.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem', alignItems: 'start' }}>
        {/* Booking Form */}
        <div className="card" style={{ padding: '2rem' }}>
          <form onSubmit={handleSubmit}>
            {/* Department Filter */}
            <div className="form-group">
              <label className="form-label">Clinical Specialty / Department</label>
              <select
                className="form-control"
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
              >
                <option value="All">All Medical Departments</option>
                {departments.map((dept, idx) => (
                  <option key={idx} value={dept}>{dept}</option>
                ))}
              </select>
            </div>

            {/* Doctor Picker */}
            <div className="form-group">
              <label className="form-label">Select Specialist Physician *</label>
              {loadingDocs ? (
                <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Loading doctors...</div>
              ) : doctors.length === 0 ? (
                <div style={{ color: '#ef4444', fontSize: '0.85rem' }}>No doctors found for this specialty.</div>
              ) : (
                <select
                  className="form-control"
                  value={selectedDoctorId}
                  onChange={(e) => setSelectedDoctorId(e.target.value)}
                  required
                >
                  {doctors.map((d) => (
                    <option key={d.id} value={d.id}>
                      {formatDoctorName(d.user?.name)} - {d.department} (₹{parseFloat(d.consultationFee).toFixed(0)})
                    </option>
                  ))}
                </select>
              )}
            </div>

            {/* Date Picker */}
            <div className="form-group">
              <label className="form-label">Appointment Date *</label>
              <input
                type="date"
                className="form-control"
                min={todayStr}
                value={appointmentDate}
                onChange={(e) => setAppointmentDate(e.target.value)}
                required
              />
            </div>

            {/* Available Time Slots Grid */}
            <div className="form-group">
              <label className="form-label" style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Available Consultation Slots *</span>
                {slotsData?.isAvailable && (
                  <span style={{ fontSize: '0.75rem', color: 'var(--primary)', fontWeight: '600' }}>
                    {slotsData.dayOfWeek} Schedule
                  </span>
                )}
              </label>

              {loadingSlots ? (
                <div style={{ padding: '1rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                  Loading available OPD slots...
                </div>
              ) : slotsData && !slotsData.isAvailable ? (
                <div style={{ backgroundColor: '#fef3c7', color: '#92400e', padding: '10px', borderRadius: '8px', fontSize: '0.85rem' }}>
                  {slotsData.message}
                </div>
              ) : slotsData?.slots?.length > 0 ? (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(95px, 1fr))', gap: '8px', maxHeight: '180px', overflowY: 'auto', padding: '4px' }}>
                  {slotsData.slots.map((s, idx) => (
                    <button
                      key={idx}
                      type="button"
                      disabled={s.isBooked}
                      onClick={() => setSelectedSlot(s.timeSlot)}
                      style={{
                        padding: '8px 4px',
                        borderRadius: '6px',
                        border: selectedSlot === s.timeSlot ? '2px solid var(--primary)' : '1px solid var(--border-color)',
                        backgroundColor: s.isBooked ? '#f1f5f9' : (selectedSlot === s.timeSlot ? 'var(--primary-light)' : 'white'),
                        color: s.isBooked ? '#94a3b8' : (selectedSlot === s.timeSlot ? 'var(--primary)' : 'var(--text-primary)'),
                        fontSize: '0.8rem',
                        fontWeight: selectedSlot === s.timeSlot ? '700' : '500',
                        cursor: s.isBooked ? 'not-allowed' : 'pointer',
                        textAlign: 'center',
                        textDecoration: s.isBooked ? 'line-through' : 'none',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      {s.timeSlot}
                    </button>
                  ))}
                </div>
              ) : (
                <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Please select a date to view slots.</div>
              )}
            </div>

            {/* Clinical Reason & Symptoms */}
            <div className="form-group">
              <label className="form-label">Primary Reason for Visit *</label>
              <input
                type="text"
                className="form-control"
                placeholder="e.g. Chest discomfort, Persistent cough, Joint pain"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Symptoms & Notes for Doctor (Optional)</label>
              <textarea
                className="form-control"
                placeholder="Describe symptom duration, severity, medications you are currently taking..."
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary btn-lg"
              style={{ width: '100%', marginTop: '1rem' }}
              disabled={submitting || !selectedSlot || (slotsData && !slotsData.isAvailable)}
            >
              {submitting ? 'Confirming Appointment...' : 'Confirm Appointment & Issue Token'}
              <ArrowRight size={20} />
            </button>
          </form>
        </div>

        {/* Selected Doctor Summary Card */}
        {selectedDoctor && (
          <div className="card" style={{ padding: '2rem', borderTop: '4px solid var(--primary)' }}>
            <h3 style={{ fontSize: '1.2rem', marginBottom: '1rem' }}>Physician Overview</h3>

            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.25rem' }}>
              <div
                style={{
                  width: '60px',
                  height: '60px',
                  borderRadius: '50%',
                  backgroundColor: '#ccfbf1',
                  color: '#0f766e',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: '800',
                  fontSize: '1.4rem'
                }}
              >
                {selectedDoctor.user?.name?.split(' ')[1]?.charAt(0) || 'D'}
              </div>
              <div>
                <h4 style={{ fontSize: '1.15rem' }}>{formatDoctorName(selectedDoctor.user?.name)}</h4>
                <div style={{ display: 'flex', gap: '6px', alignItems: 'center', marginTop: '2px' }}>
                  <span className="badge badge-primary">{selectedDoctor.department}</span>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Room {selectedDoctor.roomNumber || 'OPD-101'}</span>
                </div>
              </div>
            </div>

            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: '1.25rem' }}>
              {selectedDoctor.bio || `${selectedDoctor.qualification} with ${selectedDoctor.experienceYears} years experience.`}
            </p>

            <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-md)', padding: '14px', marginBottom: '1.25rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', fontSize: '0.85rem' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Specialization:</span>
                <span style={{ fontWeight: '600' }}>{selectedDoctor.specialization}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', fontSize: '0.85rem' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Qualifications:</span>
                <span style={{ fontWeight: '600' }}>{selectedDoctor.qualification}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', paddingTop: '6px', borderTop: '1px solid #e2e8f0' }}>
                <span style={{ color: 'var(--navy-dark)', fontWeight: '700' }}>OPD Consultation Fee:</span>
                <span style={{ color: 'var(--primary)', fontWeight: '800', fontSize: '1.1rem' }}>₹{parseFloat(selectedDoctor.consultationFee).toFixed(0)}</span>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', fontSize: '0.8rem', color: 'var(--text-muted)', lineHeight: 1.4 }}>
              <Info size={16} style={{ flexShrink: 0, marginTop: '2px', color: 'var(--primary)' }} />
              <span>
                Booking confirmation instantly generates your daily OPD Queue Token and dispatches an SMS reminder.
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Booking Confirmation Dialog Modal */}
      {bookingSuccessModal && (
        <Modal
          isOpen={true}
          onClose={() => {
            setBookingSuccessModal(null);
            navigate('/patient/appointments');
          }}
          title="Appointment & Token Confirmed!"
        >
          <div style={{ textAlign: 'center', padding: '1rem 0' }}>
            <div
              style={{
                width: '64px',
                height: '64px',
                borderRadius: '50%',
                backgroundColor: '#d1fae5',
                color: '#059669',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '1rem'
              }}
            >
              <CheckCircle size={36} />
            </div>

            <h3 style={{ fontSize: '1.3rem', marginBottom: '0.5rem' }}>Appointment Successfully Booked</h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '1.5rem' }}>
              Your appointment has been registered in the hospital database. An SMS confirmation has been dispatched.
            </p>

            <div className="queue-ticket-card" style={{ textAlign: 'left', marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: '#94a3b8' }}>
                    OPD Queue Token
                  </div>
                  <div style={{ fontSize: '1.1rem', fontWeight: '700', color: 'white' }}>
                    Token Code: {bookingSuccessModal.queueToken?.tokenCode}
                  </div>
                </div>
                <div className="queue-token-number">
                  #{bookingSuccessModal.queueToken?.tokenNumber}
                </div>
              </div>
              <div style={{ marginTop: '1rem', paddingTop: '0.75rem', borderTop: '1px solid rgba(255,255,255,0.1)', fontSize: '0.85rem' }}>
                Appointment: <strong>{bookingSuccessModal.appointment?.appointmentNumber}</strong> | Date: <strong>{bookingSuccessModal.appointment?.appointmentDate} ({bookingSuccessModal.appointment?.timeSlot})</strong>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
              <button
                onClick={() => navigate('/patient/queue')}
                className="btn btn-secondary"
              >
                <Clock size={16} />
                <span>Track Live Queue</span>
              </button>
              <button
                onClick={() => navigate('/patient/appointments')}
                className="btn btn-primary"
              >
                <span>View My Appointments</span>
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
