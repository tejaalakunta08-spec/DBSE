import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api/client';
import StatusBadge from '../../components/StatusBadge';
import { formatDoctorName } from '../../utils/formatters';
import {
  Clock,
  User,
  Users,
  Activity,
  AlertCircle,
  RefreshCw,
  MapPin,
  CheckCircle
} from 'lucide-react';

export default function MyQueueStatus() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchStatus = async () => {
    try {
      setRefreshing(true);
      const res = await api.get('/queue/my-status');
      if (res.data.success) {
        setData(res.data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    const timer = setInterval(fetchStatus, 15000); // 15s auto-poll
    return () => clearInterval(timer);
  }, []);

  if (loading) {
    return (
      <div className="page-body" style={{ textAlign: 'center', padding: '3rem' }}>
        <p style={{ color: 'var(--text-muted)' }}>Fetching live OPD queue and token status...</p>
      </div>
    );
  }

  const token = data?.myToken;

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Live OPD Queue Tracker</h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            Real-time display of outpatient department waiting tokens and room consultations.
          </p>
        </div>

        <button onClick={fetchStatus} className="btn btn-secondary btn-sm" disabled={refreshing}>
          <RefreshCw size={16} className={refreshing ? 'pulse-badge' : ''} />
          <span>{refreshing ? 'Refreshing...' : 'Refresh Live Status'}</span>
        </button>
      </div>

      {!token ? (
        <div className="card" style={{ textAlign: 'center', padding: '3.5rem 1.5rem', maxWidth: '600px', margin: '0 auto' }}>
          <Clock size={48} style={{ color: 'var(--text-muted)', margin: '0 auto 1rem' }} />
          <h3 style={{ fontSize: '1.4rem', marginBottom: '0.5rem' }}>No Active Token for Today</h3>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '1.5rem', fontSize: '0.95rem' }}>
            You do not have any OPD appointments scheduled for today. Book an appointment to receive a daily waiting token.
          </p>
          <Link to="/patient/book" className="btn btn-primary">
            Schedule Appointment
          </Link>
        </div>
      ) : (
        <div style={{ maxWidth: '850px', margin: '0 auto' }}>
          {/* Main Board Ticket */}
          <div className="queue-ticket-card" style={{ marginBottom: '2rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
              <div>
                <span className="badge" style={{ backgroundColor: 'rgba(56, 189, 248, 0.2)', color: '#38bdf8', marginBottom: '8px' }}>
                  Daily OPD Token
                </span>
                <h2 style={{ color: 'white', fontSize: '1.8rem', margin: '4px 0' }}>
                  {formatDoctorName(token.doctor?.user?.name)}
                </h2>
                <div style={{ color: '#cbd5e1', fontSize: '0.9rem' }}>
                  {token.doctor?.department} • Room {token.doctor?.roomNumber || 'OPD-101'}
                </div>
              </div>

              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: '#94a3b8' }}>
                  Your Token Number
                </div>
                <div className="queue-token-number">
                  #{token.tokenNumber}
                </div>
                <div style={{ color: '#94a3b8', fontSize: '0.8rem' }}>{token.tokenCode}</div>
              </div>
            </div>

            {/* Live Progress Grid */}
            <div
              style={{
                backgroundColor: 'rgba(15, 23, 42, 0.7)',
                borderRadius: 'var(--radius-md)',
                padding: '1.25rem',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
                gap: '1rem',
                border: '1px solid rgba(255,255,255,0.08)'
              }}
            >
              <div>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8', display: 'block' }}>Now Calling / Serving</span>
                <span style={{ fontSize: '1.4rem', fontWeight: '800', color: '#34d399', fontFamily: 'Outfit' }}>
                  {data.currentlyServingTokenNumber ? `#${data.currentlyServingTokenNumber}` : 'Waiting to Call'}
                </span>
              </div>

              <div>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8', display: 'block' }}>Patients Ahead</span>
                <span style={{ fontSize: '1.4rem', fontWeight: '800', color: 'white', fontFamily: 'Outfit' }}>
                  {data.patientsAhead} {data.patientsAhead === 1 ? 'patient' : 'patients'}
                </span>
              </div>

              <div>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8', display: 'block' }}>Approximate Wait</span>
                <span style={{ fontSize: '1.4rem', fontWeight: '800', color: '#fbbf24', fontFamily: 'Outfit' }}>
                  ~{data.estimatedWaitMinutes} mins
                </span>
              </div>

              <div>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8', display: 'block' }}>Your Token Status</span>
                <div style={{ marginTop: '4px' }}>
                  <StatusBadge status={token.status} />
                </div>
              </div>
            </div>

            {/* Current guidance */}
            <div style={{ marginTop: '1.5rem', paddingTop: '1rem', borderTop: '1px solid rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.85rem', color: '#e2e8f0' }}>
              {token.status === 'serving' ? (
                <>
                  <CheckCircle size={20} style={{ color: '#34d399', flexShrink: 0 }} />
                  <strong>It is your turn! Please proceed immediately to Room {token.doctor?.roomNumber || 'OPD-101'}.</strong>
                </>
              ) : token.status === 'completed' ? (
                <>
                  <CheckCircle size={20} style={{ color: '#38bdf8', flexShrink: 0 }} />
                  <span>Consultation completed. You can view your doctor diagnosis and digital prescription in Medical Records.</span>
                </>
              ) : (
                <>
                  <AlertCircle size={20} style={{ color: '#38bdf8', flexShrink: 0 }} />
                  <span>Please remain in the OPD Waiting Lounge. You will receive an SMS alert when {formatDoctorName(token.doctor?.user?.name)} calls your token.</span>
                </>
              )}
            </div>
          </div>

          {/* Location / Instructions Card */}
          <div className="card">
            <h3 style={{ fontSize: '1.15rem', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <MapPin size={18} style={{ color: 'var(--primary)' }} />
              Clinic Location & Guidelines
            </h3>
            <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: '0.75rem' }}>
              • Consultations take place on <strong>Floor 1, West Wing (OPD Block)</strong>.<br />
              • Please present your Token <strong>#{token.tokenNumber}</strong> or Appointment ID <strong>{token.appointment?.appointmentNumber}</strong> at the reception desk.<br />
              • If you need vitals (Blood Pressure, Weight) recorded prior to consultation, report to the triage nursing station.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
