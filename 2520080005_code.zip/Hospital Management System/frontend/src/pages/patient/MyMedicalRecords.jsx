import React, { useState, useEffect } from 'react';
import api from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import StatusBadge from '../../components/StatusBadge';
import { formatDoctorName } from '../../utils/formatters';
import {
  FileText,
  Activity,
  Heart,
  Thermometer,
  Weight,
  Pill,
  Calendar,
  User,
  Stethoscope,
  Printer
} from 'lucide-react';

export default function MyMedicalRecords() {
  const { user } = useAuth();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRecord, setSelectedRecord] = useState(null);

  useEffect(() => {
    async function loadRecords() {
      if (!user?.patientProfile?.id) {
        setLoading(false);
        return;
      }
      try {
        const res = await api.get(`/records/patient/${user.patientProfile.id}`);
        if (res.data.success) {
          setRecords(res.data.data);
          if (res.data.data.length > 0) {
            setSelectedRecord(res.data.data[0]);
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadRecords();
  }, [user]);

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Electronic Medical Records (EMR)</h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            Access verified consultation histories, vital signs, diagnoses, and digital prescriptions.
          </p>
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
          Loading your medical history...
        </div>
      ) : records.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '3.5rem 1.5rem', maxWidth: '600px', margin: '0 auto' }}>
          <FileText size={48} style={{ color: 'var(--text-muted)', margin: '0 auto 1rem' }} />
          <h3 style={{ fontSize: '1.3rem', marginBottom: '0.5rem' }}>No Clinical Records Recorded</h3>
          <p style={{ color: 'var(--text-secondary)' }}>
            After you complete an appointment consultation with a doctor, your EMR diagnoses and prescriptions will appear here.
          </p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem', alignItems: 'start' }}>
          {/* Records Timeline List */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <h3 style={{ fontSize: '1.15rem', color: 'var(--navy-dark)' }}>Consultation Timeline</h3>
            {records.map((rec) => {
              const isSelected = selectedRecord?.id === rec.id;
              return (
                <div
                  key={rec.id}
                  onClick={() => setSelectedRecord(rec)}
                  className="card"
                  style={{
                    cursor: 'pointer',
                    borderColor: isSelected ? 'var(--primary)' : 'var(--border-color)',
                    backgroundColor: isSelected ? 'var(--bg-card)' : 'white',
                    boxShadow: isSelected ? 'var(--shadow-md)' : 'var(--shadow-sm)',
                    borderLeft: isSelected ? '4px solid var(--primary)' : '1px solid var(--border-color)'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                    <span style={{ fontWeight: '700', fontSize: '1.05rem', color: 'var(--navy-dark)' }}>
                      {rec.diagnosis}
                    </span>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{rec.visitDate}</span>
                  </div>

                  <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '8px' }}>
                    Attending Physician: <strong>{formatDoctorName(rec.doctor?.user?.name)}</strong> ({rec.doctor?.department})
                  </p>

                  <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', fontSize: '0.75rem' }}>
                    {rec.bloodPressure && (
                      <span className="badge badge-neutral">BP: {rec.bloodPressure}</span>
                    )}
                    {rec.prescription && (
                      <span className="badge badge-primary">
                        <Pill size={12} /> {rec.prescription.items?.length || 0} Meds Prescribed
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Record Detail & Digital Prescription */}
          {selectedRecord && (
            <div className="card" style={{ padding: '2rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '1px solid var(--border-color)', paddingBottom: '1.25rem', marginBottom: '1.5rem' }}>
                <div>
                  <span className="badge badge-primary" style={{ marginBottom: '6px' }}>Clinical Consultation</span>
                  <h2 style={{ fontSize: '1.5rem', color: 'var(--navy-dark)' }}>{selectedRecord.diagnosis}</h2>
                  <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                    Consulted <strong>{formatDoctorName(selectedRecord.doctor?.user?.name)}</strong> on <strong>{selectedRecord.visitDate}</strong>
                  </div>
                </div>

                <button
                  onClick={() => window.print()}
                  className="btn btn-secondary btn-sm"
                  title="Print Record"
                >
                  <Printer size={16} />
                  <span>Print</span>
                </button>
              </div>

              {/* Vital Signs Grid */}
              <div style={{ marginBottom: '1.5rem' }}>
                <h4 style={{ fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.75rem' }}>
                  Recorded Vital Signs
                </h4>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '10px' }}>
                  <div style={{ backgroundColor: 'var(--bg-subtle)', padding: '10px 12px', borderRadius: '8px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--danger)', fontSize: '0.75rem', fontWeight: '600' }}>
                      <Heart size={14} /> Blood Pressure
                    </div>
                    <div style={{ fontSize: '1.1rem', fontWeight: '700', color: 'var(--navy-dark)' }}>
                      {selectedRecord.bloodPressure || 'N/A'}
                    </div>
                  </div>

                  <div style={{ backgroundColor: 'var(--bg-subtle)', padding: '10px 12px', borderRadius: '8px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--secondary)', fontSize: '0.75rem', fontWeight: '600' }}>
                      <Activity size={14} /> Heart Rate
                    </div>
                    <div style={{ fontSize: '1.1rem', fontWeight: '700', color: 'var(--navy-dark)' }}>
                      {selectedRecord.heartRate ? `${selectedRecord.heartRate} bpm` : 'N/A'}
                    </div>
                  </div>

                  <div style={{ backgroundColor: 'var(--bg-subtle)', padding: '10px 12px', borderRadius: '8px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#f59e0b', fontSize: '0.75rem', fontWeight: '600' }}>
                      <Thermometer size={14} /> Temperature
                    </div>
                    <div style={{ fontSize: '1.1rem', fontWeight: '700', color: 'var(--navy-dark)' }}>
                      {selectedRecord.temperature ? `${selectedRecord.temperature} °F` : 'N/A'}
                    </div>
                  </div>

                  <div style={{ backgroundColor: 'var(--bg-subtle)', padding: '10px 12px', borderRadius: '8px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--primary)', fontSize: '0.75rem', fontWeight: '600' }}>
                      <Weight size={14} /> Body Weight
                    </div>
                    <div style={{ fontSize: '1.1rem', fontWeight: '700', color: 'var(--navy-dark)' }}>
                      {selectedRecord.weight ? `${selectedRecord.weight} kg` : 'N/A'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Symptoms & Clinical Notes */}
              <div style={{ marginBottom: '1.5rem' }}>
                <h4 style={{ fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
                  Symptoms & Clinical Observations
                </h4>
                <div style={{ backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '12px', fontSize: '0.9rem', color: 'var(--text-primary)', lineHeight: 1.6 }}>
                  <div><strong>Presenting Symptoms:</strong> {selectedRecord.symptoms}</div>
                  {selectedRecord.doctorNotes && (
                    <div style={{ marginTop: '8px', paddingTop: '8px', borderTop: '1px solid #e2e8f0' }}>
                      <strong>Doctor Notes:</strong> {selectedRecord.doctorNotes}
                    </div>
                  )}
                  {selectedRecord.followUpDate && (
                    <div style={{ marginTop: '8px', color: 'var(--primary)', fontWeight: '600' }}>
                      Recommended Follow-up Date: {selectedRecord.followUpDate}
                    </div>
                  )}
                </div>
              </div>

              {/* Digital Prescription Items */}
              {selectedRecord.prescription && (
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                    <h4 style={{ fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      Digital Rx Prescription (#{selectedRecord.prescription.prescriptionCode})
                    </h4>
                    <StatusBadge status={selectedRecord.prescription.status} />
                  </div>

                  <div className="table-responsive">
                    <table className="table" style={{ fontSize: '0.85rem' }}>
                      <thead>
                        <tr>
                          <th>Medication</th>
                          <th>Dosage & Frequency</th>
                          <th>Duration</th>
                          <th>Instructions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {selectedRecord.prescription.items?.map((item, idx) => (
                          <tr key={idx}>
                            <td>
                              <strong>{item.medicineName}</strong>
                            </td>
                            <td>
                              <div>{item.dosage}</div>
                              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{item.frequency}</span>
                            </td>
                            <td>{item.durationDays} days (Qty: {item.quantity})</td>
                            <td>{item.instructions || 'As advised'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {selectedRecord.prescription.generalAdvice && (
                    <div style={{ marginTop: '1rem', backgroundColor: '#f0fdfa', border: '1px solid #ccfbf1', borderRadius: '8px', padding: '10px 12px', fontSize: '0.85rem', color: '#0f766e' }}>
                      <strong>Physician Advice:</strong> {selectedRecord.prescription.generalAdvice}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
