import React, { useState, useEffect } from 'react';
import api from '../../api/client';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { useNotifications } from '../../context/NotificationContext';
import {
  CreditCard,
  CheckCircle,
  Shield,
  DollarSign,
  Receipt,
  FileCheck,
  AlertCircle
} from 'lucide-react';

export default function MyBills() {
  const { showToast } = useNotifications();
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);

  // Pay modal
  const [payModal, setPayModal] = useState(null); // bill
  const [payMethod, setPayMethod] = useState('upi');
  const [paying, setPaying] = useState(false);

  // Insurance modal
  const [claimModal, setClaimModal] = useState(null); // bill
  const [insuranceProvider, setInsuranceProvider] = useState('');
  const [policyNumber, setPolicyNumber] = useState('');
  const [claiming, setClaiming] = useState(false);

  const fetchBills = async () => {
    try {
      setLoading(true);
      const res = await api.get('/billing');
      if (res.data.success) {
        setBills(res.data.data.bills || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBills();
  }, []);

  const handlePaySubmit = async (e) => {
    e.preventDefault();
    if (!payModal) return;

    try {
      setPaying(true);
      const res = await api.post(`/billing/${payModal.id}/pay`, {
        amount: payModal.balanceAmount,
        paymentMethod: payMethod
      });

      if (res.data.success) {
        showToast('Payment processed successfully! Invoice cleared.');
        setPayModal(null);
        fetchBills();
      }
    } catch (err) {
      showToast(err.response?.data?.message || 'Payment failed', 'error');
    } finally {
      setPaying(false);
    }
  };

  const handleClaimSubmit = async (e) => {
    e.preventDefault();
    if (!claimModal) return;

    try {
      setClaiming(true);
      const res = await api.post('/billing/claim', {
        billId: claimModal.id,
        providerName: insuranceProvider,
        policyNumber: policyNumber,
        claimAmount: claimModal.totalAmount
      });

      if (res.data.success) {
        showToast('Insurance claim submitted for adjudication.');
        setClaimModal(null);
        fetchBills();
      }
    } catch (err) {
      showToast(err.response?.data?.message || 'Claim submission failed', 'error');
    } finally {
      setClaiming(false);
    }
  };

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Billing & Invoices</h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            Transparent itemized charges, digital payments, and insurance claims.
          </p>
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Bill Date</th>
                <th>Consultation</th>
                <th>Pharmacy</th>
                <th>Diagnostics</th>
                <th>Total Amount</th>
                <th>Balance Due</th>
                <th>Status</th>
                <th>Insurance Claim</th>
                <th style={{ textAlign: 'right' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="10" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading invoices...
                  </td>
                </tr>
              ) : bills.length === 0 ? (
                <tr>
                  <td colSpan="10" style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
                    No invoices generated yet.
                  </td>
                </tr>
              ) : (
                bills.map((bill) => (
                  <tr key={bill.id}>
                    <td>
                      <strong style={{ color: 'var(--navy-dark)' }}>{bill.billNumber}</strong>
                    </td>
                    <td>{bill.billDate}</td>
                    <td>₹{parseFloat(bill.consultationFee).toFixed(0)}</td>
                    <td>₹{parseFloat(bill.medicineFee).toFixed(0)}</td>
                    <td>₹{parseFloat(bill.labFee).toFixed(0)}</td>
                    <td>
                      <strong>₹{parseFloat(bill.totalAmount).toFixed(2)}</strong>
                    </td>
                    <td>
                      <strong style={{ color: parseFloat(bill.balanceAmount) > 0 ? '#ef4444' : '#10b981' }}>
                        ₹{parseFloat(bill.balanceAmount).toFixed(2)}
                      </strong>
                    </td>
                    <td>
                      <StatusBadge status={bill.paymentStatus} />
                    </td>
                    <td>
                      {bill.insuranceClaim ? (
                        <StatusBadge status={bill.insuranceClaim.claimStatus} />
                      ) : (
                        <button
                          onClick={() => {
                            setClaimModal(bill);
                            setInsuranceProvider(bill.patient?.insuranceProvider || '');
                            setPolicyNumber(bill.patient?.insurancePolicyNumber || '');
                          }}
                          className="btn btn-secondary btn-sm"
                          style={{ fontSize: '0.75rem', padding: '2px 8px' }}
                        >
                          <Shield size={12} /> Claim
                        </button>
                      )}
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      {parseFloat(bill.balanceAmount) > 0 ? (
                        <button
                          onClick={() => setPayModal(bill)}
                          className="btn btn-primary btn-sm"
                        >
                          <CreditCard size={14} /> Pay Now
                        </button>
                      ) : (
                        <span style={{ fontSize: '0.8rem', color: 'var(--success)', fontWeight: '600' }}>
                          ✓ Settled
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pay Modal */}
      {payModal && (
        <Modal
          isOpen={true}
          onClose={() => setPayModal(null)}
          title={`Pay Invoice #${payModal.billNumber}`}
        >
          <form onSubmit={handlePaySubmit}>
            <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: '8px', padding: '14px', marginBottom: '1.25rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', fontSize: '0.9rem' }}>
                <span>Consultation Fee:</span>
                <span>₹{parseFloat(payModal.consultationFee).toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', fontSize: '0.9rem' }}>
                <span>Pharmacy Medicines:</span>
                <span>₹{parseFloat(payModal.medicineFee).toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', fontSize: '0.9rem' }}>
                <span>Diagnostic Lab Tests:</span>
                <span>₹{parseFloat(payModal.labFee).toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.1rem', fontWeight: '800', borderTop: '1px solid #e2e8f0', paddingTop: '8px', marginTop: '4px', color: 'var(--navy-dark)' }}>
                <span>Balance Due:</span>
                <span style={{ color: 'var(--primary)' }}>₹{parseFloat(payModal.balanceAmount).toFixed(2)}</span>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Payment Method</label>
              <select
                className="form-control"
                value={payMethod}
                onChange={(e) => setPayMethod(e.target.value)}
              >
                <option value="upi">UPI (GPay / PhonePe / Paytm simulation)</option>
                <option value="credit_card">Credit Card (Visa / Mastercard)</option>
                <option value="debit_card">Debit Card</option>
                <option value="cash">Cash at Hospital Desk</option>
              </select>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button
                type="button"
                onClick={() => setPayModal(null)}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={paying}
              >
                {paying ? 'Processing...' : `Pay ₹${parseFloat(payModal.balanceAmount).toFixed(2)}`}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Insurance Claim Modal */}
      {claimModal && (
        <Modal
          isOpen={true}
          onClose={() => setClaimModal(null)}
          title="Submit Health Insurance Claim"
        >
          <form onSubmit={handleClaimSubmit}>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', marginBottom: '1rem' }}>
              Submit a cashless or reimbursement insurance claim for Invoice <strong>#{claimModal.billNumber}</strong> (₹{parseFloat(claimModal.totalAmount).toFixed(2)}).
            </p>

            <div className="form-group">
              <label className="form-label">Insurance Provider *</label>
              <input
                type="text"
                className="form-control"
                placeholder="e.g. Star Health, HDFC ERGO, Care Health"
                value={insuranceProvider}
                onChange={(e) => setInsuranceProvider(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Policy / Member ID *</label>
              <input
                type="text"
                className="form-control"
                placeholder="e.g. POL-8839210"
                value={policyNumber}
                onChange={(e) => setPolicyNumber(e.target.value)}
                required
              />
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button
                type="button"
                onClick={() => setClaimModal(null)}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={claiming}
              >
                {claiming ? 'Submitting Claim...' : 'Submit Claim'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
