import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api/client';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { formatDoctorName } from '../../utils/formatters';
import { useNotifications } from '../../context/NotificationContext';
import {
  Calendar,
  Clock,
  User,
  XCircle,
  Eye,
  FileText,
  Search,
  Plus
} from 'lucide-react';

export default function MyAppointments() {
  const { showToast } = useNotifications();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');

  // Cancel modal state
  const [cancelModal, setCancelModal] = useState(null); // appointment object
  const [cancellationReason, setCancellationReason] = useState('');
  const [cancelling, setCancelling] = useState(false);

  const fetchAppointments = async () => {
    try {
      setLoading(true);
      const res = await api.get('/appointments');
      if (res.data.success) {
        setAppointments(res.data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  const handleCancelSubmit = async (e) => {
    e.preventDefault();
    if (!cancelModal) return;

    try {
      setCancelling(true);
      const res = await api.post(`/appointments/${cancelModal.id}/cancel`, {
        cancellationReason
      });

      if (res.data.success) {
        showToast('Appointment has been cancelled.');
        setCancelModal(null);
        setCancellationReason('');
        fetchAppointments();
      }
    } catch (err) {
      showToast(err.response?.data?.message || 'Failed to cancel appointment', 'error');
    } finally {
      setCancelling(false);
    }
  };

  const filtered = appointments.filter(a => {
    const matchStatus = statusFilter === 'all' || a.status === statusFilter;
    const matchSearch = !search ||
      a.appointmentNumber.toLowerCase().includes(search.toLowerCase()) ||
      a.doctor?.user?.name.toLowerCase().includes(search.toLowerCase()) ||
      a.doctor?.department.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>My Consultation Schedule</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Track all your past, active, and upcoming hospital appointments.</p>
        </div>
        <Link to="/patient/book" className="btn btn-primary">
          <Plus size={18} />
          <span>New Appointment</span>
        </Link>
      </div>

      {/* Filter Toolbar */}
      <div className="card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem', display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          {['all', 'confirmed', 'in_consultation', 'completed', 'cancelled'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className="btn btn-sm"
              style={{
                backgroundColor: statusFilter === st ? 'var(--navy-dark)' : 'var(--bg-subtle)',
                color: statusFilter === st ? 'white' : 'var(--text-secondary)',
                fontWeight: '600',
                textTransform: 'capitalize'
              }}
            >
              {st.replace('_', ' ')}
            </button>
          ))}
        </div>

        <div style={{ position: 'relative', minWidth: '240px' }}>
          <Search size={16} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
          <input
            type="text"
            className="form-control"
            style={{ paddingLeft: '34px', fontSize: '0.85rem' }}
            placeholder="Search by doctor or APT #..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Appointments Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Appointment #</th>
                <th>Doctor & Dept</th>
                <th>Date & Slot</th>
                <th>OPD Token</th>
                <th>Status</th>
                <th>Consultation Fee</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading appointments...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
                    No appointments found matching current filters.
                  </td>
                </tr>
              ) : (
                filtered.map((apt) => (
                  <tr key={apt.id}>
                    <td>
                      <strong style={{ color: 'var(--navy-dark)' }}>{apt.appointmentNumber}</strong>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{apt.reason}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: '600' }}>{formatDoctorName(apt.doctor?.user?.name)}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--primary)' }}>
                        {apt.doctor?.department} (Room {apt.doctor?.roomNumber || 'OPD'})
                      </div>
                    </td>
                    <td>
                      <div style={{ fontWeight: '600' }}>{apt.appointmentDate}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{apt.timeSlot}</div>
                    </td>
                    <td>
                      {apt.queueToken ? (
                        <span className="badge badge-info">
                          #{apt.queueToken.tokenNumber} ({apt.queueToken.status})
                        </span>
                      ) : (
                        <span style={{ color: 'var(--text-muted)' }}>-</span>
                      )}
                    </td>
                    <td>
                      <StatusBadge status={apt.status} />
                    </td>
                    <td>
                      <strong style={{ color: 'var(--navy-dark)' }}>
                        ₹{parseFloat(apt.doctor?.consultationFee || 500).toFixed(0)}
                      </strong>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'flex', gap: '6px', justifyContent: 'flex-end' }}>
                        {apt.status === 'confirmed' && (
                          <button
                            onClick={() => setCancelModal(apt)}
                            className="btn btn-secondary btn-sm"
                            style={{ color: '#ef4444' }}
                            title="Cancel appointment"
                          >
                            <XCircle size={15} />
                            <span>Cancel</span>
                          </button>
                        )}
                        {apt.queueToken && (
                          <Link to="/patient/queue" className="btn btn-secondary btn-sm" title="View Token Live Status">
                            <Clock size={15} />
                            <span>Token</span>
                          </Link>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cancellation Modal */}
      {cancelModal && (
        <Modal
          isOpen={true}
          onClose={() => setCancelModal(null)}
          title="Cancel Appointment"
        >
          <form onSubmit={handleCancelSubmit}>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '1.25rem', fontSize: '0.9rem' }}>
              Are you sure you wish to cancel Appointment <strong>#{cancelModal.appointmentNumber}</strong> with <strong>{formatDoctorName(cancelModal.doctor?.user?.name)}</strong> on <strong>{cancelModal.appointmentDate}</strong>?
            </p>

            <div className="form-group">
              <label className="form-label">Reason for Cancellation</label>
              <textarea
                className="form-control"
                placeholder="Please state why you are cancelling..."
                value={cancellationReason}
                onChange={(e) => setCancellationReason(e.target.value)}
                required
              />
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button
                type="button"
                onClick={() => setCancelModal(null)}
                className="btn btn-secondary"
              >
                Keep Appointment
              </button>
              <button
                type="submit"
                className="btn btn-danger"
                disabled={cancelling}
              >
                {cancelling ? 'Cancelling...' : 'Confirm Cancellation'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
