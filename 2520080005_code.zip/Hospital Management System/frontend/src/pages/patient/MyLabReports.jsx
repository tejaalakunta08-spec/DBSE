import React, { useState, useEffect } from 'react';
import api from '../../api/client';
import StatusBadge from '../../components/StatusBadge';
import { formatDoctorName } from '../../utils/formatters';
import {
  FlaskConical,
  AlertTriangle,
  CheckCircle,
  Clock,
  Printer,
  FileText
} from 'lucide-react';

export default function MyLabReports() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState(null);

  useEffect(() => {
    async function loadReports() {
      try {
        const res = await api.get('/lab/reports');
        if (res.data.success) {
          setReports(res.data.data);
          if (res.data.data.length > 0) {
            setSelectedReport(res.data.data[0]);
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadReports();
  }, []);

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Diagnostic Laboratory Reports</h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            Pathology, biochemistry, and radiological investigation findings.
          </p>
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
          Loading lab investigation reports...
        </div>
      ) : reports.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '3.5rem 1.5rem', maxWidth: '600px', margin: '0 auto' }}>
          <FlaskConical size={48} style={{ color: 'var(--text-muted)', margin: '0 auto 1rem' }} />
          <h3 style={{ fontSize: '1.3rem', marginBottom: '0.5rem' }}>No Diagnostic Reports Available</h3>
          <p style={{ color: 'var(--text-secondary)' }}>
            When a doctor orders blood tests or radiological imaging for you, your results will be published here.
          </p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem', alignItems: 'start' }}>
          {/* Reports Table */}
          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <div className="table-responsive">
              <table className="table">
                <thead>
                  <tr>
                    <th>Report #</th>
                    <th>Test Name</th>
                    <th>Date</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {reports.map((rep) => {
                    const isSelected = selectedReport?.id === rep.id;
                    return (
                      <tr
                        key={rep.id}
                        onClick={() => setSelectedReport(rep)}
                        style={{
                          cursor: 'pointer',
                          backgroundColor: isSelected ? 'var(--primary-light)' : 'transparent'
                        }}
                      >
                        <td>
                          <strong>{rep.reportNumber}</strong>
                        </td>
                        <td>
                          <div style={{ fontWeight: '600' }}>{rep.test?.name}</div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                            {rep.test?.category}
                          </div>
                        </td>
                        <td>{rep.prescribedDate}</td>
                        <td>
                          <StatusBadge status={rep.status} />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Report Detail View */}
          {selectedReport && (
            <div className="card" style={{ padding: '2rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '1px solid var(--border-color)', paddingBottom: '1rem', marginBottom: '1.5rem' }}>
                <div>
                  <span className="badge badge-primary" style={{ marginBottom: '6px' }}>Diagnostic Investigation</span>
                  <h3 style={{ fontSize: '1.4rem' }}>{selectedReport.test?.name}</h3>
                  <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                    Report #{selectedReport.reportNumber} • Prescribed by {formatDoctorName(selectedReport.doctor?.user?.name)}
                  </div>
                </div>

                <button onClick={() => window.print()} className="btn btn-secondary btn-sm">
                  <Printer size={16} />
                  <span>Print</span>
                </button>
              </div>

              <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: '8px', padding: '12px 16px', marginBottom: '1.5rem', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '10px' }}>
                <div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Specimen Type</span>
                  <div style={{ fontWeight: '700', fontSize: '0.85rem' }}>{selectedReport.test?.sampleRequired || 'Blood'}</div>
                </div>
                <div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Normal Reference Range</span>
                  <div style={{ fontWeight: '700', fontSize: '0.85rem' }}>{selectedReport.normalRangeSnapshot || selectedReport.test?.normalRange}</div>
                </div>
                <div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Investigation Status</span>
                  <div><StatusBadge status={selectedReport.status} /></div>
                </div>
              </div>

              {/* Result Value Box */}
              <div style={{ marginBottom: '1.5rem' }}>
                <h4 style={{ fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
                  Laboratory Findings & Values
                </h4>
                {selectedReport.resultValue ? (
                  <div
                    style={{
                      backgroundColor: selectedReport.isAbnormal ? '#fffbeb' : '#f0fdf4',
                      border: selectedReport.isAbnormal ? '1px solid #fde68a' : '1px solid #bbf7d0',
                      borderRadius: '8px',
                      padding: '16px',
                      color: selectedReport.isAbnormal ? '#92400e' : '#166534',
                      lineHeight: 1.6
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: '700', marginBottom: '6px' }}>
                      {selectedReport.isAbnormal ? <AlertTriangle size={18} /> : <CheckCircle size={18} />}
                      <span>{selectedReport.isAbnormal ? 'Abnormal / Borderline Result' : 'Within Normal Physiological Range'}</span>
                    </div>
                    <div style={{ fontSize: '0.95rem', fontWeight: '500' }}>
                      {selectedReport.resultValue}
                    </div>
                  </div>
                ) : (
                  <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: '8px', padding: '16px', textAlign: 'center', color: 'var(--text-muted)' }}>
                    <Clock size={20} style={{ margin: '0 auto 4px' }} />
                    <p style={{ fontSize: '0.85rem' }}>Specimen sample is currently being processed by clinical pathology.</p>
                  </div>
                )}
              </div>

              {selectedReport.technicianNotes && (
                <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', backgroundColor: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                  <strong>Pathologist / Technician Notes:</strong> {selectedReport.technicianNotes}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
