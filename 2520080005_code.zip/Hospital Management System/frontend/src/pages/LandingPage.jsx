import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';
import {
  Calendar,
  Clock,
  Shield,
  Activity,
  Award,
  PhoneCall,
  CheckCircle2,
  Stethoscope,
  HeartPulse,
  Brain,
  Bone,
  Baby,
  ArrowRight
} from 'lucide-react';

export default function LandingPage() {
  const [doctors, setDoctors] = useState([]);

  useEffect(() => {
    async function fetchDocs() {
      try {
        const res = await api.get('/doctors');
        if (res.data.success) {
          setDoctors(res.data.data.slice(0, 4));
        }
      } catch (e) {
        // quiet fallback
      }
    }
    fetchDocs();
  }, []);

  const specialties = [
    { name: 'Cardiology', icon: HeartPulse, color: '#ef4444', desc: 'Comprehensive cardiac care, interventions, and diagnostics.' },
    { name: 'Neurology', icon: Brain, color: '#8b5cf6', desc: 'Specialized diagnosis and treatment of neural & brain disorders.' },
    { name: 'Orthopedics', icon: Bone, color: '#0ea5e9', desc: 'Advanced joint replacement, spine surgery, and trauma care.' },
    { name: 'Pediatrics', icon: Baby, color: '#f59e0b', desc: 'Compassionate pediatric wellness, neonatal ICU, and vaccinations.' },
    { name: 'General Medicine', icon: Stethoscope, color: '#10b981', desc: 'Holistic chronic illness management and adult primary care.' },
    { name: '24/7 Diagnostics', icon: Activity, color: '#06b6d4', desc: 'Modern automated pathology labs and radiological imaging.' }
  ];

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#ffffff' }}>
      {/* Hero Section */}
      <section
        style={{
          background: 'radial-gradient(circle at 80% 20%, rgba(13, 148, 136, 0.12) 0%, rgba(248, 250, 252, 1) 60%)',
          padding: '4.5rem 1.5rem',
          borderBottom: '1px solid var(--border-color)'
        }}
      >
        <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '3rem', alignItems: 'center' }}>
          <div>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '6px 14px',
                borderRadius: 'var(--radius-full)',
                backgroundColor: 'var(--primary-light)',
                color: 'var(--primary)',
                fontWeight: '700',
                fontSize: '0.8rem',
                marginBottom: '1.25rem'
              }}
            >
              <Activity size={16} /> Advanced Digital Healthcare Platform
            </div>
            <h1
              style={{
                fontSize: 'clamp(2.2rem, 5vw, 3.4rem)',
                lineHeight: 1.15,
                marginBottom: '1.25rem',
                color: 'var(--navy-dark)'
              }}
            >
              Next-Generation <span style={{ color: 'var(--primary)' }}>Hospital Care</span> & OPD Scheduling
            </h1>
            <p
              style={{
                fontSize: '1.1rem',
                color: 'var(--text-secondary)',
                lineHeight: 1.6,
                marginBottom: '2rem'
              }}
            >
              Experience seamless OPD appointment booking, real-time live queue tokens, digital electronic medical records (EMR), automated pharmacy dispensing, and transparent billing.
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
              <Link to="/patient/book" className="btn btn-primary btn-lg">
                <Calendar size={20} />
                <span>Book OPD Appointment</span>
              </Link>
              <Link to="/patient/queue" className="btn btn-secondary btn-lg">
                <Clock size={20} />
                <span>Live Queue Status</span>
              </Link>
            </div>

            <div style={{ display: 'flex', gap: '2rem', marginTop: '2.5rem', paddingTop: '1.5rem', borderTop: '1px solid #e2e8f0' }}>
              <div>
                <div style={{ fontSize: '1.75rem', fontWeight: '800', fontFamily: 'Outfit', color: 'var(--navy-dark)' }}>15+</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: '600' }}>Specialist Doctors</div>
              </div>
              <div>
                <div style={{ fontSize: '1.75rem', fontWeight: '800', fontFamily: 'Outfit', color: 'var(--navy-dark)' }}>24/7</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: '600' }}>Emergency & Trauma</div>
              </div>
              <div>
                <div style={{ fontSize: '1.75rem', fontWeight: '800', fontFamily: 'Outfit', color: 'var(--navy-dark)' }}>100%</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: '600' }}>Paperless EMR</div>
              </div>
            </div>
          </div>

          {/* Hero Feature Box */}
          <div
            style={{
              backgroundColor: '#ffffff',
              borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--border-color)',
              padding: '2rem',
              boxShadow: 'var(--shadow-xl)',
              position: 'relative'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
              <h3 style={{ fontSize: '1.25rem', color: 'var(--navy-dark)' }}>Today’s Live OPD Board</h3>
              <span className="badge badge-success">
                <span className="pulse-badge" style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'currentColor' }}></span>
                Queue Active
              </span>
            </div>

            <div className="queue-ticket-card" style={{ marginBottom: '1.5rem', padding: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: '#94a3b8' }}>
                    Now Serving in Room 101
                  </div>
                  <div style={{ fontSize: '1.1rem', fontWeight: '700', color: 'white' }}>
                    Dr. Ramesh Sharma (Cardiology)
                  </div>
                </div>
                <div className="queue-token-number" style={{ fontSize: '2.5rem' }}>
                  #01
                </div>
              </div>
              <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', paddingTop: '0.75rem', borderTop: '1px solid rgba(255,255,255,0.1)', fontSize: '0.8rem', color: '#cbd5e1' }}>
                <div>Estimated wait per patient: <strong>15 mins</strong></div>
                <div>Status: <span style={{ color: '#38bdf8' }}>Serving Patient</span></div>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                <CheckCircle2 size={18} style={{ color: 'var(--success)', flexShrink: 0 }} />
                <span>Instant SMS Token Alerts delivered via Twilio</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                <CheckCircle2 size={18} style={{ color: 'var(--success)', flexShrink: 0 }} />
                <span>Digital E-Prescriptions & Pharmacy integration</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                <CheckCircle2 size={18} style={{ color: 'var(--success)', flexShrink: 0 }} />
                <span>Seamless Insurance Claim settlement workflow</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Specialties Grid */}
      <section style={{ padding: '4rem 1.5rem', maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <h2 style={{ fontSize: '2.2rem', marginBottom: '0.5rem' }}>Centers of Clinical Excellence</h2>
          <p style={{ color: 'var(--text-secondary)', maxWidth: '600px', margin: '0 auto' }}>
            Multi-disciplinary medical departments equipped with state-of-the-art diagnostic and surgical technologies.
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.5rem' }}>
          {specialties.map((spec, i) => {
            const Icon = spec.icon;
            return (
              <div key={i} className="card" style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                <div
                  style={{
                    width: '46px',
                    height: '46px',
                    borderRadius: '12px',
                    backgroundColor: `${spec.color}15`,
                    color: spec.color,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <Icon size={24} />
                </div>
                <h3 style={{ fontSize: '1.15rem' }}>{spec.name}</h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.5, flex: 1 }}>
                  {spec.desc}
                </p>
                <Link
                  to={`/patient/book`}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '4px',
                    fontSize: '0.85rem',
                    fontWeight: '700',
                    color: 'var(--primary)',
                    marginTop: '0.5rem'
                  }}
                >
                  Book Specialist <ArrowRight size={14} />
                </Link>
              </div>
            );
          })}
        </div>
      </section>

      {/* Featured Doctors */}
      {doctors.length > 0 && (
        <section style={{ backgroundColor: 'var(--bg-main)', padding: '4rem 1.5rem', borderTop: '1px solid var(--border-color)', borderBottom: '1px solid var(--border-color)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '2.5rem', flexWrap: 'wrap', gap: '1rem' }}>
              <div>
                <h2 style={{ fontSize: '2.2rem', marginBottom: '0.5rem' }}>Our Distinguished Faculty</h2>
                <p style={{ color: 'var(--text-secondary)' }}>Consult with certified specialists committed to clinical excellence.</p>
              </div>
              <Link to="/patient/book" className="btn btn-secondary btn-sm">
                View All Doctors
              </Link>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.5rem' }}>
              {doctors.map((doc) => (
                <div key={doc.id} className="card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                    <div
                      style={{
                        width: '54px',
                        height: '54px',
                        borderRadius: '50%',
                        backgroundColor: '#ccfbf1',
                        color: '#0f766e',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontWeight: '800',
                        fontSize: '1.2rem'
                      }}
                    >
                      {doc.user?.name ? doc.user.name.split(' ')[1]?.charAt(0) || 'D' : 'D'}
                    </div>
                    <div>
                      <h4 style={{ fontSize: '1.05rem', marginBottom: '2px' }}>{doc.user?.name}</h4>
                      <span className="badge badge-primary">{doc.department}</span>
                    </div>
                  </div>

                  <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '1rem', flex: 1 }}>
                    {doc.specialization} • {doc.qualification}
                  </p>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '0.75rem', borderTop: '1px solid #f1f5f9', fontSize: '0.85rem' }}>
                    <div>Fee: <strong>₹{parseFloat(doc.consultationFee).toFixed(0)}</strong></div>
                    <Link to={`/patient/book`} className="btn btn-primary btn-sm">
                      Book Slot
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Emergency Callout Banner */}
      <section style={{ padding: '3.5rem 1.5rem', background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)', color: 'white' }}>
        <div style={{ maxWidth: '1000px', margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '2rem' }}>
          <div>
            <div style={{ color: '#ef4444', fontWeight: '700', fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <PhoneCall size={16} /> Immediate Critical Care Hotline
            </div>
            <h2 style={{ color: 'white', fontSize: '2rem', marginBottom: '0.5rem' }}>
              Need Urgent Emergency Medical Assistance?
            </h2>
            <p style={{ color: '#94a3b8', fontSize: '1rem' }}>
              Our 24-hour trauma center and automated rapid-response ambulances are on standby.
            </p>
          </div>
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
            <a
              href="tel:108"
              className="btn btn-danger btn-lg"
              style={{ fontWeight: '700', fontSize: '1.1rem', letterSpacing: '0.02em' }}
            >
              Call 108 Ambulance
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ backgroundColor: '#ffffff', borderTop: '1px solid var(--border-color)', padding: '2.5rem 1.5rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <p style={{ fontWeight: '600', color: 'var(--navy-dark)', marginBottom: '0.5rem' }}>
            MedCare Hospital Management & OPD Appointment System
          </p>
          <p>Built with React.js, Node.js, Express.js, Sequelize ORM & MySQL. Role-Based Access Control for Patient, Doctor, and Admin.</p>
        </div>
      </footer>
    </div>
  );
}
