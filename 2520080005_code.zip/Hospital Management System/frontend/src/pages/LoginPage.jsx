import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import {
  Activity,
  Lock,
  Mail,
  ShieldCheck,
  Stethoscope,
  User,
  ArrowRight,
  Sparkles
} from 'lucide-react';

export default function LoginPage() {
  const { login } = useAuth();
  const { showToast } = useNotifications();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [activeTab, setActiveTab] = useState('patient'); // 'patient' | 'doctor' | 'admin'
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const expiredSession = new URLSearchParams(location.search).get('expired');

  // One-click demo credentials autofill
  const handleDemoFill = (roleType) => {
    setActiveTab(roleType);
    if (roleType === 'admin') {
      setEmail('admin@hospital.com');
      setPassword('Admin@123');
    } else if (roleType === 'doctor') {
      setEmail('dr.sharma@hospital.com');
      setPassword('Doctor@123');
    } else {
      setEmail('patient.sai@hospital.com');
      setPassword('Patient@123');
    }
    setErrorMsg('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorMsg('Please enter both email address and password.');
      return;
    }

    try {
      setSubmitting(true);
      setErrorMsg('');
      const loggedUser = await login(email, password);
      showToast(`Welcome back, ${loggedUser.name}!`);

      if (loggedUser.role === 'admin') {
        navigate('/admin/dashboard');
      } else if (loggedUser.role === 'doctor') {
        navigate('/doctor/dashboard');
      } else {
        navigate('/patient/dashboard');
      }
    } catch (err) {
      setErrorMsg(err.response?.data?.message || err.message || 'Login failed. Please check credentials.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      style={{
        minHeight: 'calc(100vh - 70px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '2rem 1rem',
        background: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)'
      }}
    >
      <div style={{ maxWidth: '480px', width: '100%' }}>
        <div className="card" style={{ padding: '2.5rem', boxShadow: 'var(--shadow-xl)' }}>
          {/* Logo & Header */}
          <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
            <div
              style={{
                width: '50px',
                height: '50px',
                borderRadius: '14px',
                background: 'linear-gradient(135deg, var(--primary) 0%, #0284c7 100%)',
                color: 'white',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '1rem',
                boxShadow: '0 4px 12px rgba(13, 148, 136, 0.3)'
              }}
            >
              <Activity size={28} />
            </div>
            <h2 style={{ fontSize: '1.75rem', marginBottom: '0.25rem' }}>Welcome to MedCare</h2>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
              Sign in to access your specialized healthcare portal
            </p>
          </div>

          {expiredSession && (
            <div style={{ backgroundColor: '#fef3c7', color: '#92400e', padding: '10px 14px', borderRadius: '8px', fontSize: '0.85rem', marginBottom: '1.25rem', fontWeight: '500' }}>
              Your session expired. Please log in again.
            </div>
          )}

          {errorMsg && (
            <div style={{ backgroundColor: '#fee2e2', color: '#991b1b', padding: '10px 14px', borderRadius: '8px', fontSize: '0.85rem', marginBottom: '1.25rem', fontWeight: '500' }}>
              {errorMsg}
            </div>
          )}

          {/* Quick Demo Credentials Autofill Picker */}
          <div style={{ backgroundColor: '#f0fdfa', border: '1px solid #ccfbf1', borderRadius: 'var(--radius-md)', padding: '12px', marginBottom: '1.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.75rem', fontWeight: '700', color: '#0f766e', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '8px' }}>
              <Sparkles size={14} /> 1-Click Academic Demo Sign-In
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px' }}>
              <button
                type="button"
                onClick={() => handleDemoFill('patient')}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.75rem', padding: '6px', border: activeTab === 'patient' ? '2px solid var(--primary)' : '1px solid #cbd5e1' }}
              >
                👤 Patient
              </button>
              <button
                type="button"
                onClick={() => handleDemoFill('doctor')}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.75rem', padding: '6px', border: activeTab === 'doctor' ? '2px solid var(--primary)' : '1px solid #cbd5e1' }}
              >
                🩺 Doctor
              </button>
              <button
                type="button"
                onClick={() => handleDemoFill('admin')}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.75rem', padding: '6px', border: activeTab === 'admin' ? '2px solid var(--primary)' : '1px solid #cbd5e1' }}
              >
                👑 Admin
              </button>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <div style={{ position: 'relative' }}>
                <Mail size={18} style={{ position: 'absolute', left: '12px', top: '12px', color: 'var(--text-muted)' }} />
                <input
                  type="email"
                  className="form-control"
                  style={{ paddingLeft: '38px' }}
                  placeholder="name@hospital.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Password</label>
              <div style={{ position: 'relative' }}>
                <Lock size={18} style={{ position: 'absolute', left: '12px', top: '12px', color: 'var(--text-muted)' }} />
                <input
                  type="password"
                  className="form-control"
                  style={{ paddingLeft: '38px' }}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              style={{ width: '100%', marginTop: '0.5rem', padding: '0.75rem' }}
              disabled={submitting}
            >
              {submitting ? 'Authenticating...' : 'Sign In'}
              <ArrowRight size={18} />
            </button>
          </form>

          <div style={{ marginTop: '1.75rem', textAlign: 'center', paddingTop: '1.25rem', borderTop: '1px solid #e2e8f0', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
            Are you a new patient?{' '}
            <Link to="/register" style={{ fontWeight: '700', color: 'var(--primary)' }}>
              Create Patient Account
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
