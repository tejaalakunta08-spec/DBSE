import React, { useState, useEffect } from 'react';
import api from '../../api/client';
import Modal from '../../components/Modal';
import StatusBadge from '../../components/StatusBadge';
import { formatDoctorName } from '../../utils/formatters';
import { useNotifications } from '../../context/NotificationContext';
import {
  FlaskConical,
  Plus,
  Search,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileEdit
} from 'lucide-react';

export default function AdminLab() {
  const { showToast } = useNotifications();
  const [reports, setReports] = useState([]);
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(true);

  // Enter Result Modal
  const [resultModal, setResultModal] = useState(null); // report
  const [resultValue, setResultValue] = useState('');
  const [isAbnormal, setIsAbnormal] = useState(false);
  const [status, setStatus] = useState('completed');
  const [technicianNotes, setTechnicianNotes] = useState('');
  const [saving, setSaving] = useState(false);

  // Add Test Catalog Modal
  const [addTestModal, setAddTestModal] = useState(false);
  const [newTest, setNewTest] = useState({
    name: '',
    category: 'Hematology',
    standardFee: 400,
    normalRange: '',
    unit: '',
    sampleRequired: 'Blood'
  });

  const fetchData = async () => {
    try {
      setLoading(true);
      const [repRes, testRes] = await Promise.all([
        api.get('/lab/reports'),
        api.get('/lab/tests')
      ]);
      if (repRes.data.success) setReports(repRes.data.data);
      if (testRes.data.success) setTests(testRes.data.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleResultSubmit = async (e) => {
    e.preventDefault();
    if (!resultModal) return;

    try {
      setSaving(true);
      const res = await api.put(`/lab/reports/${resultModal.id}`, {
        resultValue,
        isAbnormal,
        status,
        technicianNotes
      });
      if (res.data.success) {
        showToast('Lab report updated and released to patient!');
        setResultModal(null);
        fetchData();
      }
    } catch (err) {
      showToast('Failed to update lab report', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleAddTestSubmit = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const res = await api.post('/lab/tests', newTest);
      if (res.data.success) {
        showToast(`Diagnostic test ${newTest.name} added to catalog!`);
        setAddTestModal(false);
        fetchData();
      }
    } catch (err) {
      showToast('Failed to add lab test', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Diagnostic Pathology & Radiology</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Manage patient specimen investigations, test catalogs, and clinical pathology reports.</p>
        </div>

        <button onClick={() => setAddTestModal(true)} className="btn btn-primary">
          <Plus size={18} />
          <span>New Catalog Test</span>
        </button>
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="card-header" style={{ padding: '1.25rem 1.5rem', margin: 0 }}>
          <h3 className="card-title">Laboratory Orders & Patient Specimens</h3>
        </div>

        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Report #</th>
                <th>Patient Name</th>
                <th>Test Name & Specimen</th>
                <th>Ordering Doctor</th>
                <th>Prescribed Date</th>
                <th>Findings</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading laboratory investigations...
                  </td>
                </tr>
              ) : reports.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                    No lab orders found.
                  </td>
                </tr>
              ) : (
                reports.map((rep) => (
                  <tr key={rep.id}>
                    <td>
                      <strong style={{ color: 'var(--navy-dark)' }}>{rep.reportNumber}</strong>
                    </td>
                    <td>
                      <div style={{ fontWeight: '600' }}>{rep.patient?.user?.name}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{rep.patient?.user?.phone}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: '700' }}>{rep.test?.name}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{rep.test?.sampleRequired}</div>
                    </td>
                    <td>{formatDoctorName(rep.doctor?.user?.name)}</td>
                    <td>{rep.prescribedDate}</td>
                    <td style={{ maxWidth: '200px' }}>
                      {rep.resultValue ? (
                        <div style={{ fontSize: '0.8rem', color: rep.isAbnormal ? '#b91c1c' : '#15803d', fontWeight: '500' }}>
                          {rep.resultValue.slice(0, 45)}...
                        </div>
                      ) : (
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Pending Sample/Test</span>
                      )}
                    </td>
                    <td>
                      <StatusBadge status={rep.status} />
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <button
                        onClick={() => {
                          setResultModal(rep);
                          setResultValue(rep.resultValue || '');
                          setIsAbnormal(rep.isAbnormal || false);
                          setStatus(rep.status === 'ordered' ? 'completed' : rep.status);
                          setTechnicianNotes(rep.technicianNotes || '');
                        }}
                        className="btn btn-secondary btn-sm"
                      >
                        <FileEdit size={14} /> Update Result
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Enter Result Modal */}
      {resultModal && (
        <Modal
          isOpen={true}
          onClose={() => setResultModal(null)}
          title={`Enter Results: ${resultModal.test?.name}`}
        >
          <form onSubmit={handleResultSubmit}>
            <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: '8px', padding: '12px', marginBottom: '1.25rem', fontSize: '0.85rem' }}>
              <div>Patient: <strong>{resultModal.patient?.user?.name}</strong></div>
              <div>Normal Reference Range: <strong>{resultModal.normalRangeSnapshot || resultModal.test?.normalRange}</strong></div>
            </div>

            <div className="form-group">
              <label className="form-label">Investigation Findings / Values *</label>
              <textarea
                className="form-control"
                placeholder="Enter clinical test observations, unit values..."
                value={resultValue}
                onChange={(e) => setResultValue(e.target.value)}
                required
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Investigation Status</label>
                <select
                  className="form-control"
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                >
                  <option value="sample_collected">Sample Collected</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed & Released</option>
                </select>
              </div>

              <div className="form-group" style={{ display: 'flex', alignItems: 'center', marginTop: '1.75rem' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '0.9rem', fontWeight: '600', color: isAbnormal ? '#b91c1c' : 'inherit' }}>
                  <input
                    type="checkbox"
                    checked={isAbnormal}
                    onChange={(e) => setIsAbnormal(e.target.checked)}
                  />
                  <span>Flag as Abnormal / Out-of-Range</span>
                </label>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Technician / Pathologist Remarks</label>
              <input
                type="text"
                className="form-control"
                placeholder="Methodology or notes for attending doctor..."
                value={technicianNotes}
                onChange={(e) => setTechnicianNotes(e.target.value)}
              />
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button
                type="button"
                onClick={() => setResultModal(null)}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={saving}
              >
                {saving ? 'Publishing...' : 'Save & Release Report'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Add Test Catalog Modal */}
      {addTestModal && (
        <Modal
          isOpen={true}
          onClose={() => setAddTestModal(false)}
          title="Add New Diagnostic Test to Catalog"
        >
          <form onSubmit={handleAddTestSubmit}>
            <div className="form-group">
              <label className="form-label">Test Name *</label>
              <input
                type="text"
                className="form-control"
                placeholder="e.g. Thyroid Panel (T3, T4, TSH)"
                value={newTest.name}
                onChange={(e) => setNewTest({ ...newTest, name: e.target.value })}
                required
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Category *</label>
                <select
                  className="form-control"
                  value={newTest.category}
                  onChange={(e) => setNewTest({ ...newTest, category: e.target.value })}
                >
                  <option value="Hematology">Hematology</option>
                  <option value="Biochemistry">Biochemistry</option>
                  <option value="Endocrinology">Endocrinology</option>
                  <option value="Radiology">Radiology</option>
                  <option value="Microbiology">Microbiology</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Standard Charge (₹) *</label>
                <input
                  type="number"
                  className="form-control"
                  value={newTest.standardFee}
                  onChange={(e) => setNewTest({ ...newTest, standardFee: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Normal Physiological Range</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="e.g. 0.4 - 4.0 mIU/L"
                  value={newTest.normalRange}
                  onChange={(e) => setNewTest({ ...newTest, normalRange: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Specimen Sample Required</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="e.g. Blood (Serum), Urine, Swab"
                  value={newTest.sampleRequired}
                  onChange={(e) => setNewTest({ ...newTest, sampleRequired: e.target.value })}
                />
              </div>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button
                type="button"
                onClick={() => setAddTestModal(false)}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={saving}
              >
                {saving ? 'Adding...' : 'Add Test to Catalog'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
