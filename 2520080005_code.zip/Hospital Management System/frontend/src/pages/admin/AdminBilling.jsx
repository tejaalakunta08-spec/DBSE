import React, { useState, useEffect } from 'react';
import api from '../../api/client';
import Modal from '../../components/Modal';
import StatusBadge from '../../components/StatusBadge';
import { useNotifications } from '../../context/NotificationContext';
import {
  CreditCard,
  Shield,
  CheckCircle,
  XCircle,
  FileCheck,
  Search,
  DollarSign
} from 'lucide-react';

export default function AdminBilling() {
  const { showToast } = useNotifications();
  const [bills, setBills] = useState([]);
  const [revenueStats, setRevenueStats] = useState({ totalRevenue: '0.00', pendingDues: '0.00' });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Adjudication Modal
  const [adjudicateModal, setAdjudicateModal] = useState(null); // claim
  const [claimStatus, setClaimStatus] = useState('approved');
  const [approvedAmount, setApprovedAmount] = useState('');
  const [remarks, setRemarks] = useState('');
  const [saving, setSaving] = useState(false);

  const fetchBills = async () => {
    try {
      setLoading(true);
      const res = await api.get('/billing');
      if (res.data.success) {
        setBills(res.data.data.bills || []);
        setRevenueStats({
          totalRevenue: res.data.data.totalRevenue,
          pendingDues: res.data.data.pendingDues
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBills();
  }, []);

  const handleAdjudicateSubmit = async (e) => {
    e.preventDefault();
    if (!adjudicateModal) return;

    try {
      setSaving(true);
      const res = await api.put(`/billing/claim/${adjudicateModal.id}/adjudicate`, {
        claimStatus,
        approvedAmount: parseFloat(approvedAmount),
        remarks
      });

      if (res.data.success) {
        showToast(`Insurance claim ${claimStatus.toUpperCase()}! Bill balance adjusted.`);
        setAdjudicateModal(null);
        fetchBills();
      }
    } catch (err) {
      showToast('Adjudication failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const filtered = bills.filter(b => {
    return !search ||
      b.billNumber.toLowerCase().includes(search.toLowerCase()) ||
      b.patient?.user?.name.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Hospital Billing & Insurance Claims</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Itemized consultation invoices, patient fee settlements, and third-party insurance adjudication.</p>
        </div>
      </div>

      {/* Revenue Stats Banner */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
        <div className="stat-card" style={{ borderLeft: '4px solid #10b981' }}>
          <div>
            <div className="stat-label">Total Revenue Collected</div>
            <div className="stat-value" style={{ color: '#059669' }}>₹{parseFloat(revenueStats.totalRevenue).toLocaleString()}</div>
            <div className="stat-trend" style={{ color: '#10b981' }}>Cleared payments</div>
          </div>
        </div>
        <div className="stat-card" style={{ borderLeft: '4px solid #ef4444' }}>
          <div>
            <div className="stat-label">Total Outstanding Dues</div>
            <div className="stat-value" style={{ color: '#dc2626' }}>₹{parseFloat(revenueStats.pendingDues).toLocaleString()}</div>
            <div className="stat-trend" style={{ color: '#ef4444' }}>Unpaid patient balances</div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem', display: 'flex', justifyContent: 'flex-end' }}>
        <div style={{ position: 'relative', width: '320px' }}>
          <Search size={16} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
          <input
            type="text"
            className="form-control"
            style={{ paddingLeft: '34px', fontSize: '0.85rem' }}
            placeholder="Search invoice # or patient name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Invoices & Insurance Claims Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Patient Details</th>
                <th>Consultation</th>
                <th>Pharmacy</th>
                <th>Diagnostics</th>
                <th>Total</th>
                <th>Paid</th>
                <th>Balance</th>
                <th>Status</th>
                <th>Insurance Claim</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="11" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading invoices...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan="11" style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                    No invoices match criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((b) => (
                  <tr key={b.id}>
                    <td>
                      <strong style={{ color: 'var(--navy-dark)' }}>{b.billNumber}</strong>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{b.billDate}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: '600' }}>{b.patient?.user?.name}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{b.patient?.patientCode}</div>
                    </td>
                    <td>₹{parseFloat(b.consultationFee).toFixed(0)}</td>
                    <td>₹{parseFloat(b.medicineFee).toFixed(0)}</td>
                    <td>₹{parseFloat(b.labFee).toFixed(0)}</td>
                    <td>
                      <strong>₹{parseFloat(b.totalAmount).toFixed(2)}</strong>
                    </td>
                    <td>₹{parseFloat(b.paidAmount).toFixed(2)}</td>
                    <td>
                      <strong style={{ color: parseFloat(b.balanceAmount) > 0 ? '#ef4444' : '#10b981' }}>
                        ₹{parseFloat(b.balanceAmount).toFixed(2)}
                      </strong>
                    </td>
                    <td>
                      <StatusBadge status={b.paymentStatus} />
                    </td>
                    <td>
                      {b.insuranceClaim ? (
                        <div>
                          <StatusBadge status={b.insuranceClaim.claimStatus} />
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                            {b.insuranceClaim.providerName}
                          </div>
                        </div>
                      ) : (
                        <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Direct Cash</span>
                      )}
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      {b.insuranceClaim && b.insuranceClaim.claimStatus === 'submitted' && (
                        <button
                          onClick={() => {
                            setAdjudicateModal(b.insuranceClaim);
                            setApprovedAmount(b.insuranceClaim.claimAmount);
                            setClaimStatus('approved');
                            setRemarks('');
                          }}
                          className="btn btn-secondary btn-sm"
                          style={{ borderColor: 'var(--primary)', color: 'var(--primary)' }}
                        >
                          <Shield size={14} /> Review Claim
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Claim Adjudication Modal */}
      {adjudicateModal && (
        <Modal
          isOpen={true}
          onClose={() => setAdjudicateModal(null)}
          title={`Adjudicate Claim #${adjudicateModal.claimNumber}`}
        >
          <form onSubmit={handleAdjudicateSubmit}>
            <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: '8px', padding: '12px', marginBottom: '1.25rem', fontSize: '0.85rem' }}>
              <div>Provider: <strong>{adjudicateModal.providerName}</strong></div>
              <div>Policy Number: <strong>{adjudicateModal.policyNumber}</strong></div>
              <div>Claimed Amount: <strong>₹{parseFloat(adjudicateModal.claimAmount).toFixed(2)}</strong></div>
            </div>

            <div className="form-group">
              <label className="form-label">Adjudication Decision</label>
              <select
                className="form-control"
                value={claimStatus}
                onChange={(e) => setClaimStatus(e.target.value)}
              >
                <option value="approved">Approve Claim & Settle Balance</option>
                <option value="rejected">Reject Claim</option>
                <option value="in_review">Keep In Review</option>
              </select>
            </div>

            {claimStatus === 'approved' && (
              <div className="form-group">
                <label className="form-label">Approved Reimbursement Amount (₹) *</label>
                <input
                  type="number"
                  step="0.01"
                  className="form-control"
                  value={approvedAmount}
                  onChange={(e) => setApprovedAmount(e.target.value)}
                  required
                />
              </div>
            )}

            <div className="form-group">
              <label className="form-label">Adjudication Remarks / Audit Notes</label>
              <textarea
                className="form-control"
                placeholder="Reason for approval/rejection..."
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
              />
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button
                type="button"
                onClick={() => setAdjudicateModal(null)}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={saving}
              >
                {saving ? 'Processing...' : 'Submit Decision'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
