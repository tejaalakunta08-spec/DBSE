import React, { useState, useEffect } from 'react';
import api from '../../api/client';
import StatusBadge from '../../components/StatusBadge';
import { formatDoctorName } from '../../utils/formatters';
import {
  Clock,
  RefreshCw,
  Search,
  Filter,
  UserCheck
} from 'lucide-react';

export default function AdminQueue() {
  const [tokens, setTokens] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchQueue = async () => {
    try {
      setLoading(true);
      const url = selectedDoctorId ? `/queue/live?doctorId=${selectedDoctorId}` : '/queue/live';
      const [qRes, docRes] = await Promise.all([
        api.get(url),
        api.get('/doctors')
      ]);

      if (qRes.data.success) {
        setTokens(qRes.data.data.tokens || []);
      }
      if (docRes.data.success) {
        setDoctors(docRes.data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQueue();
    const interval = setInterval(fetchQueue, 15000);
    return () => clearInterval(interval);
  }, [selectedDoctorId]);

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Central Hospital OPD Queue Board</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Hospital-wide real-time outpatient waiting token oversight.</p>
        </div>

        <button onClick={fetchQueue} className="btn btn-secondary btn-sm">
          <RefreshCw size={16} />
          <span>Refresh Live Queue</span>
        </button>
      </div>

      <div className="card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <span style={{ fontSize: '0.85rem', fontWeight: '700' }}>Filter by Doctor:</span>
        <select
          className="form-control"
          style={{ width: '280px', padding: '6px 10px', fontSize: '0.85rem' }}
          value={selectedDoctorId}
          onChange={(e) => setSelectedDoctorId(e.target.value)}
        >
          <option value="">All Hospital Doctors & Departments</option>
          {doctors.map((d) => (
            <option key={d.id} value={d.id}>
              {formatDoctorName(d.user?.name)} ({d.department})
            </option>
          ))}
        </select>
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Token #</th>
                <th>Patient Details</th>
                <th>Assigned Doctor</th>
                <th>Department</th>
                <th>Time Slot</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading hospital queue...
                  </td>
                </tr>
              ) : tokens.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                    No queue tokens active for today.
                  </td>
                </tr>
              ) : (
                tokens.map((tok) => (
                  <tr key={tok.id} style={{ backgroundColor: tok.status === 'serving' ? '#f0fdf4' : 'transparent' }}>
                    <td>
                      <span style={{ fontSize: '1.1rem', fontWeight: '800', color: tok.status === 'serving' ? '#059669' : 'var(--navy-dark)' }}>
                        #{tok.tokenNumber}
                      </span>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{tok.tokenCode}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: '600' }}>{tok.patient?.user?.name}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{tok.patient?.user?.phone}</div>
                    </td>
                    <td>{formatDoctorName(tok.doctor?.user?.name)}</td>
                    <td>
                      <span className="badge badge-primary">{tok.doctor?.department}</span>
                    </td>
                    <td>{tok.estimatedTime || '-'}</td>
                    <td>
                      <StatusBadge status={tok.status} />
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
