import React, { useState, useEffect } from 'react';
import api from '../../api/client';
import Modal from '../../components/Modal';
import StatusBadge from '../../components/StatusBadge';
import { formatDoctorName } from '../../utils/formatters';
import { useNotifications } from '../../context/NotificationContext';
import {
  UserCheck,
  Plus,
  Search,
  Mail,
  Phone,
  DollarSign,
  Building,
  CheckCircle
} from 'lucide-react';

export default function AdminDoctors() {
  const { showToast } = useNotifications();
  const [doctors, setDoctors] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState('All');

  // New Doctor Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: 'Doctor@123',
    phone: '',
    department: 'Cardiology',
    specialization: '',
    qualification: 'MBBS, MD',
    experienceYears: 5,
    consultationFee: 700,
    roomNumber: 'OPD-101',
    bio: ''
  });

  const fetchDoctors = async () => {
    try {
      setLoading(true);
      const res = await api.get('/doctors');
      if (res.data.success) {
        setDoctors(res.data.data);
      }
      const deptRes = await api.get('/doctors/departments');
      if (deptRes.data.success) {
        setDepartments(deptRes.data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDoctors();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setSubmitting(true);
      const res = await api.post('/auth/register-doctor', formData);
      if (res.data.success) {
        showToast('New doctor registered successfully with default schedule!');
        setIsModalOpen(false);
        setFormData({
          name: '',
          email: '',
          password: 'Doctor@123',
          phone: '',
          department: 'Cardiology',
          specialization: '',
          qualification: 'MBBS, MD',
          experienceYears: 5,
          consultationFee: 700,
          roomNumber: 'OPD-101',
          bio: ''
        });
        fetchDoctors();
      }
    } catch (err) {
      showToast(err.response?.data?.message || 'Failed to register doctor', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = doctors.filter(d => {
    const matchDept = selectedDept === 'All' || d.department === selectedDept;
    const matchSearch = !search ||
      d.user?.name.toLowerCase().includes(search.toLowerCase()) ||
      d.specialization.toLowerCase().includes(search.toLowerCase()) ||
      d.doctorCode.toLowerCase().includes(search.toLowerCase());
    return matchDept && matchSearch;
  });

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Doctors & Clinical Staff Directory</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Manage hospital physicians, clinical specialties, and consulting fees.</p>
        </div>

        <button onClick={() => setIsModalOpen(true)} className="btn btn-primary">
          <Plus size={18} />
          <span>Register New Doctor</span>
        </button>
      </div>

      {/* Toolbar */}
      <div className="card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem', display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <span style={{ fontSize: '0.85rem', fontWeight: '600' }}>Filter Dept:</span>
          <select
            className="form-control"
            style={{ width: '200px', padding: '6px 10px', fontSize: '0.85rem' }}
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
          >
            <option value="All">All Departments</option>
            {departments.map((d, i) => (
              <option key={i} value={d}>{d}</option>
            ))}
          </select>
        </div>

        <div style={{ position: 'relative', minWidth: '240px' }}>
          <Search size={16} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
          <input
            type="text"
            className="form-control"
            style={{ paddingLeft: '34px', fontSize: '0.85rem' }}
            placeholder="Search doctor by name or specialty..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Doctor Code</th>
                <th>Physician Name</th>
                <th>Department</th>
                <th>Specialization & Qualification</th>
                <th>Room #</th>
                <th>OPD Fee</th>
                <th>Contact</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading doctors...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                    No doctors found matching filters.
                  </td>
                </tr>
              ) : (
                filtered.map((doc) => (
                  <tr key={doc.id}>
                    <td>
                      <strong style={{ color: 'var(--navy-dark)' }}>{doc.doctorCode}</strong>
                    </td>
                    <td>
                      <div style={{ fontWeight: '700' }}>{formatDoctorName(doc.user?.name)}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{doc.user?.email}</div>
                    </td>
                    <td>
                      <span className="badge badge-primary">{doc.department}</span>
                    </td>
                    <td>
                      <div style={{ fontWeight: '500' }}>{doc.specialization}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{doc.qualification} ({doc.experienceYears} yrs)</div>
                    </td>
                    <td>{doc.roomNumber || 'OPD-101'}</td>
                    <td>
                      <strong>₹{parseFloat(doc.consultationFee).toFixed(0)}</strong>
                    </td>
                    <td>{doc.user?.phone || 'N/A'}</td>
                    <td>
                      <StatusBadge status={doc.user?.status || 'active'} />
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Register Doctor Modal */}
      {isModalOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsModalOpen(false)}
          title="Register New Hospital Doctor"
          maxWidth="700px"
        >
          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Full Name *</label>
                <input
                  type="text"
                  name="name"
                  className="form-control"
                  placeholder="e.g. Dr. Rajesh Kumar"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Email Address *</label>
                <input
                  type="email"
                  name="email"
                  className="form-control"
                  placeholder="doctor@hospital.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Password *</label>
                <input
                  type="password"
                  name="password"
                  className="form-control"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Phone Number *</label>
                <input
                  type="tel"
                  name="phone"
                  className="form-control"
                  placeholder="+91 98765 43210"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Department *</label>
                <select
                  name="department"
                  className="form-control"
                  value={formData.department}
                  onChange={handleChange}
                >
                  <option value="Cardiology">Cardiology</option>
                  <option value="Neurology">Neurology</option>
                  <option value="Orthopedics">Orthopedics</option>
                  <option value="Pediatrics">Pediatrics</option>
                  <option value="General Medicine">General Medicine</option>
                  <option value="Dermatology">Dermatology</option>
                  <option value="Radiology">Radiology</option>
                  <option value="ENT">ENT</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Specialization *</label>
                <input
                  type="text"
                  name="specialization"
                  className="form-control"
                  placeholder="e.g. Interventional Cardiology"
                  value={formData.specialization}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Qualifications</label>
                <input
                  type="text"
                  name="qualification"
                  className="form-control"
                  placeholder="MBBS, MD, DM"
                  value={formData.qualification}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Experience (Years)</label>
                <input
                  type="number"
                  name="experienceYears"
                  className="form-control"
                  value={formData.experienceYears}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Consultation Fee (₹) *</label>
                <input
                  type="number"
                  name="consultationFee"
                  className="form-control"
                  value={formData.consultationFee}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Assigned Room Number</label>
                <input
                  type="text"
                  name="roomNumber"
                  className="form-control"
                  placeholder="e.g. OPD-104"
                  value={formData.roomNumber}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Professional Bio / Profile Summary</label>
              <textarea
                name="bio"
                className="form-control"
                placeholder="Doctor's research background, clinical interests..."
                value={formData.bio}
                onChange={handleChange}
              />
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={submitting}
              >
                {submitting ? 'Registering...' : 'Register Doctor'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
