import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api/client';
import StatCard from '../../components/StatCard';
import StatusBadge from '../../components/StatusBadge';
import { formatDoctorName } from '../../utils/formatters';
import {
  Users,
  UserCheck,
  Calendar,
  CreditCard,
  Pill,
  FlaskConical,
  Clock,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Plus
} from 'lucide-react';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      try {
        const res = await api.get('/admin/stats');
        if (res.data.success) {
          setStats(res.data.data);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadStats();
  }, []);

  if (loading) {
    return (
      <div className="page-body" style={{ textAlign: 'center', padding: '3rem' }}>
        <p style={{ color: 'var(--text-muted)' }}>Loading executive hospital dashboard...</p>
      </div>
    );
  }

  return (
    <div className="page-body">
      {/* Welcome Banner */}
      <div
        style={{
          background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
          borderRadius: 'var(--radius-lg)',
          padding: '2rem',
          color: 'white',
          marginBottom: '2rem',
          boxShadow: 'var(--shadow-md)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '1.5rem'
        }}
      >
        <div>
          <span className="badge" style={{ backgroundColor: '#8b5cf6', color: 'white', marginBottom: '8px' }}>
            Hospital Master Administration
          </span>
          <h1 style={{ color: 'white', fontSize: '1.85rem', margin: '4px 0 8px' }}>
            Executive Operations Command Center
          </h1>
          <p style={{ color: '#94a3b8', fontSize: '0.95rem' }}>
            Live clinical KPIs, outpatient department token flows, pharmacy stock levels, and revenue monitoring.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <Link to="/admin/doctors" className="btn btn-primary" style={{ backgroundColor: 'var(--primary)' }}>
            <Plus size={18} />
            <span>Add Doctor</span>
          </Link>
          <Link to="/admin/pharmacy" className="btn btn-secondary" style={{ backgroundColor: 'white', color: 'var(--navy-dark)' }}>
            <Pill size={18} />
            <span>Pharmacy Stock</span>
          </Link>
        </div>
      </div>

      {/* Low Stock Warning Banner */}
      {stats?.lowStockCount > 0 && (
        <div style={{ backgroundColor: '#fffbeb', border: '1px solid #fde68a', borderRadius: 'var(--radius-md)', padding: '12px 18px', marginBottom: '2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#92400e' }}>
            <AlertTriangle size={20} style={{ color: '#f59e0b', flexShrink: 0 }} />
            <span>
              <strong>Inventory Alert:</strong> {stats.lowStockCount} essential medication(s) have fallen below their safety reorder thresholds!
            </span>
          </div>
          <Link to="/admin/pharmacy?lowStock=true" className="btn btn-sm" style={{ backgroundColor: '#f59e0b', color: 'white' }}>
            Restock Inventory
          </Link>
        </div>
      )}

      {/* 6 KPI Stat Cards */}
      <div className="stat-grid">
        <StatCard
          label="Total Registered Patients"
          value={stats?.totalPatients || 0}
          icon={Users}
          color="#0284c7"
          subtext="EHR records active"
        />
        <StatCard
          label="Specialist Doctors"
          value={stats?.totalDoctors || 0}
          icon={UserCheck}
          color="#0d9488"
          subtext="Across all departments"
        />
        <StatCard
          label="Today's Appointments"
          value={stats?.todayAppointmentsCount || 0}
          icon={Calendar}
          color="#8b5cf6"
          subtext="Outpatient bookings"
        />
        <StatCard
          label="Total Hospital Revenue"
          value={`₹${parseFloat(stats?.totalRevenue || 0).toLocaleString()}`}
          icon={CreditCard}
          color="#10b981"
          subtext="Consultation + Meds + Lab"
        />
        <StatCard
          label="Active OPD Queue"
          value={stats?.activeQueueCount || 0}
          icon={Clock}
          color="#f59e0b"
          subtext="Waiting & serving today"
        />
        <StatCard
          label="Pending Lab Reports"
          value={stats?.pendingLabTestsCount || 0}
          icon={FlaskConical}
          color="#06b6d4"
          subtext="Diagnostics in progress"
        />
      </div>

      {/* Recent Appointments & System Status */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="card-header" style={{ padding: '1.25rem 1.5rem', margin: 0, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 className="card-title">Recent Outpatient Consultations</h3>
          <Link to="/admin/appointments" style={{ fontSize: '0.85rem', color: 'var(--primary)', fontWeight: '600' }}>
            View All Appointments
          </Link>
        </div>

        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Appointment #</th>
                <th>Patient Name</th>
                <th>Attending Doctor</th>
                <th>Specialty</th>
                <th>Date & Slot</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {stats?.recentAppointments?.map((apt) => (
                <tr key={apt.id}>
                  <td>
                    <strong>{apt.appointmentNumber}</strong>
                  </td>
                  <td>{apt.patient?.user?.name}</td>
                  <td>{formatDoctorName(apt.doctor?.user?.name)}</td>
                  <td>
                    <span className="badge badge-primary">{apt.doctor?.department}</span>
                  </td>
                  <td>
                    {apt.appointmentDate} <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>({apt.timeSlot})</span>
                  </td>
                  <td>
                    <StatusBadge status={apt.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
