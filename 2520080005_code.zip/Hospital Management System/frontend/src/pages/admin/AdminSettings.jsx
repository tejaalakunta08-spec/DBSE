import React, { useState } from 'react';
import api from '../../api/client';
import { useNotifications } from '../../context/NotificationContext';
import {
  Settings,
  Send,
  MessageSquare,
  CheckCircle,
  AlertCircle,
  Database,
  Shield,
  Server
} from 'lucide-react';

export default function AdminSettings() {
  const { showToast } = useNotifications();
  const [phoneNumber, setPhoneNumber] = useState('+919876543210');
  const [smsMessage, setSmsMessage] = useState('MedCare Hospital: Test SMS notification. Your OPD appointment is confirmed.');
  const [testingSms, setTestingSms] = useState(false);
  const [testResult, setTestResult] = useState(null);

  const handleTestSms = async (e) => {
    e.preventDefault();
    try {
      setTestingSms(true);
      setTestResult(null);
      const res = await api.post('/admin/test-sms', {
        phoneNumber,
        message: smsMessage
      });
      setTestResult(res.data);
      showToast(res.data.message || 'SMS test executed!');
    } catch (err) {
      showToast(err.response?.data?.message || 'SMS test failed', 'error');
    } finally {
      setTestingSms(false);
    }
  };

  return (
    <div className="page-body">
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>System Settings & Twilio SMS Configuration</h1>
        <p style={{ color: 'var(--text-secondary)' }}>
          Manage communications, database parameters, and third-party SMS delivery settings.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem', alignItems: 'start' }}>
        {/* Twilio SMS Test Card */}
        <div className="card" style={{ padding: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '1.25rem' }}>
            <div style={{ width: '42px', height: '42px', borderRadius: '10px', backgroundColor: '#e0f2fe', color: '#0284c7', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <MessageSquare size={22} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.25rem', color: 'var(--navy-dark)' }}>Twilio SMS Dispatch Tool</h3>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                Test automated SMS delivery for appointment confirmations and OPD queue alerts.
              </p>
            </div>
          </div>

          <form onSubmit={handleTestSms}>
            <div className="form-group">
              <label className="form-label">Recipient Mobile Number (E.164 Format) *</label>
              <input
                type="text"
                className="form-control"
                placeholder="+919876543210"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">SMS Alert Body *</label>
              <textarea
                className="form-control"
                placeholder="Enter SMS alert text..."
                value={smsMessage}
                onChange={(e) => setSmsMessage(e.target.value)}
                required
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              style={{ width: '100%' }}
              disabled={testingSms}
            >
              <Send size={16} />
              <span>{testingSms ? 'Transmitting SMS...' : 'Dispatch Test SMS Notification'}</span>
            </button>
          </form>

          {testResult && (
            <div
              style={{
                marginTop: '1.5rem',
                backgroundColor: testResult.success ? '#f0fdf4' : '#fef2f2',
                border: `1px solid ${testResult.success ? '#bbf7d0' : '#fecaca'}`,
                borderRadius: '8px',
                padding: '14px',
                fontSize: '0.85rem'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: '700', color: testResult.success ? '#15803d' : '#b91c1c', marginBottom: '4px' }}>
                {testResult.success ? <CheckCircle size={18} /> : <AlertCircle size={18} />}
                <span>{testResult.message}</span>
              </div>
              <div style={{ color: 'var(--text-secondary)' }}>
                Transmission Mode: <strong>{testResult.result?.mode || 'simulated'}</strong><br />
                Message SID: <code>{testResult.result?.sid || 'N/A'}</code>
              </div>
            </div>
          )}
        </div>

        {/* System & Database Architecture Info */}
        <div className="card" style={{ padding: '2rem' }}>
          <h3 style={{ fontSize: '1.25rem', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Server size={20} style={{ color: 'var(--primary)' }} /> Architecture & Environment
          </h3>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: '8px', padding: '12px 14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: '700', fontSize: '0.9rem', color: 'var(--navy-dark)', marginBottom: '4px' }}>
                <Database size={16} style={{ color: '#0d9488' }} /> Database Engine
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                MySQL 8.0 with Sequelize ORM • 15+ normalized relational tables (PK/FK/Indexes)
              </div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: '8px', padding: '12px 14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: '700', fontSize: '0.9rem', color: 'var(--navy-dark)', marginBottom: '4px' }}>
                <Shield size={16} style={{ color: '#8b5cf6' }} /> Security & Authentication
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                JSON Web Token (JWT) with bcrypt salt rounds (10) • Role-Based Access Control (RBAC)
              </div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: '8px', padding: '12px 14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: '700', fontSize: '0.9rem', color: 'var(--navy-dark)', marginBottom: '4px' }}>
                <MessageSquare size={16} style={{ color: '#0284c7' }} /> Twilio SMS Integration
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                Supports Live Twilio API keys from <code>backend/.env</code> with instant console/MySQL fallback logger for academic demos.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
