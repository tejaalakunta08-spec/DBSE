import React, { useState, useEffect } from 'react';
import api from '../../api/client';
import Modal from '../../components/Modal';
import StatusBadge from '../../components/StatusBadge';
import {
  Users,
  Search,
  Eye,
  HeartPulse,
  Shield,
  Phone,
  Calendar,
  FileText
} from 'lucide-react';

export default function AdminPatients() {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedPatient, setSelectedPatient] = useState(null);

  const fetchPatients = async () => {
    try {
      setLoading(true);
      const res = await api.get('/patients');
      if (res.data.success) {
        setPatients(res.data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPatients();
  }, []);

  const filtered = patients.filter(p => {
    return !search ||
      p.user?.name.toLowerCase().includes(search.toLowerCase()) ||
      p.patientCode.toLowerCase().includes(search.toLowerCase()) ||
      p.user?.phone?.includes(search) ||
      p.user?.email.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Electronic Patient Registry</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Master directory of registered hospital patients, EHR profiles, and medical histories.</p>
        </div>
      </div>

      <div className="card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem', display: 'flex', justifyContent: 'flex-end' }}>
        <div style={{ position: 'relative', width: '320px' }}>
          <Search size={16} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
          <input
            type="text"
            className="form-control"
            style={{ paddingLeft: '34px', fontSize: '0.85rem' }}
            placeholder="Search patient by name, code, or phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Patient Code</th>
                <th>Full Name</th>
                <th>Contact</th>
                <th>Demographics</th>
                <th>Blood Group</th>
                <th>Emergency Contact</th>
                <th>Insurance Provider</th>
                <th style={{ textAlign: 'right' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading patient records...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                    No patients found.
                  </td>
                </tr>
              ) : (
                filtered.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <strong style={{ color: 'var(--navy-dark)' }}>{p.patientCode}</strong>
                    </td>
                    <td>
                      <div style={{ fontWeight: '600' }}>{p.user?.name}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{p.user?.email}</div>
                    </td>
                    <td>{p.user?.phone || 'N/A'}</td>
                    <td>
                      <span style={{ textTransform: 'capitalize' }}>{p.gender || 'N/A'}</span>
                      {p.dob && <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block' }}>DOB: {p.dob}</span>}
                    </td>
                    <td>
                      <span className="badge badge-neutral" style={{ fontWeight: '700' }}>{p.bloodGroup || 'N/A'}</span>
                    </td>
                    <td>
                      <div>{p.emergencyContactName || 'N/A'}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{p.emergencyContactPhone}</div>
                    </td>
                    <td>
                      {p.insuranceProvider ? (
                        <div>
                          <span style={{ fontWeight: '600' }}>{p.insuranceProvider}</span>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{p.insurancePolicyNumber}</div>
                        </div>
                      ) : (
                        <span style={{ color: 'var(--text-muted)' }}>Direct Cash</span>
                      )}
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <button
                        onClick={() => setSelectedPatient(p)}
                        className="btn btn-secondary btn-sm"
                      >
                        <Eye size={14} /> View EHR
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Patient Detail Modal */}
      {selectedPatient && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedPatient(null)}
          title={`Electronic Health Record (EHR) - ${selectedPatient.user?.name}`}
          maxWidth="650px"
        >
          <div>
            <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: '8px', padding: '14px', marginBottom: '1.25rem' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px', fontSize: '0.85rem' }}>
                <div>Patient Code: <strong>{selectedPatient.patientCode}</strong></div>
                <div>Blood Group: <strong>{selectedPatient.bloodGroup || 'N/A'}</strong></div>
                <div>Gender: <strong>{selectedPatient.gender}</strong></div>
                <div>Date of Birth: <strong>{selectedPatient.dob || 'N/A'}</strong></div>
                <div>Email: <strong>{selectedPatient.user?.email}</strong></div>
                <div>Phone: <strong>{selectedPatient.user?.phone}</strong></div>
              </div>
            </div>

            <div style={{ marginBottom: '1rem', fontSize: '0.875rem' }}>
              <strong>Residential Address:</strong>
              <p style={{ color: 'var(--text-secondary)', marginTop: '2px' }}>
                {selectedPatient.address || 'No residential address on file.'}
              </p>
            </div>

            <div style={{ marginBottom: '1rem', fontSize: '0.875rem' }}>
              <strong>Allergies:</strong>
              <p style={{ color: selectedPatient.allergies ? '#991b1b' : 'var(--text-secondary)', marginTop: '2px' }}>
                {selectedPatient.allergies || 'No known drug allergies reported.'}
              </p>
            </div>

            <div style={{ marginBottom: '1rem', fontSize: '0.875rem' }}>
              <strong>Chronic Medical Conditions:</strong>
              <p style={{ color: selectedPatient.chronicConditions ? '#92400e' : 'var(--text-secondary)', marginTop: '2px' }}>
                {selectedPatient.chronicConditions || 'None reported.'}
              </p>
            </div>

            <div style={{ marginBottom: '1.5rem', fontSize: '0.875rem', backgroundColor: '#f0fdfa', border: '1px solid #ccfbf1', borderRadius: '8px', padding: '10px 12px' }}>
              <strong>Insurance Policy:</strong>
              <p style={{ color: '#0f766e', marginTop: '2px' }}>
                Provider: {selectedPatient.insuranceProvider || 'Self-pay'} | Policy No: {selectedPatient.insurancePolicyNumber || 'N/A'}
              </p>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <button
                type="button"
                onClick={() => setSelectedPatient(null)}
                className="btn btn-secondary"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
