import React, { useState, useEffect } from 'react';
import api from '../../api/client';
import StatusBadge from '../../components/StatusBadge';
import { formatDoctorName } from '../../utils/formatters';
import { useNotifications } from '../../context/NotificationContext';
import {
  Calendar,
  Search,
  CheckCircle,
  XCircle,
  Filter
} from 'lucide-react';

export default function AdminAppointments() {
  const { showToast } = useNotifications();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');

  const fetchAppointments = async () => {
    try {
      setLoading(true);
      const res = await api.get('/appointments');
      if (res.data.success) {
        setAppointments(res.data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  const handleUpdateStatus = async (id, status) => {
    try {
      const res = await api.put(`/appointments/${id}/status`, { status });
      if (res.data.success) {
        showToast(`Appointment status updated to ${status}`);
        fetchAppointments();
      }
    } catch (e) {
      showToast('Status update failed', 'error');
    }
  };

  const filtered = appointments.filter(a => {
    const matchStatus = statusFilter === 'all' || a.status === statusFilter;
    const matchSearch = !search ||
      a.appointmentNumber.toLowerCase().includes(search.toLowerCase()) ||
      a.patient?.user?.name.toLowerCase().includes(search.toLowerCase()) ||
      a.doctor?.user?.name.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Hospital-Wide Appointments Monitor</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Master outpatient booking registry across all clinical departments.</p>
        </div>
      </div>

      <div className="card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem', display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          {['all', 'confirmed', 'in_consultation', 'completed', 'cancelled'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className="btn btn-sm"
              style={{
                backgroundColor: statusFilter === st ? 'var(--navy-dark)' : 'var(--bg-subtle)',
                color: statusFilter === st ? 'white' : 'var(--text-secondary)',
                fontWeight: '600',
                textTransform: 'capitalize'
              }}
            >
              {st.replace('_', ' ')}
            </button>
          ))}
        </div>

        <div style={{ position: 'relative', width: '280px' }}>
          <Search size={16} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
          <input
            type="text"
            className="form-control"
            style={{ paddingLeft: '34px', fontSize: '0.85rem' }}
            placeholder="Search appointment # or patient..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Appointment #</th>
                <th>Patient Name</th>
                <th>Attending Doctor</th>
                <th>Department</th>
                <th>Date & Slot</th>
                <th>OPD Token</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Override Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading appointments...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                    No appointments match criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((apt) => (
                  <tr key={apt.id}>
                    <td>
                      <strong style={{ color: 'var(--navy-dark)' }}>{apt.appointmentNumber}</strong>
                    </td>
                    <td>
                      <div style={{ fontWeight: '600' }}>{apt.patient?.user?.name}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{apt.patient?.user?.phone}</div>
                    </td>
                    <td>{formatDoctorName(apt.doctor?.user?.name)}</td>
                    <td>
                      <span className="badge badge-primary">{apt.doctor?.department}</span>
                    </td>
                    <td>
                      <div>{apt.appointmentDate}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{apt.timeSlot}</div>
                    </td>
                    <td>
                      {apt.queueToken ? `#${apt.queueToken.tokenNumber}` : '-'}
                    </td>
                    <td>
                      <StatusBadge status={apt.status} />
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <select
                        className="form-control"
                        style={{ padding: '4px 8px', fontSize: '0.8rem', width: '130px', display: 'inline-block' }}
                        value={apt.status}
                        onChange={(e) => handleUpdateStatus(apt.id, e.target.value)}
                      >
                        <option value="confirmed">Confirmed</option>
                        <option value="in_consultation">In Consultation</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
