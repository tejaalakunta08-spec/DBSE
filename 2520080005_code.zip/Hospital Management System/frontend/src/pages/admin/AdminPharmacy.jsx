import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import api from '../../api/client';
import Modal from '../../components/Modal';
import StatusBadge from '../../components/StatusBadge';
import { useNotifications } from '../../context/NotificationContext';
import {
  Pill,
  Plus,
  Search,
  AlertTriangle,
  RefreshCw,
  Archive,
  ArrowDownCircle,
  Package
} from 'lucide-react';

export default function AdminPharmacy() {
  const { showToast } = useNotifications();
  const location = useLocation();

  const [medicines, setMedicines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showLowStockOnly, setShowLowStockOnly] = useState(
    new URLSearchParams(location.search).get('lowStock') === 'true'
  );

  // Add Medicine Modal
  const [addModal, setAddModal] = useState(false);
  const [newMed, setNewMed] = useState({
    name: '',
    genericName: '',
    category: 'Antibiotics',
    dosageForm: 'Tablet',
    strength: '500mg',
    unitPrice: 10,
    stockQuantity: 100,
    reorderLevel: 25,
    manufacturer: 'Sun Pharma',
    expiryDate: '2028-06-30'
  });

  // Restock Modal
  const [restockModal, setRestockModal] = useState(null); // medicine object
  const [restockQty, setRestockQty] = useState(50);
  const [saving, setSaving] = useState(false);

  const fetchMedicines = async () => {
    try {
      setLoading(true);
      const res = await api.get(`/pharmacy/medicines${showLowStockOnly ? '?lowStock=true' : ''}`);
      if (res.data.success) {
        setMedicines(res.data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMedicines();
  }, [showLowStockOnly]);

  const handleAddSubmit = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const res = await api.post('/pharmacy/medicines', newMed);
      if (res.data.success) {
        showToast(`Added ${newMed.name} to pharmacy inventory!`);
        setAddModal(false);
        fetchMedicines();
      }
    } catch (err) {
      showToast(err.response?.data?.message || 'Failed to add medicine', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleRestockSubmit = async (e) => {
    e.preventDefault();
    if (!restockModal) return;

    try {
      setSaving(true);
      const res = await api.post(`/pharmacy/medicines/${restockModal.id}/restock`, {
        quantity: restockQty,
        notes: 'Warehouse batch shipment restocking'
      });
      if (res.data.success) {
        showToast(`Restocked ${restockQty} units of ${restockModal.name}!`);
        setRestockModal(null);
        fetchMedicines();
      }
    } catch (err) {
      showToast('Restock failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const filtered = medicines.filter(m => {
    return !search ||
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.genericName?.toLowerCase().includes(search.toLowerCase()) ||
      m.code.toLowerCase().includes(search.toLowerCase()) ||
      m.category.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="page-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.85rem', marginBottom: '0.25rem' }}>Pharmacy & Drug Inventory</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Manage medical stock, reorder thresholds, dispensing records, and batch numbers.</p>
        </div>

        <button onClick={() => setAddModal(true)} className="btn btn-primary">
          <Plus size={18} />
          <span>Add New Drug</span>
        </button>
      </div>

      {/* Filter toolbar */}
      <div className="card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem', display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            onClick={() => setShowLowStockOnly(false)}
            className="btn btn-sm"
            style={{
              backgroundColor: !showLowStockOnly ? 'var(--navy-dark)' : 'var(--bg-subtle)',
              color: !showLowStockOnly ? 'white' : 'var(--text-secondary)'
            }}
          >
            All Inventory
          </button>
          <button
            onClick={() => setShowLowStockOnly(true)}
            className="btn btn-sm"
            style={{
              backgroundColor: showLowStockOnly ? '#ef4444' : 'var(--bg-subtle)',
              color: showLowStockOnly ? 'white' : 'var(--text-secondary)'
            }}
          >
            ⚠️ Low Stock Warnings
          </button>
        </div>

        <div style={{ position: 'relative', width: '300px' }}>
          <Search size={16} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
          <input
            type="text"
            className="form-control"
            style={{ paddingLeft: '34px', fontSize: '0.85rem' }}
            placeholder="Search medicine by name or generic salt..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>Drug Code</th>
                <th>Brand Name</th>
                <th>Generic Name</th>
                <th>Category</th>
                <th>Dosage Form</th>
                <th>Stock Quantity</th>
                <th>Reorder Level</th>
                <th>Unit Price</th>
                <th>Expiry Date</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="10" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                    Loading medicines catalog...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan="10" style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                    No medicines match the criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((med) => {
                  const isLow = med.stockQuantity <= med.reorderLevel;
                  return (
                    <tr key={med.id} style={{ backgroundColor: isLow ? '#fff1f2' : 'transparent' }}>
                      <td>
                        <strong style={{ color: 'var(--navy-dark)' }}>{med.code}</strong>
                      </td>
                      <td>
                        <div style={{ fontWeight: '700' }}>{med.name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{med.manufacturer}</div>
                      </td>
                      <td>{med.genericName || '-'}</td>
                      <td>
                        <span className="badge badge-neutral">{med.category}</span>
                      </td>
                      <td>
                        {med.dosageForm} ({med.strength || '-'})
                      </td>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <span style={{ fontWeight: '800', fontSize: '1rem', color: isLow ? '#dc2626' : 'var(--navy-dark)' }}>
                            {med.stockQuantity}
                          </span>
                          {isLow && (
                            <span className="badge badge-danger" style={{ fontSize: '0.65rem', padding: '2px 5px' }}>
                              LOW
                            </span>
                          )}
                        </div>
                      </td>
                      <td>{med.reorderLevel} units</td>
                      <td>₹{parseFloat(med.unitPrice).toFixed(2)}</td>
                      <td>{med.expiryDate || 'N/A'}</td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          onClick={() => {
                            setRestockModal(med);
                            setRestockQty(50);
                          }}
                          className="btn btn-secondary btn-sm"
                          style={{ borderColor: isLow ? '#ef4444' : 'var(--border-color)', color: isLow ? '#b91c1c' : 'inherit' }}
                        >
                          <ArrowDownCircle size={14} /> Restock
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Medicine Modal */}
      {addModal && (
        <Modal
          isOpen={true}
          onClose={() => setAddModal(false)}
          title="Add Medication to Pharmacy Catalog"
        >
          <form onSubmit={handleAddSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Brand / Trade Name *</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="e.g. Paracetamol 650mg"
                  value={newMed.name}
                  onChange={(e) => setNewMed({ ...newMed, name: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Generic Active Ingredient</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="e.g. Acetaminophen"
                  value={newMed.genericName}
                  onChange={(e) => setNewMed({ ...newMed, genericName: e.target.value })}
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Therapeutic Category *</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="e.g. Analgesics, Antibiotics"
                  value={newMed.category}
                  onChange={(e) => setNewMed({ ...newMed, category: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Dosage Form</label>
                <select
                  className="form-control"
                  value={newMed.dosageForm}
                  onChange={(e) => setNewMed({ ...newMed, dosageForm: e.target.value })}
                >
                  <option value="Tablet">Tablet</option>
                  <option value="Capsule">Capsule</option>
                  <option value="Syrup">Syrup</option>
                  <option value="Injection">Injection</option>
                  <option value="Ointment">Ointment</option>
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Unit Price (₹) *</label>
                <input
                  type="number"
                  step="0.01"
                  className="form-control"
                  value={newMed.unitPrice}
                  onChange={(e) => setNewMed({ ...newMed, unitPrice: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Opening Stock Quantity</label>
                <input
                  type="number"
                  className="form-control"
                  value={newMed.stockQuantity}
                  onChange={(e) => setNewMed({ ...newMed, stockQuantity: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Reorder Warning Level</label>
                <input
                  type="number"
                  className="form-control"
                  value={newMed.reorderLevel}
                  onChange={(e) => setNewMed({ ...newMed, reorderLevel: e.target.value })}
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Manufacturer</label>
                <input
                  type="text"
                  className="form-control"
                  value={newMed.manufacturer}
                  onChange={(e) => setNewMed({ ...newMed, manufacturer: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Expiry Date</label>
                <input
                  type="date"
                  className="form-control"
                  value={newMed.expiryDate}
                  onChange={(e) => setNewMed({ ...newMed, expiryDate: e.target.value })}
                />
              </div>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button
                type="button"
                onClick={() => setAddModal(false)}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={saving}
              >
                {saving ? 'Saving...' : 'Add Medicine'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Restock Modal */}
      {restockModal && (
        <Modal
          isOpen={true}
          onClose={() => setRestockModal(null)}
          title={`Restock: ${restockModal.name}`}
        >
          <form onSubmit={handleRestockSubmit}>
            <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: '8px', padding: '12px', marginBottom: '1rem', fontSize: '0.85rem' }}>
              <div>Current Stock: <strong>{restockModal.stockQuantity} units</strong></div>
              <div>Safety Threshold: <strong>{restockModal.reorderLevel} units</strong></div>
            </div>

            <div className="form-group">
              <label className="form-label">Quantity to Add (Units) *</label>
              <input
                type="number"
                min="1"
                className="form-control"
                value={restockQty}
                onChange={(e) => setRestockQty(parseInt(e.target.value, 10))}
                required
              />
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button
                type="button"
                onClick={() => setRestockModal(null)}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={saving}
              >
                {saving ? 'Restocking...' : `Add ${restockQty} Units`}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
