import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('hospital_token') || null);
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('hospital_user');
      if (!saved) return null;
      const parsed = JSON.parse(saved);
      return parsed?.user || parsed;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadUser() {
      if (token) {
        try {
          const res = await api.get('/auth/me');
          if (res.data.success) {
            const profile = res.data.data?.user || res.data.data;
            setUser(profile);
            localStorage.setItem('hospital_user', JSON.stringify(profile));
          } else {
            logout();
          }
        } catch (error) {
          console.error('Failed to load user profile with token:', error);
          logout();
        }
      }
    }
    loadUser();
  }, [token]);

  const login = async (email, password) => {
    const res = await api.post('/auth/login', { email, password });
    if (res.data.success) {
      const receivedToken = res.data.data.token;
      const receivedUser = res.data.data.user || res.data.data;
      setToken(receivedToken);
      setUser(receivedUser);
      localStorage.setItem('hospital_token', receivedToken);
      localStorage.setItem('hospital_user', JSON.stringify(receivedUser));
      return receivedUser;
    }
    throw new Error(res.data.message || 'Login failed');
  };

  const register = async (patientData) => {
    const res = await api.post('/auth/register', patientData);
    if (res.data.success) {
      const receivedToken = res.data.data.token;
      const receivedUser = res.data.data.user || res.data.data;
      setToken(receivedToken);
      setUser(receivedUser);
      localStorage.setItem('hospital_token', receivedToken);
      localStorage.setItem('hospital_user', JSON.stringify(receivedUser));
      return receivedUser;
    }
    throw new Error(res.data.message || 'Registration failed');
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('hospital_token');
    localStorage.removeItem('hospital_user');
  };

  const refreshUser = async () => {
    try {
      const res = await api.get('/auth/me');
      if (res.data.success) {
        const profile = res.data.data?.user || res.data.data;
        setUser(profile);
        localStorage.setItem('hospital_user', JSON.stringify(profile));
      }
    } catch (e) {
      console.warn('Could not refresh profile:', e);
    }
  };

  const value = {
    user,
    token,
    loading,
    isAuthenticated: !!user,
    isAdmin: user?.role === 'admin',
    isDoctor: user?.role === 'doctor',
    isPatient: user?.role === 'patient',
    login,
    register,
    logout,
    refreshUser
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
