import React from 'react';

export default function StatCard({ label, value, icon: Icon, color = '#0d9488', trend, subtext }) {
  return (
    <div className="stat-card">
      <div
        className="stat-icon-wrapper"
        style={{
          backgroundColor: `${color}18`,
          color: color
        }}
      >
        {Icon && <Icon size={24} />}
      </div>
      <div className="stat-info">
        <div className="stat-label">{label}</div>
        <div className="stat-value">{value}</div>
        {(trend || subtext) && (
          <div className="stat-trend" style={{ color: trend?.includes('+') ? '#10b981' : '#64748b' }}>
            {trend && <span style={{ fontWeight: '700' }}>{trend} </span>}
            {subtext && <span>{subtext}</span>}
          </div>
        )}
      </div>
    </div>
  );
}
