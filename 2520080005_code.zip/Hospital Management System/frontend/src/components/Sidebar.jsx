import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Calendar,
  CalendarPlus,
  Clock,
  FileText,
  CreditCard,
  FlaskConical,
  UserCheck,
  Users,
  Pill,
  ShieldAlert,
  Settings,
  Stethoscope,
  ClipboardList
} from 'lucide-react';

export default function Sidebar({ isOpen }) {
  const { isAdmin, isDoctor, isPatient } = useAuth();

  const patientNav = [
    { name: 'Dashboard', path: '/patient/dashboard', icon: LayoutDashboard },
    { name: 'Book Appointment', path: '/patient/book', icon: CalendarPlus },
    { name: 'My Appointments', path: '/patient/appointments', icon: Calendar },
    { name: 'Live OPD Queue', path: '/patient/queue', icon: Clock },
    { name: 'Medical Records', path: '/patient/records', icon: FileText },
    { name: 'Bills & Invoices', path: '/patient/billing', icon: CreditCard },
    { name: 'Diagnostic Reports', path: '/patient/lab', icon: FlaskConical }
  ];

  const doctorNav = [
    { name: 'Doctor Dashboard', path: '/doctor/dashboard', icon: LayoutDashboard },
    { name: 'Today’s Appointments', path: '/doctor/appointments', icon: Calendar },
    { name: 'OPD Queue Manager', path: '/doctor/queue', icon: Clock },
    { name: 'Consultation Room', path: '/doctor/consultation', icon: Stethoscope },
    { name: 'Patient Directory', path: '/doctor/patients', icon: Users },
    { name: 'OPD Schedule', path: '/doctor/schedule', icon: Settings }
  ];

  const adminNav = [
    { name: 'Overview Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
    { name: 'Doctors & Staff', path: '/admin/doctors', icon: UserCheck },
    { name: 'Patients Registry', path: '/admin/patients', icon: Users },
    { name: 'Appointments Monitor', path: '/admin/appointments', icon: Calendar },
    { name: 'Central OPD Queue', path: '/admin/queue', icon: Clock },
    { name: 'Pharmacy Inventory', path: '/admin/pharmacy', icon: Pill },
    { name: 'Diagnostic Lab', path: '/admin/lab', icon: FlaskConical },
    { name: 'Billing & Insurance', path: '/admin/billing', icon: CreditCard },
    { name: 'Security Audit Logs', path: '/admin/audit', icon: ShieldAlert },
    { name: 'Twilio & Settings', path: '/admin/settings', icon: Settings }
  ];

  const currentNav = isAdmin ? adminNav : (isDoctor ? doctorNav : (isPatient ? patientNav : []));

  if (!isOpen) return null;

  return (
    <aside
      style={{
        width: '260px',
        backgroundColor: '#ffffff',
        borderRight: '1px solid var(--border-color)',
        display: 'flex',
        flexDirection: 'column',
        height: 'calc(100vh - 70px)',
        position: 'sticky',
        top: '70px',
        overflowY: 'auto',
        zIndex: 50
      }}
    >
      <div style={{ padding: '1.25rem 1rem 0.5rem' }}>
        <span
          style={{
            fontSize: '0.7rem',
            fontWeight: '700',
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
            color: 'var(--text-muted)',
            paddingLeft: '0.5rem'
          }}
        >
          {isAdmin ? 'Administration Portal' : (isDoctor ? 'Doctor Clinical Console' : 'Patient Care Portal')}
        </span>
      </div>

      <nav style={{ padding: '0.5rem', display: 'flex', flexDirection: 'column', gap: '4px' }}>
        {currentNav.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              style={({ isActive }) => ({
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                padding: '0.65rem 0.9rem',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                fontWeight: isActive ? '700' : '500',
                color: isActive ? 'var(--primary)' : 'var(--text-secondary)',
                backgroundColor: isActive ? 'var(--primary-light)' : 'transparent',
                transition: 'all var(--transition-fast)'
              })}
            >
              <Icon size={18} />
              <span>{item.name}</span>
            </NavLink>
          );
        })}
      </nav>

      <div style={{ marginTop: 'auto', padding: '1rem', borderTop: '1px solid var(--border-color)' }}>
        <div
          style={{
            backgroundColor: '#f8fafc',
            border: '1px solid #e2e8f0',
            borderRadius: 'var(--radius-md)',
            padding: '10px',
            fontSize: '0.75rem',
            color: 'var(--text-muted)'
          }}
        >
          <div style={{ fontWeight: '700', color: 'var(--navy-dark)', marginBottom: '2px' }}>
            🏥 MedCare Hospital 24/7
          </div>
          <div>Emergency: 108 / 1800-MED-CARE</div>
        </div>
      </div>
    </aside>
  );
}
