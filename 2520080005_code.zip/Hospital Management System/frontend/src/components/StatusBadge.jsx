import React from 'react';

export default function StatusBadge({ status, type = 'default' }) {
  if (!status) return null;

  const s = String(status).toLowerCase();

  let badgeClass = 'badge-neutral';
  let label = status;

  if (s === 'confirmed' || s === 'completed' || s === 'paid' || s === 'active' || s === 'approved') {
    badgeClass = 'badge-success';
  } else if (s === 'waiting' || s === 'in_consultation' || s === 'serving' || s === 'in_progress' || s === 'sample_collected' || s === 'submitted' || s === 'in_review') {
    badgeClass = 'badge-warning';
  } else if (s === 'cancelled' || s === 'no_show' || s === 'unpaid' || s === 'rejected' || s === 'inactive') {
    badgeClass = 'badge-danger';
  } else if (s === 'prescribed' || s === 'ordered' || s === 'partial') {
    badgeClass = 'badge-info';
  } else if (s === 'dispensed') {
    badgeClass = 'badge-primary';
  }

  // Pretty format strings
  label = s.replace(/_/g, ' ');

  return (
    <span className={`badge ${badgeClass}`}>
      {s === 'serving' && <span className="pulse-badge" style={{ display: 'inline-block', width: '6px', height: '6px', borderRadius: '50%', backgroundColor: 'currentColor' }}></span>}
      {label}
    </span>
  );
}
