import React, { useState } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import ProtectedRoute from './components/ProtectedRoute';

// Public Pages
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';

// Patient Pages
import PatientDashboard from './pages/patient/PatientDashboard';
import BookAppointment from './pages/patient/BookAppointment';
import MyAppointments from './pages/patient/MyAppointments';
import MyQueueStatus from './pages/patient/MyQueueStatus';
import MyMedicalRecords from './pages/patient/MyMedicalRecords';
import MyBills from './pages/patient/MyBills';
import MyLabReports from './pages/patient/MyLabReports';

// Doctor Pages
import DoctorDashboard from './pages/doctor/DoctorDashboard';
import DoctorQueue from './pages/doctor/DoctorQueue';
import ConsultationRoom from './pages/doctor/ConsultationRoom';
import DoctorSchedule from './pages/doctor/DoctorSchedule';

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminDoctors from './pages/admin/AdminDoctors';
import AdminPatients from './pages/admin/AdminPatients';
import AdminAppointments from './pages/admin/AdminAppointments';
import AdminQueue from './pages/admin/AdminQueue';
import AdminPharmacy from './pages/admin/AdminPharmacy';
import AdminLab from './pages/admin/AdminLab';
import AdminBilling from './pages/admin/AdminBilling';
import AdminAudit from './pages/admin/AdminAudit';
import AdminSettings from './pages/admin/AdminSettings';

export default function App() {
  const { isAuthenticated, user } = useAuth();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const isPublicPage = ['/', '/login', '/register'].includes(location.pathname);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <Navbar onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} />

      <div className="app-container">
        {isAuthenticated && !isPublicPage && (
          <Sidebar isOpen={sidebarOpen} />
        )}

        <main className="main-content">
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />

            {/* Patient Protected Routes */}
            <Route element={<ProtectedRoute allowedRoles={['patient']} />}>
              <Route path="/patient/dashboard" element={<PatientDashboard />} />
              <Route path="/patient/book" element={<BookAppointment />} />
              <Route path="/patient/appointments" element={<MyAppointments />} />
              <Route path="/patient/queue" element={<MyQueueStatus />} />
              <Route path="/patient/records" element={<MyMedicalRecords />} />
              <Route path="/patient/billing" element={<MyBills />} />
              <Route path="/patient/lab" element={<MyLabReports />} />
            </Route>

            {/* Doctor Protected Routes */}
            <Route element={<ProtectedRoute allowedRoles={['doctor']} />}>
              <Route path="/doctor/dashboard" element={<DoctorDashboard />} />
              <Route path="/doctor/appointments" element={<AdminAppointments />} />
              <Route path="/doctor/queue" element={<DoctorQueue />} />
              <Route path="/doctor/consultation" element={<ConsultationRoom />} />
              <Route path="/doctor/patients" element={<AdminPatients />} />
              <Route path="/doctor/schedule" element={<DoctorSchedule />} />
            </Route>

            {/* Admin Protected Routes */}
            <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
              <Route path="/admin/dashboard" element={<AdminDashboard />} />
              <Route path="/admin/doctors" element={<AdminDoctors />} />
              <Route path="/admin/patients" element={<AdminPatients />} />
              <Route path="/admin/appointments" element={<AdminAppointments />} />
              <Route path="/admin/queue" element={<AdminQueue />} />
              <Route path="/admin/pharmacy" element={<AdminPharmacy />} />
              <Route path="/admin/lab" element={<AdminLab />} />
              <Route path="/admin/billing" element={<AdminBilling />} />
              <Route path="/admin/audit" element={<AdminAudit />} />
              <Route path="/admin/settings" element={<AdminSettings />} />
            </Route>

            {/* Default Catch-all */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
