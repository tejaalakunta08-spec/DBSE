/**
 * Formats a doctor's name cleanly.
 * Ensures the name begins with 'Dr. ' and prevents any accidental duplicate prefixes
 * like 'Dr. Dr. Ramesh Sharma'.
 *
 * @param {string} name - Raw doctor name string
 * @returns {string} Formatted name e.g. "Dr. Ramesh Sharma"
 */
export function formatDoctorName(name) {
  if (!name) return 'Dr. Specialist';
  const clean = name.replace(/^(Dr\.\s*|Dr\s+)+/i, '').trim();
  return `Dr. ${clean}`;
}
