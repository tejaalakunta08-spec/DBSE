# Hospital Management & Appointment System — Microservices Architecture 🏥

An enterprise-grade, distributed **Hospital Management System** backend re-architected from a monolith into **8 autonomous microservices** coordinated through an **API Gateway**, adhering strictly to the **Database-per-Service pattern with MySQL as the exclusive database technology**.

---

## 📑 Table of Contents

1. [Architecture Overview & Principles](#1-architecture-overview--principles)
2. [Microservices Architecture Diagram](#2-microservices-architecture-diagram)
3. [Service Directory Structure](#3-service-directory-structure)
4. [Microservices Catalog & Port Allocation](#4-microservices-catalog--port-allocation)
5. [Database-per-Service Design (MySQL Only)](#5-database-per-service-design-mysql-only)
6. [API Gateway Architecture](#6-api-gateway-architecture)
7. [Authentication & Role-Based Access Control (RBAC)](#7-authentication--role-based-access-control-rbac)
8. [Inter-Service REST Communication](#8-inter-service-rest-communication)
9. [Complete API Endpoint Catalog](#9-complete-api-endpoint-catalog)
10. [Docker & Container Orchestration](#10-docker--container-orchestration)
11. [Environment Configuration Reference](#11-environment-configuration-reference)
12. [Commands to Run Locally & Docker](#12-commands-to-run-locally--docker)
13. [Verification & Integration Test Results](#13-verification--integration-test-results)

---

## 1. Architecture Overview & Principles

### Core Design Rules Enforced
1. **Strictly MySQL Only**: No NoSQL, Redis, MongoDB, PostgreSQL, or Firebase. Each microservice connects exclusively to its own dedicated MySQL schema.
2. **Database-per-Service**: Microservices maintain complete data autonomy. Direct cross-database SQL queries or foreign keys between different services are strictly forbidden.
3. **Identifier References**: Entities in other services are referenced strictly through immutable integer IDs (`patientId`, `doctorId`, `appointmentId`). Complete metadata is retrieved on-demand via low-latency internal REST APIs.
4. **API Gateway as Single Entry Point**: The React.js frontend communicates exclusively with the API Gateway on port `5000`. The frontend code requires zero modifications to function.
5. **Defense-in-Depth Authentication**: The API Gateway verifies the JWT and decorates forwarded requests with `x-user-id`, `x-user-role`, `x-patient-id`, and `x-doctor-id`, while individual microservices independently validate authorization headers.
6. **Isolated Third-Party Integrations**: Twilio SMS delivery and simulation are isolated inside the `notification-service`, shielding other domains from external network changes or failures.

---

## 2. Microservices Architecture Diagram

```mermaid
graph TD
    Client["React.js Frontend (Port 5173)"]
    
    subgraph Gateway_Layer["API Gateway Layer"]
        GW["API Gateway (Port 5000)<br/>• Route Reverse Proxy<br/>• Gateway JWT Verification<br/>• Role-Based Access Control<br/>• Centralized Logging & Error Handling<br/>• Executive Dashboard Aggregator"]
    end

    Client -->|HTTP /api/*| GW

    subgraph Microservices_Layer["Autonomous Microservices (Node.js + Express.js + Sequelize)"]
        AuthSvc["Auth & User Service<br/>(Port 5001)"]
        ApptSvc["Appointment Service<br/>(Port 5002)"]
        EmrSvc["Patient & EMR Service<br/>(Port 5003)"]
        QueueSvc["Queue & Token Service<br/>(Port 5004)"]
        BillSvc["Billing & Insurance Service<br/>(Port 5005)"]
        PharmSvc["Pharmacy & Inventory Service<br/>(Port 5006)"]
        LabSvc["Laboratory Service<br/>(Port 5007)"]
        NotifSvc["Notification Service<br/>(Port 5008)"]
    end

    GW -->|/api/auth, /api/doctors, /api/patients| AuthSvc
    GW -->|/api/appointments, /api/doctors/:id/slots| ApptSvc
    GW -->|/api/records| EmrSvc
    GW -->|/api/queue| QueueSvc
    GW -->|/api/billing| BillSvc
    GW -->|/api/pharmacy| PharmSvc
    GW -->|/api/lab| LabSvc
    GW -->|/api/notifications| NotifSvc

    %% Inter-Service Communication
    ApptSvc -.->|GET /internal/doctors/:id| AuthSvc
    ApptSvc -.->|POST /internal/generate| QueueSvc
    ApptSvc -.->|POST /internal/create| BillSvc
    ApptSvc -.->|POST /internal/send| NotifSvc
    EmrSvc -.->|POST /internal/deduct-stock| PharmSvc
    EmrSvc -.->|POST /internal/send| NotifSvc
    BillSvc -.->|POST /internal/send| NotifSvc

    subgraph MySQL_Databases["Database-per-Service (MySQL 8.0)"]
        DB_Auth[("hospital_auth_db")]
        DB_Appt[("hospital_appointment_db")]
        DB_Emr[("hospital_emr_db")]
        DB_Queue[("hospital_queue_db")]
        DB_Bill[("hospital_billing_db")]
        DB_Pharm[("hospital_pharmacy_db")]
        DB_Lab[("hospital_lab_db")]
        DB_Notif[("hospital_notification_db")]
    end

    AuthSvc --> DB_Auth
    ApptSvc --> DB_Appt
    EmrSvc --> DB_Emr
    QueueSvc --> DB_Queue
    BillSvc --> DB_Bill
    PharmSvc --> DB_Pharm
    LabSvc --> DB_Lab
    NotifSvc --> DB_Notif
```

---

## 3. Service Directory Structure

```
Hospital Management System/
│
├── api-gateway/                      # Port 5000 (Central routing, JWT & aggregation)
│   ├── src/
│   │   ├── config/gateway.config.js
│   │   ├── controllers/adminStats.controller.js
│   │   ├── middleware/auth.middleware.js
│   │   ├── middleware/error.middleware.js
│   │   ├── routes/gateway.routes.js
│   │   └── server.js
│   ├── .env
│   ├── Dockerfile
│   └── package.json
│
├── services/
│   ├── auth-service/                 # Port 5001 (DB: hospital_auth_db)
│   │   ├── src/
│   │   │   ├── config/db.config.js, jwt.config.js
│   │   │   ├── controllers/auth.controller.js, doctor.controller.js, ...
│   │   │   ├── models/User.js, Patient.js, Doctor.js, AuditLog.js
│   │   │   ├── routes/auth.routes.js, doctor.routes.js, internal.routes.js, ...
│   │   │   └── server.js
│   │   ├── .env
│   │   ├── Dockerfile
│   │   └── package.json
│   │
│   ├── appointment-service/          # Port 5002 (DB: hospital_appointment_db)
│   │   ├── src/
│   │   │   ├── models/Appointment.js, DoctorSchedule.js
│   │   │   ├── services/authClient.service.js, queueClient.service.js, ...
│   │   │   ├── controllers/appointment.controller.js, schedule.controller.js, ...
│   │   │   └── server.js
│   │   ├── .env
│   │   ├── Dockerfile
│   │   └── package.json
│   │
│   ├── emr-service/                  # Port 5003 (DB: hospital_emr_db)
│   │   ├── src/
│   │   │   ├── models/MedicalRecord.js, Prescription.js, PrescriptionItem.js
│   │   │   ├── services/authClient.service.js, pharmacyClient.service.js, ...
│   │   │   ├── controllers/medicalRecord.controller.js, ...
│   │   │   └── server.js
│   │   ├── .env
│   │   ├── Dockerfile
│   │   └── package.json
│   │
│   ├── queue-service/                # Port 5004 (DB: hospital_queue_db)
│   │   ├── src/
│   │   │   ├── models/QueueToken.js
│   │   │   ├── services/authClient.service.js, notificationClient.service.js
│   │   │   ├── controllers/queue.controller.js, ...
│   │   │   └── server.js
│   │   ├── .env
│   │   ├── Dockerfile
│   │   └── package.json
│   │
│   ├── billing-service/              # Port 5005 (DB: hospital_billing_db)
│   │   ├── src/
│   │   │   ├── models/Bill.js, InsuranceClaim.js
│   │   │   ├── services/authClient.service.js, notificationClient.service.js
│   │   │   ├── controllers/billing.controller.js, ...
│   │   │   └── server.js
│   │   ├── .env
│   │   ├── Dockerfile
│   │   └── package.json
│   │
│   ├── pharmacy-service/             # Port 5006 (DB: hospital_pharmacy_db)
│   │   ├── src/
│   │   │   ├── models/Medicine.js, InventoryTransaction.js
│   │   │   ├── controllers/pharmacy.controller.js, ...
│   │   │   └── server.js
│   │   ├── .env
│   │   ├── Dockerfile
│   │   └── package.json
│   │
│   ├── laboratory-service/           # Port 5007 (DB: hospital_lab_db)
│   │   ├── src/
│   │   │   ├── models/LabTest.js, LabReport.js
│   │   │   ├── services/authClient.service.js, billingClient.service.js
│   │   │   ├── controllers/lab.controller.js, ...
│   │   │   └── server.js
│   │   ├── .env
│   │   ├── Dockerfile
│   │   └── package.json
│   │
│   └── notification-service/         # Port 5008 (DB: hospital_notification_db)
│       ├── src/
│       │   ├── config/twilio.config.js
│       │   ├── models/Notification.js
│       │   ├── controllers/notification.controller.js, ...
│       │   └── server.js
│       ├── .env
│       ├── Dockerfile
│       └── package.json
│
├── frontend/                         # Port 5173 (React.js SPA)
├── docker-compose.yml                # Multi-container orchestration
├── docker/mysql-init/                # MySQL schemas initialization
├── scripts/
│   ├── initMicroserviceDatabases.js  # Schema creation script
│   ├── seedMicroservices.js          # Unified seed script for all 8 DBs
│   ├── testMicroservices.js          # 18-step integration test suite
│   └── testBookingFlow.js            # Distributed transaction test
├── .env.example                      # Root environment configuration reference
└── package.json                      # Workspace orchestrator
```

---

## 4. Microservices Catalog & Port Allocation

| Service Name | Port | MySQL Schema | Core Responsibilities |
|---|---|---|---|
| **API Gateway** | `5000` | — | Reverse proxying, JWT validation, RBAC, metric aggregation, request logging |
| **Authentication & User Service** | `5001` | `hospital_auth_db` | User login/registration, password hashing, doctor/patient profiles, audit logging |
| **Appointment Service** | `5002` | `hospital_appointment_db` | Doctor weekly schedules, booking logic, slot availability, cancellation |
| **Patient & EMR Service** | `5003` | `hospital_emr_db` | Clinical records, vital signs, electronic prescriptions, prescription items |
| **Queue & Token Service** | `5004` | `hospital_queue_db` | Sequential OPD token creation, real-time queue statuses, token transitions |
| **Billing & Insurance Service** | `5005` | `hospital_billing_db` | Consultation invoices, payments (Cash/UPI/Card), insurance claims adjudication |
| **Pharmacy & Inventory Service** | `5006` | `hospital_pharmacy_db` | Medicine catalog, stock tracking, automatic deduction, low-stock reorder alerts |
| **Laboratory Service** | `5007` | `hospital_lab_db` | Test catalog (CBC, Lipid, HbA1c, LFT), report publishing, diagnostic ranges |
| **Notification Service** | `5008` | `hospital_notification_db` | In-app alerts, SMS dispatch via Twilio (with fallback mock simulator) |

---

## 5. Database-per-Service Design (MySQL Only)

Each microservice manages its own independent schema. No service can perform SQL joins across schemas.

### Schema & Entity Mapping
1. **`hospital_auth_db`**:
   - `users` (`id`, `name`, `email`, `password_hash`, `role`, `status`)
   - `patients` (`id`, `userId` [FK], `patientCode`, `dob`, `gender`, `bloodGroup`, `emergencyContactName`, `insuranceProvider`, `insurancePolicyNumber`)
   - `doctors` (`id`, `userId` [FK], `doctorCode`, `department`, `specialization`, `consultationFee`, `roomNumber`, `isAvailableToday`)
   - `audit_logs` (`id`, `userId`, `action`, `entity`, `entityId`, `details`, `ipAddress`)

2. **`hospital_appointment_db`**:
   - `doctor_schedules` (`id`, `doctorId`, `dayOfWeek`, `startTime`, `endTime`, `slotDurationMinutes`, `maxPatientsPerDay`, `isAvailable`)
   - `appointments` (`id`, `appointmentNumber`, `patientId`, `doctorId`, `appointmentDate`, `timeSlot`, `status`, `reason`, `symptoms`, `cancelledBy`, `cancellationReason`)

3. **`hospital_emr_db`**:
   - `medical_records` (`id`, `patientId`, `doctorId`, `appointmentId`, `visitDate`, `symptoms`, `diagnosis`, `bloodPressure`, `heartRate`, `temperature`, `weight`, `clinicalNotes`, `doctorNotes`)
   - `prescriptions` (`id`, `prescriptionCode`, `medicalRecordId` [FK], `appointmentId`, `patientId`, `doctorId`, `status`, `generalAdvice`)
   - `prescription_items` (`id`, `prescriptionId` [FK], `medicineName`, `dosage`, `frequency`, `durationDays`, `quantity`, `instructions`)

4. **`hospital_queue_db`**:
   - `queue_tokens` (`id`, `tokenNumber`, `tokenCode`, `appointmentId`, `patientId`, `doctorId`, `tokenDate`, `status`, `estimatedTime`, `calledAt`, `completedAt`)

5. **`hospital_billing_db`**:
   - `bills` (`id`, `billNumber`, `patientId`, `appointmentId`, `consultationFee`, `medicineFee`, `labFee`, `subtotal`, `discountAmount`, `totalAmount`, `paidAmount`, `balanceAmount`, `paymentStatus`, `paymentMethod`, `transactionReference`, `billDate`)
   - `insurance_claims` (`id`, `billId` [FK], `claimNumber`, `patientId`, `insuranceProvider`, `policyNumber`, `claimAmount`, `approvedAmount`, `status`, `rejectionReason`)

6. **`hospital_pharmacy_db`**:
   - `medicines` (`id`, `name`, `genericName`, `category`, `manufacturer`, `batchNumber`, `stockQuantity`, `unitPrice`, `reorderLevel`, `expiryDate`)
   - `inventory_transactions` (`id`, `medicineId` [FK], `type`, `quantity`, `previousStock`, `currentStock`, `referenceNote`, `createdByUserId`)

7. **`hospital_lab_db`**:
   - `lab_tests` (`id`, `testCode`, `name`, `category`, `price`, `turnaroundHours`, `normalRange`, `description`)
   - `lab_reports` (`id`, `reportNumber`, `labTestId` [FK], `patientId`, `doctorId`, `appointmentId`, `status`, `resultValue`, `isAbnormal`, `remarks`, `technicianNotes`, `prescribedDate`)

8. **`hospital_notification_db`**:
   - `notifications` (`id`, `userId`, `phone`, `email`, `title`, `message`, `channel`, `eventType`, `isRead`, `deliveryStatus`, `twilioSid`)

---

## 6. API Gateway Architecture

The API Gateway runs on port **5000** and serves as the single façade between the client and microservices.

### Gateway Capabilities
- **Reverse Proxy Routing**: Directs client requests to target microservices seamlessly while preserving query parameters and payload bodies via `http-proxy-middleware` and `fixRequestBody`.
- **Pre-Routing Token Authentication**: Verifies JWT signatures before requests ever leave the Gateway layer.
- **Header Enrichment**: Decodes user identity and injects trusted internal headers:
  - `x-user-id`
  - `x-user-role`
  - `x-user-name`
  - `x-patient-id` (for patient sessions)
  - `x-doctor-id` (for doctor sessions)
- **Executive Operations Aggregator**: The `GET /api/admin/stats` route coordinates concurrent calls to `/internal/stats` across 6 microservices (`auth`, `appointment`, `billing`, `pharmacy`, `lab`, `queue`), compiles operational metrics, and formats the response for the admin command center with sub-second latencies and timeout safety fallbacks.

---

## 7. Authentication & Role-Based Access Control (RBAC)

The Authentication Service issues signed JWT tokens containing the user's role and associated profile identifiers.

### Token Claims
```json
{
  "id": 7,
  "email": "patient.sai@hospital.com",
  "role": "patient",
  "name": "Sai Teja",
  "patientProfile": { "id": 1, "patientCode": "PAT-100007" },
  "doctorProfile": null,
  "iat": 1727931600,
  "exp": 1728536400
}
```

### Role Matrix
| Capability | Patient | Doctor | Admin |
|---|:---:|:---:|:---:|
| View Doctor Directory & Available Slots | ✅ | ✅ | ✅ |
| Book & Cancel Personal Appointments | ✅ | ❌ | ✅ |
| View Assigned Consultations | ❌ | ✅ | ✅ |
| Access Electronic Health Records (EMR) | Own Only | Authorized Patients | All |
| Issue Prescriptions & Clinical Records | ❌ | ✅ | ✅ |
| View OPD Waiting Queue | Own Token | Attending Doctor Queue | All Queue Tokens |
| Advance OPD Queue (`call-next`) | ❌ | ✅ | ✅ |
| View Invoices & Settle Balance | Own Only | ❌ | All |
| Adjudicate Insurance Claims | ❌ | ❌ | ✅ |
| Manage Pharmacy Stock & Inventory | View Catalog | View Catalog | Full Read / Write |
| Order & View Laboratory Diagnostics | Own Only | Assigned Patients | Full Read / Write |
| Executive Operations Dashboard (`/admin/stats`) | ❌ | ❌ | ✅ |
| Audit Trail Logs (`/admin/audit-logs`) | ❌ | ❌ | ✅ |

---

## 8. Inter-Service REST Communication

Services communicate over synchronous, non-blocking HTTP REST using native Node.js 18+ `fetch` with in-memory caching.

### Distributed Booking Transaction Sequence

```
Patient Client           API Gateway         Appointment Svc        Queue Svc           Billing Svc        Notification Svc
     │                        │                     │                   │                    │                   │
     │── POST /appointments ─>│                     │                   │                    │                   │
     │                        │── Proxy POST ──────>│                   │                    │                   │
     │                        │                     │                   │                    │                   │
     │                        │                     │── Save Appt to DB │                    │                   │
     │                        │                     │                   │                    │                   │
     │                        │                     │── POST /internal/generate ────────────>│                   │
     │                        │                     │<─ Return Token #4 ─────────────────────│                   │
     │                        │                     │                   │                    │                   │
     │                        │                     │── POST /internal/create ──────────────────────────────────>│
     │                        │                     │<─ Return Bill #INV ────────────────────────────────────────│
     │                        │                     │                   │                    │                   │
     │                        │                     │── POST /internal/send ─────────────────────────────────────────>│
     │                        │                     │<─ Return SMS Dispatched ───────────────────────────────────────│
     │                        │                     │                   │                    │                   │
     │                        │<─ 201 Created ──────│                   │                    │                   │
     │<─ 201 Response ────────│                     │                   │                    │                   │
```

---

## 9. Complete API Endpoint Catalog

### 1. Authentication & User Service (`auth-service` / Port 5001)
- `POST /api/auth/register` — Patient self-registration (Public)
- `POST /api/auth/login` — User authentication and JWT generation (Public)
- `GET  /api/auth/me` — Current profile resolution (Authenticated)
- `POST /api/auth/register-doctor` — Create physician account (Admin)
- `GET  /api/doctors` — Public directory of specialist doctors (Public)
- `GET  /api/doctors/departments` — List of clinical hospital departments (Public)
- `GET  /api/doctors/:id` — Doctor profile by ID (Public)
- `GET  /api/patients` — List registered patient records (Doctor / Admin)
- `GET  /api/patients/:id` — Specific patient profile (Doctor / Admin / Owner)
- `GET  /internal/patients/:id` — Internal patient lookup (Service-to-Service)
- `GET  /internal/doctors/:id` — Internal doctor lookup (Service-to-Service)
- `GET  /internal/users/:id` — Internal user lookup (Service-to-Service)
- `GET  /internal/stats` — Patient & doctor counts for admin aggregator (Service-to-Service)
- `GET  /internal/audit-logs` — Administrative security audit log (Admin via Gateway)
- `PUT  /internal/users/:userId/status` — Activate/deactivate account (Admin via Gateway)

### 2. Appointment Service (`appointment-service` / Port 5002)
- `GET  /api/doctors/:id/slots?date=YYYY-MM-DD` — Real-time slot availability (Public)
- `GET  /api/doctors/:id/schedule` — Weekly roster schedule (Public)
- `PUT  /api/doctors/:id/schedule` — Update roster availability (Doctor / Admin)
- `POST /api/appointments` — Book new appointment (Patient / Admin)
- `GET  /api/appointments` — Get appointments (Role-aware filtering)
- `GET  /api/appointments/my` — Get logged-in patient/doctor appointments
- `GET  /api/appointments/:id` — Specific appointment details
- `POST /api/appointments/:id/cancel` — Cancel appointment (Owner / Admin)
- `PUT  /api/appointments/:id/status` — Transition appointment status (Doctor / Admin)
- `GET  /internal/appointments/:id` — Internal appointment lookup (Service-to-Service)
- `GET  /internal/stats` — Today's appointment counts & recent bookings (Service-to-Service)

### 3. Patient & EMR Service (`emr-service` / Port 5003)
- `POST /api/records` — Create clinical consultation note and prescription (Doctor / Admin)
- `GET  /api/records` — Get logged-in patient's medical records
- `GET  /api/records/my` — Get logged-in patient's medical records
- `GET  /api/records/patient/:patientId` — Clinical history for patient (Doctor / Admin / Owner)
- `GET  /api/records/:id` — Detailed consultation record with vitals and prescription

### 4. Queue & Token Service (`queue-service` / Port 5004)
- `GET  /api/queue/my-status` — Current patient's OPD token and queue position
- `GET  /api/queue/live` — Live queue display board for a physician
- `POST /api/queue/call-next` — Advance queue to next waiting token (Doctor / Admin)
- `PUT  /api/queue/:id/status` — Mark token as serving/completed/skipped (Doctor / Admin)
- `POST /internal/generate` — Generate token for today's appointment (Service-to-Service)
- `GET  /internal/stats` — Active queue token count (Service-to-Service)

### 5. Billing & Insurance Service (`billing-service` / Port 5005)
- `GET  /api/billing` — List itemized bills (Role-aware: Patient sees own, Admin sees all)
- `POST /api/billing/:id/pay` — Settle invoice via Cash/UPI/Card (Patient / Admin)
- `POST /api/billing/claim` — Submit insurance claim for adjudication (Patient / Admin)
- `PUT  /api/billing/claims/:id` — Approve or reject insurance claim (Admin)
- `POST /internal/create` — Generate consultation bill (Service-to-Service)
- `GET  /internal/stats` — Revenue summary & pending claims (Service-to-Service)

### 6. Pharmacy & Inventory Service (`pharmacy-service` / Port 5006)
- `GET  /api/pharmacy/medicines` — Pharmacy medication catalog
- `POST /api/pharmacy/medicines` — Add new medication to catalog (Admin)
- `PUT  /api/pharmacy/medicines/:id` — Update medicine details and reorder thresholds (Admin)
- `GET  /api/pharmacy/transactions` — Audit trail of inventory movements (Admin)
- `POST /internal/deduct-stock` — Deduct medication stock upon prescription issue (Service-to-Service)
- `GET  /internal/stats` — Low stock inventory alerts count (Service-to-Service)

### 7. Laboratory Service (`laboratory-service` / Port 5007)
- `GET  /api/lab/tests` — Diagnostic pathology and radiology test catalog
- `POST /api/lab/tests` — Add diagnostic test to catalog (Admin)
- `GET  /api/lab/my-reports` — View patient's completed lab reports (Patient)
- `GET  /api/lab/patient-reports/:patientId` — View patient's lab reports (Doctor / Admin)
- `POST /api/lab/reports` — Order lab test for patient (Doctor / Admin)
- `PUT  /api/lab/reports/:id` — Upload test results and clinical interpretation (Doctor / Admin)
- `GET  /internal/stats` — Pending diagnostic tests count (Service-to-Service)

### 8. Notification Service (`notification-service` / Port 5008)
- `GET  /api/notifications/my` — Get logged-in user notifications
- `PUT  /api/notifications/:id/read` — Mark notification as read
- `PUT  /api/notifications/read-all` — Mark all notifications as read
- `POST /api/notifications/test-sms` — Trigger test Twilio SMS alert (Admin)
- `POST /internal/send` — Send notification & SMS (Service-to-Service)

### 9. API Gateway Aggregator (`api-gateway` / Port 5000)
- `GET  /health` — API Gateway status check
- `GET  /api/admin/stats` — Hospital Command Center operational KPI aggregation (Admin)
- `GET  /api/admin/audit-logs` — Proxied to Auth Service audit trail (Admin)
- `PUT  /api/admin/users/:userId/status` — Proxied to Auth Service user management (Admin)
- `POST /api/admin/test-sms` — Proxied to Notification Service SMS tool (Admin)

---

## 10. Docker & Container Orchestration

A multi-container `docker-compose.yml` configuration orchestrates:
- **`mysql`**: MySQL 8.0 server with automated multi-database provisioning (`docker/mysql-init/01-create-databases.sql`)
- **8 Microservices**: Each containerized via lightweight `node:18-alpine` Dockerfiles
- **`api-gateway`**: Reverse proxy gateway container on port 5000
- **`frontend`**: React.js Vite application on port 5173

### Launching with Docker Compose
```bash
# Start all containers in detached mode
docker compose up -d --build

# View real-time aggregated logs
docker compose logs -f

# Seed initial demonstration data inside the Docker network
docker compose exec api-gateway node /app/scripts/seedMicroservices.js
```

---

## 11. Environment Configuration Reference

Create or inspect `.env.example` in the root workspace. Each microservice contains its own `.env` file configuring its database and inter-service dependencies.

```env
# Central MySQL DBMS
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=root
DB_PASS=Teja@2007

# JWT Security
JWT_SECRET=hospital_jwt_super_secret_key_2026_academic_project
JWT_EXPIRES_IN=7d

# Microservice Ports
GATEWAY_PORT=5000
AUTH_SERVICE_PORT=5001
APPOINTMENT_SERVICE_PORT=5002
EMR_SERVICE_PORT=5003
QUEUE_SERVICE_PORT=5004
BILLING_SERVICE_PORT=5005
PHARMACY_SERVICE_PORT=5006
LAB_SERVICE_PORT=5007
NOTIFICATION_SERVICE_PORT=5008

# Inter-Service URLs
AUTH_SERVICE_URL=http://127.0.0.1:5001
APPOINTMENT_SERVICE_URL=http://127.0.0.1:5002
EMR_SERVICE_URL=http://127.0.0.1:5003
QUEUE_SERVICE_URL=http://127.0.0.1:5004
BILLING_SERVICE_URL=http://127.0.0.1:5005
PHARMACY_SERVICE_URL=http://127.0.0.1:5006
LAB_SERVICE_URL=http://127.0.0.1:5007
NOTIFICATION_SERVICE_URL=http://127.0.0.1:5008

# Twilio SMS Credentials (Optional - Mock mode active if empty)
TWILIO_ENABLED=false
TWILIO_ACCOUNT_SID=ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_PHONE_NUMBER=+1234567890
```

---

## 12. Commands to Run Locally & Docker

### Option A: Complete Microservices Development Stack (Recommended)

1. **Initialize the 8 MySQL Databases**:
   ```bash
   npm run microservices:init
   ```

2. **Seed All Databases with Initial Realistic Data**:
   ```bash
   npm run microservices:seed
   ```

3. **Start All 8 Microservices + API Gateway Concurrently**:
   ```bash
   npm run microservices:dev
   ```

4. **Start the React Frontend**:
   ```bash
   npm run frontend
   ```
   *Access the web app at `http://localhost:5173`.*

---

### Option B: Run Everything in One Command

```bash
npm run dev:all
```
*Starts API Gateway, all 8 microservices, and the React frontend concurrently with colored log labels.*

---

### Option C: Start Microservices Independently

```bash
# Terminal 1: API Gateway
npm run microservices:gateway

# Terminal 2: Auth Service
npm run microservices:auth

# Terminal 3: Appointment Service
npm run microservices:appointment

# Terminal 4: EMR Service
npm run microservices:emr

# Terminal 5: Queue Service
npm run microservices:queue

# Terminal 6: Billing Service
npm run microservices:billing

# Terminal 7: Pharmacy Service
npm run microservices:pharmacy

# Terminal 8: Lab Service
npm run microservices:lab

# Terminal 9: Notification Service
npm run microservices:notification
```

---

## 13. Verification & Integration Test Results

Two automated test suites are provided to prove architectural correctness and distributed data flow:

### 1. 18-Step Microservices API Test Suite
```bash
node scripts/testMicroservices.js
```
**Output Summary**:
```
===============================================================
🧪 RUNNING COMPREHENSIVE MICROSERVICES INTEGRATION TESTS
🌐 Target: API Gateway (http://127.0.0.1:5000/api)
===============================================================

  ✅ [PASS] API Gateway Health Check
  ✅ [PASS] Auth Service: GET /doctors (Public)
  ✅ [PASS] Auth Service: GET /doctors/departments (Public)
  ✅ [PASS] Appointment Service: GET /doctors/1/slots (Public)
  ✅ [PASS] Auth Service: Patient Login (patient.sai@hospital.com)
  ✅ [PASS] Auth Service: Doctor Login (dr.sharma@hospital.com)
  ✅ [PASS] Auth Service: Admin Login (admin@hospital.com)
  ✅ [PASS] Appointment Service: GET /appointments/my (Patient Auth)
  ✅ [PASS] Queue Service: GET /queue/my-status (Patient Auth)
  ✅ [PASS] EMR Service: GET /records/my (Patient Auth)
  ✅ [PASS] Billing Service: GET /billing (Patient Auth)
  ✅ [PASS] Pharmacy Service: GET /pharmacy/medicines (Patient Auth)
  ✅ [PASS] Laboratory Service: GET /lab/tests (Patient Auth)
  ✅ [PASS] Notification Service: GET /notifications/my (Patient Auth)
  ✅ [PASS] API Gateway: GET /admin/stats (Admin Auth Aggregator)
  ✅ [PASS] API Gateway -> Auth Service: GET /admin/audit-logs (Admin Auth)
  ✅ [PASS] Security / RBAC: Patient blocked from /admin/stats (403 Forbidden)
  ✅ [PASS] Security: Missing Token blocked from /admin/stats (401 Unauthorized)

===============================================================
📊 TEST RESULTS: 18 PASSED | 0 FAILED (100% SUCCESS)
===============================================================
```

### 2. Distributed Transaction Booking Flow Test
```bash
node scripts/testBookingFlow.js
```
**Output Summary**:
```
===============================================================
🔄 TESTING DISTRIBUTED INTER-SERVICE BOOKING TRANSACTION
===============================================================

1. Logged in as Patient: Sai Teja
2. Book Appointment Response: Appointment booked successfully!
   - Appointment ID: 8
   - Appointment Number: APT-236319-72
   - OPD Token Generated: #4 (Code: OPD-DOC-2-004)
3. Queue Service Verification: Active Token #4 (in hospital_queue_db)
4. Billing Service Verification: Bill #INV-236363-53 for ₹750.00 (in hospital_billing_db)
5. Notification Service Verification: Found 4 notifications for patient.

===============================================================
🎉 DISTRIBUTED INTER-SERVICE TRANSACTION COMPLETED SUCCESSFULLY!
===============================================================
```

### Pre-Configured Test Credentials
- **👑 Administrator**: `admin@hospital.com` / `Admin@123`
- **🩺 Specialist Doctor**: `dr.sharma@hospital.com` / `Doctor@123`
- **🧑 Patient**: `patient.sai@hospital.com` / `Patient@123`
