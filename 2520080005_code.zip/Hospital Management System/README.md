# MedCare - Hospital Management & OPD Appointment System 🏥

A full-stack, enterprise-grade **Hospital Management & Outpatient Department (OPD) Appointment System** built using **React.js for the frontend and Node.js, Express.js, Sequelize ORM, and MySQL for the backend**.

Strictly engineered with **MySQL as the only database engine**, implementing normalized relational tables, foreign key constraints, indexes, SQL joins, and ACID database transactions.

---

## 📌 Project Overview

MedCare is designed for multi-specialty hospitals to streamline the entire patient journey:
1. **Self-Registration & EHR Profiles**: Patients create their Electronic Health Record profile with allergies, chronic illnesses, and insurance details.
2. **Dynamic OPD Appointment Booking**: Real-time slot calculation based on physician schedules and existing bookings.
3. **Automated Live OPD Queue & Tokens**: Daily token generation with live queue status, current serving token tracking, and wait time estimation.
4. **Physician Consultation Room**: Comprehensive EMR recording (Symptoms, Diagnosis, Vital signs: Blood Pressure, Heart Rate, Temperature, Weight).
5. **Digital E-Prescriptions**: Prescription builder with medications catalog, dosage forms, meal instructions, and automatic pharmacy dispensing deduction.
6. **Diagnostic Pathology & Radiology**: Test ordering, sample collection tracking, and clinical test report publishing with normal range comparison.
7. **Transparent Billing & Insurance Claims**: Itemized invoices (Consultation + Pharmacy + Lab) and third-party health insurance claim adjudication.
8. **Communication & SMS**: Twilio SMS integration for automated appointment confirmations and queue call alerts (with mock simulator fallback).
9. **Role-Based Access Control (RBAC)**: Secure JWT authentication with bcrypt hashing for **Patient, Doctor, and Admin**.
10. **Security & Audit Logging**: Chronological security audit trail recording all sensitive actions with timestamps, user roles, and IP addresses.

---

## 💻 Technology Stack

| Layer | Technology | Purpose |
|---|---|---|
| **Frontend** | React.js 18, JSX, Vite | Fast, responsive single-page application |
| **Routing** | React Router v6 | Role-based protected routes and route transitions |
| **Icons & Design** | Lucide React, Modern CSS | Medical teal design system, responsive tables, cards, badges |
| **API Client** | Axios | Centralized HTTP client with JWT interceptor |
| **Backend** | Node.js, Express.js | RESTful API server with modular controllers and services |
| **Database** | **MySQL 8.0** | **Exclusive database engine** (No MongoDB, Redis, or Postgres) |
| **ORM** | Sequelize v6 (`mysql2`) | Normalized models, relationships, hooks, and transactions |
| **Security** | JWT (`jsonwebtoken`), `bcryptjs` | Stateless session tokens and salted password hashing |
| **SMS Gateway** | Twilio API | Optional SMS notifications with dev mock fallback |

---

## 📁 Project Directory Structure

```
Hospital Management System/
├── backend/
│   ├── src/
│   │   ├── config/
│   │   │   ├── db.config.js          # MySQL connection pool & auto DB creator
│   │   │   ├── jwt.config.js         # JWT secret & expiration
│   │   │   └── twilio.config.js      # Twilio SMS client & mock simulator
│   │   ├── controllers/
│   │   │   ├── admin.controller.js
│   │   │   ├── appointment.controller.js
│   │   │   ├── auth.controller.js
│   │   │   ├── billing.controller.js
│   │   │   ├── doctor.controller.js
│   │   │   ├── lab.controller.js
│   │   │   ├── medicalRecord.controller.js
│   │   │   ├── notification.controller.js
│   │   │   ├── patient.controller.js
│   │   │   ├── pharmacy.controller.js
│   │   │   └── queue.controller.js
│   │   ├── middleware/
│   │   │   ├── auth.middleware.js     # Bearer token verification
│   │   │   ├── error.middleware.js    # Centralized error handler
│   │   │   └── role.middleware.js     # RBAC (Patient, Doctor, Admin)
│   │   ├── models/
│   │   │   ├── Appointment.js
│   │   │   ├── AuditLog.js
│   │   │   ├── Bill.js
│   │   │   ├── Doctor.js
│   │   │   ├── DoctorSchedule.js
│   │   │   ├── InsuranceClaim.js
│   │   │   ├── InventoryTransaction.js
│   │   │   ├── LabReport.js
│   │   │   ├── LabTest.js
│   │   │   ├── MedicalRecord.js
│   │   │   ├── Medicine.js
│   │   │   ├── Notification.js
│   │   │   ├── Patient.js
│   │   │   ├── Prescription.js
│   │   │   ├── PrescriptionItem.js
│   │   │   ├── QueueToken.js
│   │   │   ├── User.js
│   │   │   └── index.js              # Sequelize Model Associations
│   │   ├── routes/                   # Resource routes
│   │   ├── services/                 # Audit & notification dispatchers
│   │   └── server.js                 # Express server entry point
│   ├── scripts/
│   │   ├── initDb.js                 # Database schema initialization
│   │   ├── seedData.js               # Comprehensive college project demo seed
│   │   └── testConnection.js         # MySQL credential tester & auto .env updater
│   ├── .env                          # Environment variables
│   ├── .env.example
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── api/client.js             # Axios API client with token interceptor
│   │   ├── components/               # Navbar, Sidebar, Modal, StatCard, Badges
│   │   ├── context/                  # AuthContext, NotificationContext
│   │   ├── pages/
│   │   │   ├── LandingPage.jsx       # Public portal & OPD live board
│   │   │   ├── LoginPage.jsx         # 1-Click demo logins for all roles
│   │   │   ├── RegisterPage.jsx      # Patient EHR registration
│   │   │   ├── patient/              # Dashboard, Booking, Appointments, Queue, EMR, Bills, Lab
│   │   │   ├── doctor/               # Dashboard, Appointments, OPD Queue, Consultation, Schedule
│   │   │   └── admin/                # Dashboard, Doctors, Patients, Pharmacy, Lab, Billing, Audit
│   │   ├── App.jsx                   # React Router route registry
│   │   ├── main.jsx
│   │   └── index.css                 # Medical teal design system
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── package.json                      # Root workspace orchestrator
└── README.md
```

---

## 🗄️ MySQL Database Schema & Models

The database schema is fully normalized into **17 tables** with primary keys, foreign keys, unique constraints, and indexes:

1. **`users`**: Base credentials, email, password hash, role (`admin`, `doctor`, `patient`), phone, status.
2. **`patients`**: Links to `users.id` (1:1). Stores patient code, DOB, gender, blood group, emergency contact, allergies, chronic conditions, insurance details.
3. **`doctors`**: Links to `users.id` (1:1). Stores doctor code, department, specialization, qualifications, experience, consultation fee, room number.
4. **`doctor_schedules`**: Links to `doctors.id` (1:N). Day of week, shift start/end times, slot interval minutes (e.g. 20m), daily patient quota.
5. **`appointments`**: Links `patients.id` and `doctors.id`. Appointment number, appointment date, time slot, status (`confirmed`, `in_consultation`, `completed`, `cancelled`), reason, clinical symptoms.
6. **`queue_tokens`**: Links `appointments.id`, `doctors.id`, `patients.id`. Daily token number (1, 2, 3...), token code (`OPD-DOC-001`), token date, status (`waiting`, `serving`, `completed`, `skipped`), called timestamp.
7. **`medical_records`**: EMR visit documentation. Diagnosis, symptoms, vitals (**blood pressure, heart rate, temperature, weight**), doctor notes, follow-up date.
8. **`prescriptions`**: Links `medical_records.id`, `appointments.id`, `patients.id`, `doctors.id`. Prescription code, dispensing status, general advice.
9. **`prescription_items`**: Line items linked to `prescriptions.id` and `medicines.id`. Dosage, frequency (e.g. 1-0-1), duration days, quantity, meal instructions.
10. **`medicines`**: Pharmacy drug catalog. Code, brand name, generic salt, category, dosage form, unit price, stock quantity, reorder warning level, batch number, expiry date.
11. **`inventory_transactions`**: Pharmacy stock movements (`stock_in`, `stock_out`, `dispensed`, `adjustment`), quantity, cost, reference.
12. **`bills`**: Itemized invoice linked to `appointments.id` and `patients.id`. Consultation fee, pharmacy fee, lab fee, total amount, paid amount, balance due, payment status (`unpaid`, `partial`, `paid`).
13. **`insurance_claims`**: Linked to `bills.id`. Provider name, policy number, claim amount, approved amount, status (`submitted`, `in_review`, `approved`, `rejected`).
14. **`lab_tests`**: Diagnostic catalog (CBC, Lipid Profile, Blood Glucose, Liver Function, Thyroid Panel, Chest X-Ray). Standard fee, normal reference range, sample required.
15. **`lab_reports`**: Prescribed tests. Sample collection date, result value, abnormal flag, completion status, technician remarks.
16. **`notifications`**: Multi-channel notifications (In-app and Twilio SMS). Title, message, channel, SMS SID, read status.
17. **`audit_logs`**: Security compliance trail. Operator user, role, action, entity type, entity ID, details, IP address, user agent.

---

## 👥 Demo User Accounts (Pre-Seeded)

The database includes pre-configured demo credentials with sample appointments, prescriptions, invoices, and OPD tokens.

| Role | Name | Email | Password | Details |
|---|---|---|---|---|
| **Admin** | Super Hospital Admin | `admin@hospital.com` | `Admin@123` | Full administrative control & KPI dashboard |
| **Doctor** | Dr. Ramesh Sharma | `dr.sharma@hospital.com` | `Doctor@123` | Senior Cardiologist (Room OPD-101) |
| **Doctor** | Dr. Priya Nair | `dr.priya@hospital.com` | `Doctor@123` | Neurologist (Room OPD-105) |
| **Doctor** | Dr. Rajesh Patel | `dr.rajesh@hospital.com` | `Doctor@123` | Orthopedic Surgeon (Room OPD-202) |
| **Doctor** | Dr. Anita Desai | `dr.anita@hospital.com` | `Doctor@123` | Pediatrician (Room OPD-108) |
| **Doctor** | Dr. Vikram Joshi | `dr.vikram@hospital.com` | `Doctor@123` | General Physician (Room OPD-110) |
| **Patient** | Lakshmi Sai Teja | `patient.sai@hospital.com` | `Patient@123` | Cardiac checkup appointment & Token #1 |
| **Patient** | Rahul Verma | `patient.rahul@hospital.com` | `Patient@123` | Hypertension visit & Token #2 |
| **Patient** | Sneha Patel | `patient.sneha@hospital.com` | `Patient@123` | Migraine consultation with Dr. Priya |

> **Pro-Tip**: The **Sign In page features 1-Click Demo Buttons** that instantly auto-fill credentials for Patient, Doctor, or Admin for quick viva and evaluation testing!

---

## 🚀 Setup & Execution Guide

### Prerequisites
- Node.js (v18 or higher)
- MySQL Server (running on port `3306`)

---

### Step 1: Configure MySQL Database Credentials
Open `backend/.env` and verify your local MySQL credentials:
```env
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=hospital_management_db
DB_USER=root
DB_PASSWORD=YOUR_MYSQL_ROOT_PASSWORD
```

> **Convenient Password Tester**:
> You can test and auto-update your password with one command:
> ```bash
> cd backend
> node scripts/testConnection.js YOUR_PASSWORD
> ```

---

### Step 2: Initialize Database Schema & Seed Data
From the `backend` folder, run:
```bash
# 1. Automatically creates the 'hospital_management_db' database and synchronizes all tables:
npm run db:init

# 2. Populates realistic demo records (Doctors, Patients, Appointments, Tokens, Medicines, Lab Tests):
npm run db:seed
```

---

### Step 3: Start the Backend REST API Server
```bash
cd backend
npm run dev
```
*Backend server will start at:* **`http://localhost:5000`**  
*Health Check:* `http://localhost:5000/health`

---

### Step 4: Start the React Frontend Application
Open a second terminal window:
```bash
cd frontend
npm run dev
```
*Frontend application will start at:* **`http://localhost:5173`**

---

## 🌐 Key REST API Endpoints

### Authentication & Profile
- `POST /api/auth/register` - Patient EHR registration
- `POST /api/auth/login` - User authentication (Patient, Doctor, Admin)
- `GET /api/auth/me` - Fetch authenticated user profile
- `POST /api/auth/register-doctor` - Admin registers new physician

### Appointments & OPD Queue
- `POST /api/appointments` - Book appointment (Transaction: creates token & initial bill, dispatches SMS)
- `GET /api/appointments` - Role-filtered appointment schedule
- `POST /api/appointments/:id/cancel` - Cancel appointment with reason
- `GET /api/queue/live` - Real-time OPD queue status for today
- `GET /api/queue/my-status` - Patient's active token & wait time estimate
- `POST /api/queue/call-next` - Doctor calls next waiting patient

### Medical Records & Clinical Room
- `POST /api/records` - Record diagnosis, vitals (BP, pulse, temp, weight), prescribe medications, and order lab tests
- `GET /api/records/patient/:patientId` - Patient's Electronic Medical Record timeline

### Pharmacy & Inventory
- `GET /api/pharmacy/medicines` - Medicines catalog with low-stock filter
- `POST /api/pharmacy/medicines` - Add drug to inventory
- `POST /api/pharmacy/medicines/:id/restock` - Restock drug units
- `POST /api/pharmacy/prescriptions/:prescriptionId/dispense` - Dispense prescription items

### Diagnostics & Laboratory
- `GET /api/lab/tests` - Diagnostic test catalog
- `POST /api/lab/order` - Order blood test or radiology imaging
- `PUT /api/lab/reports/:id` - Enter test findings, flag abnormal results, complete report

### Billing & Insurance
- `GET /api/billing` - Hospital-wide or patient-specific invoices
- `POST /api/billing/:id/pay` - Process payment (UPI, Card, Cash)
- `POST /api/billing/claim` - Submit insurance claim
- `PUT /api/billing/claim/:id/adjudicate` - Admin approves/rejects claim and updates balance

### Administration & Audit
- `GET /api/admin/stats` - Hospital KPI metrics
- `GET /api/admin/audit-logs` - Security audit trail
- `POST /api/admin/test-sms` - Interactive Twilio SMS test tool

---

## 🎓 Academic Viva & Defense Q&A

**Q1: Why is MySQL used instead of MongoDB?**  
*Answer:* A hospital management system handles strictly relational, interdependent entities—patients, appointments, physician schedules, medical prescriptions, bills, and insurance claims. MySQL with Sequelize enforces ACID properties, foreign key integrity, and transactions, preventing orphaned records or phantom double-bookings.

**Q2: How are concurrent double-bookings prevented?**  
*Answer:* Appointment booking executes within a Sequelize database transaction. Before creating an appointment record, it queries for existing active bookings matching the doctor, date, and time slot. If a conflicting slot exists, the transaction rolls back with a `409 Conflict` status.

**Q3: How does the OPD Token Queue work?**  
*Answer:* When an appointment is confirmed, a daily token number is sequentially generated (`OPD-DOC-001`). When the doctor clicks "Call Next Patient", the system updates the previous token to completed, advances the next waiting token to serving, and dispatches an automated SMS alert to the patient.

**Q4: How does Twilio SMS operate when credentials are not configured?**  
*Answer:* The `twilio.config.js` module implements a graceful fallback simulator. If Twilio keys are not provided, SMS messages are logged cleanly to the terminal and stored in the MySQL `notifications` table, ensuring the application operates smoothly without crashing during local demonstrations.
