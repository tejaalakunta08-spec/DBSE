const express = require('express');
const { createProxyMiddleware, fixRequestBody } = require('http-proxy-middleware');
const { services } = require('../config/gateway.config');
const {
  verifyGatewayToken,
  optionalGatewayToken,
  requireGatewayRoles
} = require('../middleware/auth.middleware');
const adminStatsController = require('../controllers/adminStats.controller');

const router = express.Router();

/**
 * Robust Service Proxy Creator
 * Uses req.originalUrl to preserve exact route paths without Express mount-point stripping.
 */
function createServiceProxy(target, customRewrite = null) {
  return createProxyMiddleware({
    target,
    changeOrigin: true,
    pathRewrite: (path, req) => {
      if (typeof customRewrite === 'function') {
        return customRewrite(path, req);
      }
      if (customRewrite && typeof customRewrite === 'object') {
        let rewritten = req.originalUrl.replace(/^\/api/, '');
        for (const [pattern, replacement] of Object.entries(customRewrite)) {
          rewritten = rewritten.replace(new RegExp(pattern), replacement);
        }
        return rewritten;
      }
      // Default: Strip leading /api and preserve rest of path (e.g. /api/auth/login -> /auth/login)
      return req.originalUrl.replace(/^\/api/, '');
    },
    on: {
      proxyReq: (proxyReq, req, res) => {
        if (req.user) {
          proxyReq.setHeader('x-user-id', String(req.user.id));
          proxyReq.setHeader('x-user-role', req.user.role);
          proxyReq.setHeader('x-user-name', encodeURIComponent(req.user.name || ''));
          proxyReq.setHeader('x-user-email', req.user.email || '');
          if (req.user.patientProfile?.id) {
            proxyReq.setHeader('x-patient-id', String(req.user.patientProfile.id));
          }
          if (req.user.doctorProfile?.id) {
            proxyReq.setHeader('x-doctor-id', String(req.user.doctorProfile.id));
          }
        }
        fixRequestBody(proxyReq, req);
      },
      error: (err, req, res) => {
        console.error(`[Proxy Error] Target: ${target}, Path: ${req.originalUrl}, Error: ${err.message}`);
        if (!res.headersSent) {
          res.status(503).json({
            success: false,
            message: `Microservice at ${target} is currently unavailable.`,
            error: err.message
          });
        }
      }
    }
  });
}

// =========================================================================
// 1. ADMIN ROUTES (/api/admin/*)
// =========================================================================
// Executive Dashboard Stats (Aggregator across all services)
router.get(
  '/admin/stats',
  verifyGatewayToken,
  requireGatewayRoles('admin'),
  adminStatsController.getAdminDashboardStats
);

// Admin Audit Logs (Routed to Auth Service internal audit endpoint)
router.use(
  '/admin/audit-logs',
  verifyGatewayToken,
  requireGatewayRoles('admin'),
  createServiceProxy(services.auth, { '^/admin/audit-logs': '/internal/audit-logs' })
);

// Admin User Status Toggle (Routed to Auth Service internal status endpoint)
router.use(
  '/admin/users',
  verifyGatewayToken,
  requireGatewayRoles('admin'),
  createServiceProxy(services.auth, { '^/admin/users': '/internal/users' })
);

// Admin Twilio Test SMS (Routed to Notification Service)
router.use(
  '/admin/test-sms',
  verifyGatewayToken,
  requireGatewayRoles('admin'),
  createServiceProxy(services.notification, { '^/admin/test-sms': '/api/notifications/test-sms' })
);


// =========================================================================
// 2. AUTHENTICATION & USER SERVICE (/api/auth/*, /api/patients/*)
// =========================================================================
router.use(
  '/auth',
  optionalGatewayToken,
  createServiceProxy(services.auth)
);

router.use(
  '/patients',
  verifyGatewayToken,
  createServiceProxy(services.auth)
);


// =========================================================================
// 3. DOCTOR & APPOINTMENT ROUTES (/api/doctors/*, /api/appointments/*)
// =========================================================================
// Doctor schedule & slot routes -> Appointment Service
router.use(
  '/doctors/:id/slots',
  optionalGatewayToken,
  createServiceProxy(services.appointment)
);

router.use(
  '/doctors/:id/schedule',
  optionalGatewayToken,
  createServiceProxy(services.appointment)
);

// General Doctor directory & departments -> Auth Service
router.use(
  '/doctors',
  optionalGatewayToken,
  createServiceProxy(services.auth)
);

// Appointment booking & management -> Appointment Service
router.use(
  '/appointments',
  verifyGatewayToken,
  createServiceProxy(services.appointment)
);


// =========================================================================
// 4. PATIENT & EMR SERVICE (/api/records/*)
// =========================================================================
router.use(
  '/records',
  verifyGatewayToken,
  createServiceProxy(services.emr)
);


// =========================================================================
// 5. QUEUE & TOKEN SERVICE (/api/queue/*)
// =========================================================================
router.use(
  '/queue',
  verifyGatewayToken,
  createServiceProxy(services.queue)
);


// =========================================================================
// 6. BILLING & INSURANCE SERVICE (/api/billing/*)
// =========================================================================
router.use(
  '/billing',
  verifyGatewayToken,
  createServiceProxy(services.billing)
);


// =========================================================================
// 7. PHARMACY & INVENTORY SERVICE (/api/pharmacy/*)
// =========================================================================
router.use(
  '/pharmacy',
  verifyGatewayToken,
  createServiceProxy(services.pharmacy)
);


// =========================================================================
// 8. LABORATORY SERVICE (/api/lab/*)
// =========================================================================
router.use(
  '/lab',
  verifyGatewayToken,
  createServiceProxy(services.lab)
);


// =========================================================================
// 9. NOTIFICATION SERVICE (/api/notifications/*)
// =========================================================================
router.use(
  '/notifications',
  verifyGatewayToken,
  createServiceProxy(services.notification)
);

module.exports = router;
