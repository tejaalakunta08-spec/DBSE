require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { port, corsOrigin } = require('./config/gateway.config');
const gatewayRoutes = require('./routes/gateway.routes');
const { errorHandler, notFoundHandler } = require('./middleware/error.middleware');

const app = express();

// Request logging
app.use(morgan('[:date[iso]] :method :url :status :response-time ms - :res[content-length]'));

// CORS configuration
app.use(cors({
  origin: corsOrigin || '*',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-user-id', 'x-user-role']
}));

// Body Parsers (Handled alongside fixRequestBody in proxy configuration)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health Check & Gateway Status
app.get('/health', (req, res) => {
  res.json({
    status: 'UP',
    service: 'Hospital Management System API Gateway',
    version: '1.0.0',
    port,
    timestamp: new Date().toISOString()
  });
});

// Root route
app.get('/', (req, res) => {
  res.json({
    message: 'Welcome to Hospital Management Microservices API Gateway',
    documentation: '/api/docs',
    health: '/health'
  });
});

// Mount Gateway Microservice Routes under /api
app.use('/api', gatewayRoutes);

// 404 and Error handling
app.use(notFoundHandler);
app.use(errorHandler);

app.listen(port, () => {
  console.log(`=======================================================`);
  console.log(`🚀 API GATEWAY RUNNING ON PORT ${port}`);
  console.log(`🌐 Health Check: http://127.0.0.1:${port}/health`);
  console.log(`🔗 Proxying React frontend to all 8 microservices`);
  console.log(`=======================================================`);
});

module.exports = app;
