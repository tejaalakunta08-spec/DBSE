/**
 * Centralized error handler for API Gateway
 */
function errorHandler(err, req, res, next) {
  console.error('[API Gateway Error]', {
    message: err.message,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
    url: req.originalUrl,
    method: req.method
  });

  // Handle service down / ECONNREFUSED
  if (err.code === 'ECONNREFUSED' || err.message?.includes('ECONNREFUSED')) {
    return res.status(503).json({
      success: false,
      message: 'Service Unavailable: Target microservice is temporarily offline or unreachable.',
      serviceError: err.message
    });
  }

  // Handle gateway timeout
  if (err.code === 'ETIMEDOUT' || err.code === 'ESOCKETTIMEDOUT') {
    return res.status(504).json({
      success: false,
      message: 'Gateway Timeout: Downstream microservice failed to respond in time.'
    });
  }

  const statusCode = err.statusCode || 500;
  return res.status(statusCode).json({
    success: false,
    message: err.message || 'Internal API Gateway Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
}

/**
 * 404 Route Not Found Handler
 */
function notFoundHandler(req, res) {
  return res.status(404).json({
    success: false,
    message: `API Route Not Found: [${req.method}] ${req.originalUrl}`
  });
}

module.exports = {
  errorHandler,
  notFoundHandler
};
