const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config/gateway.config');

/**
 * Middleware: Verify JWT at API Gateway level before routing.
 * Ensures only valid authenticated requests reach protected microservice resources.
 */
function verifyGatewayToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Access Denied: Missing or malformed authentication token at API Gateway.'
    });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, jwtSecret);
    req.user = decoded;

    // Decorate headers for downstream microservices
    req.headers['x-user-id'] = String(decoded.id);
    req.headers['x-user-role'] = decoded.role;
    req.headers['x-user-name'] = encodeURIComponent(decoded.name || '');
    req.headers['x-user-email'] = decoded.email || '';
    if (decoded.patientProfile?.id) {
      req.headers['x-patient-id'] = String(decoded.patientProfile.id);
    }
    if (decoded.doctorProfile?.id) {
      req.headers['x-doctor-id'] = String(decoded.doctorProfile.id);
    }

    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Session Expired: Please log in again.'
      });
    }
    return res.status(401).json({
      success: false,
      message: 'Invalid Authentication Token.'
    });
  }
}

/**
 * Middleware: Optional token extraction.
 * Decodes user if token is present, but allows anonymous access for public routes.
 */
function optionalGatewayToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    try {
      const decoded = jwt.verify(token, jwtSecret);
      req.user = decoded;
      req.headers['x-user-id'] = String(decoded.id);
      req.headers['x-user-role'] = decoded.role;
      req.headers['x-user-name'] = encodeURIComponent(decoded.name || '');
      req.headers['x-user-email'] = decoded.email || '';
      if (decoded.patientProfile?.id) {
        req.headers['x-patient-id'] = String(decoded.patientProfile.id);
      }
      if (decoded.doctorProfile?.id) {
        req.headers['x-doctor-id'] = String(decoded.doctorProfile.id);
      }
    } catch {
      // Ignore invalid token for optional routes
    }
  }
  next();
}

/**
 * Middleware: Enforce Role-Based Access Control at Gateway
 */
function requireGatewayRoles(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required.'
      });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Forbidden: Role '${req.user.role}' lacks permission for this resource.`
      });
    }

    next();
  };
}

module.exports = {
  verifyGatewayToken,
  optionalGatewayToken,
  requireGatewayRoles
};
