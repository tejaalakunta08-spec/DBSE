require('dotenv').config();

module.exports = {
  port: process.env.PORT || 5000,
  jwtSecret: process.env.JWT_SECRET || 'hospital_jwt_super_secret_key_2026_academic_project',
  corsOrigin: process.env.CORS_ORIGIN || 'http://localhost:5173',
  services: {
    auth: process.env.AUTH_SERVICE_URL || 'http://127.0.0.1:5001',
    appointment: process.env.APPOINTMENT_SERVICE_URL || 'http://127.0.0.1:5002',
    emr: process.env.EMR_SERVICE_URL || 'http://127.0.0.1:5003',
    queue: process.env.QUEUE_SERVICE_URL || 'http://127.0.0.1:5004',
    billing: process.env.BILLING_SERVICE_URL || 'http://127.0.0.1:5005',
    pharmacy: process.env.PHARMACY_SERVICE_URL || 'http://127.0.0.1:5006',
    lab: process.env.LAB_SERVICE_URL || 'http://127.0.0.1:5007',
    notification: process.env.NOTIFICATION_SERVICE_URL || 'http://127.0.0.1:5008'
  }
};
