const { services } = require('../config/gateway.config');

/**
 * Controller: Executive Dashboard Aggregator
 * Orchestrates calls across all microservices' internal stats endpoints to compile
 * a unified hospital operations overview for the Admin Command Center.
 */
exports.getAdminDashboardStats = async (req, res, next) => {
  try {
    const fetchSafe = async (url, fallback) => {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 3500);
        const response = await fetch(url, { signal: controller.signal });
        clearTimeout(timeout);
        if (!response.ok) return fallback;
        const json = await response.json();
        return json.success ? json.data : fallback;
      } catch (err) {
        console.warn(`[Gateway Aggregator] Warning: Failed fetching ${url}: ${err.message}`);
        return fallback;
      }
    };

    const [
      authStats,
      appointmentStats,
      billingStats,
      pharmacyStats,
      labStats,
      queueStats
    ] = await Promise.all([
      fetchSafe(`${services.auth}/internal/stats`, { totalPatients: 0, totalDoctors: 0 }),
      fetchSafe(`${services.appointment}/internal/stats`, { todayAppointmentsCount: 0, recentAppointments: [] }),
      fetchSafe(`${services.billing}/internal/stats`, { totalRevenue: '0.00', pendingClaims: 0 }),
      fetchSafe(`${services.pharmacy}/internal/stats`, { lowStockCount: 0, totalMedicines: 0 }),
      fetchSafe(`${services.lab}/internal/stats`, { pendingLabTestsCount: 0 }),
      fetchSafe(`${services.queue}/internal/stats`, { activeQueueCount: 0 })
    ]);

    return res.json({
      success: true,
      data: {
        totalPatients: authStats.totalPatients || 0,
        totalDoctors: authStats.totalDoctors || 0,
        todayAppointmentsCount: appointmentStats.todayAppointmentsCount || 0,
        totalRevenue: billingStats.totalRevenue || '0.00',
        lowStockCount: pharmacyStats.lowStockCount || 0,
        pendingLabTestsCount: labStats.pendingLabTestsCount || 0,
        activeQueueCount: queueStats.activeQueueCount || 0,
        recentAppointments: appointmentStats.recentAppointments || [],
        twilioConfigured: true
      }
    });
  } catch (error) {
    next(error);
  }
};
