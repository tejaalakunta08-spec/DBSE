const { sequelize, ensureDatabaseExists, DB_NAME } = require('../src/config/db.config');
const models = require('../src/models');

async function initDatabase() {
  try {
    console.log(`[InitDB] Step 1: Ensuring database '${DB_NAME}' exists...`);
    await ensureDatabaseExists();

    console.log('[InitDB] Step 2: Authenticating with MySQL...');
    await sequelize.authenticate();
    console.log('[InitDB] MySQL connection verified.');

    console.log('[InitDB] Step 3: Synchronizing all normalized tables (force: true)...');
    await sequelize.sync({ force: true });
    console.log('✅ [InitDB] All 15+ database tables created successfully!');

    process.exit(0);
  } catch (error) {
    console.error('❌ [InitDB Error] Failed to initialize database:', error.message);
    process.exit(1);
  }
}

initDatabase();
