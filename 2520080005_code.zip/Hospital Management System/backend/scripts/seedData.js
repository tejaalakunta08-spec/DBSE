const { sequelize } = require('../src/models');
const { ensureDatabaseExists } = require('../src/config/db.config');
const {
  User,
  Doctor,
  DoctorSchedule,
  Patient,
  Medicine,
  InventoryTransaction,
  LabTest,
  Appointment,
  QueueToken,
  MedicalRecord,
  Prescription,
  PrescriptionItem,
  Bill,
  InsuranceClaim,
  LabReport,
  Notification,
  AuditLog
} = require('../src/models');

async function seedDatabase() {
  try {
    console.log('[Seed] Ensuring database exists and tables are synchronized...');
    await ensureDatabaseExists();
    await sequelize.authenticate();
    await sequelize.sync({ force: true });
    console.log('[Seed] Schema synced cleanly.');

    // 1. Create Admin User
    console.log('[Seed] Creating Admin...');
    const admin = await User.create({
      name: 'Super Hospital Admin',
      email: 'admin@hospital.com',
      password: 'Admin@123',
      role: 'admin',
      phone: '+919876543210',
      status: 'active'
    });

    // 2. Create Doctors
    console.log('[Seed] Creating Doctors & Schedules...');
    const doctorUsersData = [
      {
        name: 'Ramesh Sharma',
        email: 'dr.sharma@hospital.com',
        password: 'Doctor@123',
        role: 'doctor',
        phone: '+919811122334',
        department: 'Cardiology',
        specialization: 'Interventional Cardiology',
        qualification: 'MBBS, MD, DM (Cardiology), FACC',
        experienceYears: 14,
        consultationFee: 800.00,
        roomNumber: 'OPD-101',
        bio: 'Senior consultant cardiologist specializing in heart failure, coronary interventions, and preventative cardiology.'
      },
      {
        name: 'Priya Nair',
        email: 'dr.priya@hospital.com',
        password: 'Doctor@123',
        role: 'doctor',
        phone: '+919822233445',
        department: 'Neurology',
        specialization: 'Clinical Neurology & Epilepsy',
        qualification: 'MBBS, MD, DM (Neurology)',
        experienceYears: 10,
        consultationFee: 750.00,
        roomNumber: 'OPD-105',
        bio: 'Leading neurologist focusing on migraine management, stroke rehabilitation, and neuropathy.'
      },
      {
        name: 'Rajesh Patel',
        email: 'dr.rajesh@hospital.com',
        password: 'Doctor@123',
        role: 'doctor',
        phone: '+919833344556',
        department: 'Orthopedics',
        specialization: 'Joint Replacement & Arthroscopy',
        qualification: 'MBBS, MS (Ortho), M.Ch',
        experienceYears: 12,
        consultationFee: 700.00,
        roomNumber: 'OPD-202',
        bio: 'Specialist in robotic knee and hip replacements, sports injury management, and spine disorders.'
      },
      {
        name: 'Anita Desai',
        email: 'dr.anita@hospital.com',
        password: 'Doctor@123',
        role: 'doctor',
        phone: '+919844455667',
        department: 'Pediatrics',
        specialization: 'General Pediatrics & Neonatology',
        qualification: 'MBBS, MD (Pediatrics), DCH',
        experienceYears: 8,
        consultationFee: 600.00,
        roomNumber: 'OPD-108',
        bio: 'Dedicated pediatrician providing comprehensive child health care, vaccinations, and growth assessments.'
      },
      {
        name: 'Vikram Joshi',
        email: 'dr.vikram@hospital.com',
        password: 'Doctor@123',
        role: 'doctor',
        phone: '+919855566778',
        department: 'General Medicine',
        specialization: 'Internal Medicine & Diabetology',
        qualification: 'MBBS, MD (Internal Medicine)',
        experienceYears: 15,
        consultationFee: 500.00,
        roomNumber: 'OPD-110',
        bio: 'General physician expert in metabolic syndrome, lifestyle disease reversal, infectious diseases, and hypertension.'
      }
    ];

    const createdDoctors = [];
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    for (const dData of doctorUsersData) {
      const u = await User.create({
        name: dData.name,
        email: dData.email,
        password: dData.password,
        role: dData.role,
        phone: dData.phone,
        status: 'active'
      });

      const doc = await Doctor.create({
        userId: u.id,
        doctorCode: `DOC-${dData.department.slice(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`,
        department: dData.department,
        specialization: dData.specialization,
        qualification: dData.qualification,
        experienceYears: dData.experienceYears,
        consultationFee: dData.consultationFee,
        roomNumber: dData.roomNumber,
        bio: dData.bio,
        isAvailableToday: true
      });

      // Schedules for Monday - Saturday
      for (const day of days) {
        await DoctorSchedule.create({
          doctorId: doc.id,
          dayOfWeek: day,
          startTime: '09:00:00',
          endTime: '17:00:00',
          slotDurationMinutes: 20,
          maxPatients: 25,
          isAvailable: true
        });
      }

      createdDoctors.push({ user: u, doctor: doc });
    }

    // 3. Create Patients
    console.log('[Seed] Creating Patients...');
    const patientUsersData = [
      {
        name: 'Lakshmi Sai Teja',
        email: 'patient.sai@hospital.com',
        password: 'Patient@123',
        phone: '+919100011223',
        dob: '2001-08-15',
        gender: 'male',
        bloodGroup: 'B+',
        address: 'H.No 4-22, Jubilee Hills, Hyderabad, India',
        emergencyContactName: 'Alakunta Srinivas',
        emergencyContactPhone: '+919100099887',
        allergies: 'Penicillin allergy',
        chronicConditions: 'Mild Seasonal Asthma',
        insuranceProvider: 'Star Health Care Allied Insurance',
        insurancePolicyNumber: 'SH-POL-8839210'
      },
      {
        name: 'Rahul Verma',
        email: 'patient.rahul@hospital.com',
        password: 'Patient@123',
        phone: '+919200022334',
        dob: '1995-04-12',
        gender: 'male',
        bloodGroup: 'O+',
        address: 'Flat 302, Green Meadows, Bengaluru, India',
        emergencyContactName: 'Meera Verma',
        emergencyContactPhone: '+919200088776',
        allergies: 'None',
        chronicConditions: 'Hypertension',
        insuranceProvider: 'HDFC ERGO General Insurance',
        insurancePolicyNumber: 'HE-9921445'
      },
      {
        name: 'Sneha Patel',
        email: 'patient.sneha@hospital.com',
        password: 'Patient@123',
        phone: '+919300033445',
        dob: '1998-11-20',
        gender: 'female',
        bloodGroup: 'A+',
        address: 'Villa 14, Lotus Palms, Ahmedabad, India',
        emergencyContactName: 'Kunal Patel',
        emergencyContactPhone: '+919300077665',
        allergies: 'Sulfa drugs',
        chronicConditions: 'None',
        insuranceProvider: 'Care Health Insurance',
        insurancePolicyNumber: 'CHI-7712398'
      }
    ];

    const createdPatients = [];
    for (const pData of patientUsersData) {
      const u = await User.create({
        name: pData.name,
        email: pData.email,
        password: pData.password,
        role: 'patient',
        phone: pData.phone,
        status: 'active'
      });

      const pat = await Patient.create({
        userId: u.id,
        patientCode: `PAT-${Math.floor(10000 + Math.random() * 90000)}`,
        dob: pData.dob,
        gender: pData.gender,
        bloodGroup: pData.bloodGroup,
        address: pData.address,
        emergencyContactName: pData.emergencyContactName,
        emergencyContactPhone: pData.emergencyContactPhone,
        allergies: pData.allergies,
        chronicConditions: pData.chronicConditions,
        insuranceProvider: pData.insuranceProvider,
        insurancePolicyNumber: pData.insurancePolicyNumber
      });

      createdPatients.push({ user: u, patient: pat });
    }

    // 4. Create Pharmacy Medicines & Initial Inventory
    console.log('[Seed] Creating Medicines & Inventory...');
    const medicinesData = [
      { code: 'MED-1001', name: 'Paracetamol 650mg', genericName: 'Acetaminophen', category: 'Analgesics', manufacturer: 'Cipla Ltd', dosageForm: 'Tablet', strength: '650mg', unitPrice: 3.50, stockQuantity: 250, reorderLevel: 50, batchNumber: 'BAT-PCM-01', expiryDate: '2027-10-15' },
      { code: 'MED-1002', name: 'Amoxicillin 500mg', genericName: 'Amoxicillin Trihydrate', category: 'Antibiotics', manufacturer: 'Sun Pharma', dosageForm: 'Capsule', strength: '500mg', unitPrice: 12.00, stockQuantity: 180, reorderLevel: 40, batchNumber: 'BAT-AMX-02', expiryDate: '2026-12-31' },
      { code: 'MED-1003', name: 'Atorvastatin 20mg', genericName: 'Atorvastatin Calcium', category: 'Cardiovascular', manufacturer: 'Dr. Reddys', dosageForm: 'Tablet', strength: '20mg', unitPrice: 18.50, stockQuantity: 120, reorderLevel: 30, batchNumber: 'BAT-ATV-03', expiryDate: '2028-04-20' },
      { code: 'MED-1004', name: 'Metformin 500mg ER', genericName: 'Metformin Hydrochloride', category: 'Antidiabetic', manufacturer: 'Torrent Pharma', dosageForm: 'Tablet', strength: '500mg', unitPrice: 8.00, stockQuantity: 300, reorderLevel: 50, batchNumber: 'BAT-MET-04', expiryDate: '2027-08-30' },
      { code: 'MED-1005', name: 'Cetirizine 10mg', genericName: 'Cetirizine Dihydrochloride', category: 'Antihistamines', manufacturer: 'Alkem Labs', dosageForm: 'Tablet', strength: '10mg', unitPrice: 4.50, stockQuantity: 15, reorderLevel: 25, batchNumber: 'BAT-CET-05', expiryDate: '2027-02-14' }, // LOW STOCK ALERT!
      { code: 'MED-1006', name: 'Omeprazole 20mg', genericName: 'Omeprazole', category: 'Gastrointestinal', manufacturer: 'Zydus Cadila', dosageForm: 'Capsule', strength: '20mg', unitPrice: 9.00, stockQuantity: 140, reorderLevel: 30, batchNumber: 'BAT-OMP-06', expiryDate: '2027-11-25' },
      { code: 'MED-1007', name: 'Azithromycin 500mg', genericName: 'Azithromycin', category: 'Antibiotics', manufacturer: 'Lupin Ltd', dosageForm: 'Tablet', strength: '500mg', unitPrice: 22.00, stockQuantity: 8, reorderLevel: 20, batchNumber: 'BAT-AZI-07', expiryDate: '2026-11-10' }, // LOW STOCK ALERT!
      { code: 'MED-1008', name: 'Cough Syrup 100ml', genericName: 'Dextromethorphan + Chlorpheniramine', category: 'Respiratory', manufacturer: 'Abbott', dosageForm: 'Syrup', strength: '100ml', unitPrice: 110.00, stockQuantity: 75, reorderLevel: 15, batchNumber: 'BAT-CS-08', expiryDate: '2027-06-18' }
    ];

    const createdMedicines = [];
    for (const m of medicinesData) {
      const med = await Medicine.create(m);
      await InventoryTransaction.create({
        medicineId: med.id,
        transactionType: 'stock_in',
        quantity: med.stockQuantity,
        unitCost: med.unitPrice,
        referenceType: 'InitialStock',
        notes: 'Initial warehouse stocking',
        performedBy: 'Super Hospital Admin'
      });
      createdMedicines.push(med);
    }

    // 5. Create Lab Diagnostic Tests Catalog
    console.log('[Seed] Creating Lab Tests...');
    const labTestsData = [
      { code: 'LAB-101', name: 'Complete Blood Count (CBC)', category: 'Hematology', standardFee: 350.00, normalRange: 'WBC: 4,000-11,000 /mcL, Hb: 13-17 g/dL', unit: 'Various', sampleRequired: 'Whole Blood (EDTA)', description: 'Analyzes red cells, white blood cells, hemoglobin, and platelets.' },
      { code: 'LAB-102', name: 'Lipid Profile Screen', category: 'Biochemistry', standardFee: 650.00, normalRange: 'Cholesterol < 200, LDL < 100, HDL > 40 mg/dL', unit: 'mg/dL', sampleRequired: 'Blood - Serum (Fasting)', description: 'Evaluates cardiac risk factors and cholesterol balance.' },
      { code: 'LAB-103', name: 'Fasting Blood Glucose & HbA1c', category: 'Endocrinology', standardFee: 500.00, normalRange: 'FBS: 70-99 mg/dL, HbA1c < 5.7%', unit: 'mg/dL / %', sampleRequired: 'Blood - Fluoride / EDTA', description: 'Screening and management of diabetes mellitus.' },
      { code: 'LAB-104', name: 'Liver Function Test (LFT)', category: 'Biochemistry', standardFee: 750.00, normalRange: 'ALT: 7-56 U/L, AST: 10-40 U/L, Bilirubin < 1.2 mg/dL', unit: 'U/L', sampleRequired: 'Blood - Serum', description: 'Measures liver enzymes, proteins, and bilirubin levels.' },
      { code: 'LAB-105', name: 'Thyroid Stimulating Hormone (TSH)', category: 'Endocrinology', standardFee: 450.00, normalRange: '0.4 - 4.0 mIU/L', unit: 'mIU/L', sampleRequired: 'Blood - Serum', description: 'Screens for hypo- and hyperthyroidism.' },
      { code: 'LAB-106', name: 'Chest X-Ray PA View', category: 'Radiology', standardFee: 550.00, normalRange: 'Clear lung fields, normal cardiac silhouette', unit: 'Imaging', sampleRequired: 'Radiological scan', description: 'Digital radiological examination of lungs, ribs, and heart.' }
    ];

    const createdLabTests = [];
    for (const lt of labTestsData) {
      const test = await LabTest.create(lt);
      createdLabTests.push(test);
    }

    // 6. Create Realistic Appointments, Queue Tokens, Invoices & EMR
    console.log('[Seed] Creating Appointments, Queue, Invoices, EMR...');
    const today = new Date().toISOString().split('T')[0];

    // Appointment 1: Today for Lakshmi Sai Teja with Dr. Sharma (Cardiology) - Serving in queue!
    const apt1 = await Appointment.create({
      appointmentNumber: `APT-${today.replace(/-/g, '')}-101`,
      patientId: createdPatients[0].patient.id,
      doctorId: createdDoctors[0].doctor.id,
      appointmentDate: today,
      timeSlot: '09:40 AM',
      status: 'in_consultation',
      reason: 'Routine cardiac health review and occasional palpitations.',
      symptoms: 'Mild shortness of breath on exertion, lightheadedness.'
    });

    const token1 = await QueueToken.create({
      appointmentId: apt1.id,
      doctorId: createdDoctors[0].doctor.id,
      patientId: createdPatients[0].patient.id,
      tokenNumber: 1,
      tokenCode: `OPD-${createdDoctors[0].doctor.doctorCode}-001`,
      tokenDate: today,
      status: 'serving',
      estimatedTime: '09:40 AM',
      calledAt: new Date()
    });

    const bill1 = await Bill.create({
      billNumber: `INV-${today.replace(/-/g, '')}-5001`,
      appointmentId: apt1.id,
      patientId: createdPatients[0].patient.id,
      consultationFee: 800.00,
      medicineFee: 185.00,
      labFee: 650.00,
      otherCharges: 0.00,
      subtotal: 1635.00,
      taxAmount: 0.00,
      discountAmount: 100.00,
      totalAmount: 1535.00,
      paidAmount: 1535.00,
      balanceAmount: 0.00,
      paymentStatus: 'paid',
      paymentMethod: 'upi',
      transactionReference: 'UPI-REF-8849201948',
      billDate: today
    });

    const claim1 = await InsuranceClaim.create({
      claimNumber: `CLM-${Date.now().toString().slice(-6)}01`,
      billId: bill1.id,
      patientId: createdPatients[0].patient.id,
      providerName: 'Star Health Care Allied Insurance',
      policyNumber: 'SH-POL-8839210',
      claimAmount: 1535.00,
      approvedAmount: 1435.00,
      claimStatus: 'approved',
      submissionDate: today,
      adjudicationDate: today,
      remarks: 'Covered under cardiac preventive wellness package.'
    });

    // Medical Record & Prescription for Appointment 1
    const mr1 = await MedicalRecord.create({
      appointmentId: apt1.id,
      patientId: createdPatients[0].patient.id,
      doctorId: createdDoctors[0].doctor.id,
      visitDate: today,
      symptoms: 'Occasional palpitations after heavy meals, mild dyspnea.',
      diagnosis: 'Sinus Tachycardia, Borderline Dyslipidemia',
      bloodPressure: '128/82',
      heartRate: 84,
      temperature: 98.4,
      weight: 68.5,
      doctorNotes: 'Advised 30 minutes brisk walking daily. Low sodium, Mediterranean-style diet. Follow up in 30 days.',
      followUpDate: '2026-10-30'
    });

    const rx1 = await Prescription.create({
      prescriptionCode: `RX-${Date.now().toString().slice(-6)}01`,
      medicalRecordId: mr1.id,
      appointmentId: apt1.id,
      patientId: createdPatients[0].patient.id,
      doctorId: createdDoctors[0].doctor.id,
      status: 'dispensed',
      generalAdvice: 'Drink 3 liters of water daily. Avoid excess caffeine.'
    });

    await PrescriptionItem.create({
      prescriptionId: rx1.id,
      medicineId: createdMedicines[2].id, // Atorvastatin
      medicineName: 'Atorvastatin 20mg',
      dosage: '1 tablet',
      frequency: '0-0-1 (Once daily at bedtime)',
      durationDays: 30,
      quantity: 30,
      instructions: 'Take after dinner with water'
    });

    // Lab Report for Appointment 1 (Lipid Profile)
    await LabReport.create({
      reportNumber: `LBR-${Date.now().toString().slice(-6)}01`,
      testId: createdLabTests[1].id, // Lipid Profile
      appointmentId: apt1.id,
      patientId: createdPatients[0].patient.id,
      doctorId: createdDoctors[0].doctor.id,
      prescribedDate: today,
      sampleCollectedDate: new Date(),
      resultDate: new Date(),
      resultValue: 'Total Cholesterol: 215 mg/dL (Borderline High), Triglycerides: 160 mg/dL, HDL: 44 mg/dL, LDL: 139 mg/dL',
      normalRangeSnapshot: createdLabTests[1].normalRange,
      unit: 'mg/dL',
      status: 'completed',
      isAbnormal: true,
      technicianNotes: 'Lipemic serum sample. Recheck recommended in 6-8 weeks.'
    });

    // Appointment 2: Today for Rahul Verma with Dr. Sharma (Waiting token #2)
    const apt2 = await Appointment.create({
      appointmentNumber: `APT-${today.replace(/-/g, '')}-102`,
      patientId: createdPatients[1].patient.id,
      doctorId: createdDoctors[0].doctor.id,
      appointmentDate: today,
      timeSlot: '10:00 AM',
      status: 'confirmed',
      reason: 'Hypertension follow-up and blood pressure monitoring.',
      symptoms: 'Mild morning headache.'
    });

    const token2 = await QueueToken.create({
      appointmentId: apt2.id,
      doctorId: createdDoctors[0].doctor.id,
      patientId: createdPatients[1].patient.id,
      tokenNumber: 2,
      tokenCode: `OPD-${createdDoctors[0].doctor.doctorCode}-002`,
      tokenDate: today,
      status: 'waiting',
      estimatedTime: '10:00 AM'
    });

    const bill2 = await Bill.create({
      billNumber: `INV-${today.replace(/-/g, '')}-5002`,
      appointmentId: apt2.id,
      patientId: createdPatients[1].patient.id,
      consultationFee: 800.00,
      medicineFee: 0.00,
      labFee: 0.00,
      otherCharges: 0.00,
      subtotal: 800.00,
      taxAmount: 0.00,
      discountAmount: 0.00,
      totalAmount: 800.00,
      paidAmount: 0.00,
      balanceAmount: 800.00,
      paymentStatus: 'unpaid',
      paymentMethod: 'cash',
      billDate: today
    });

    // Appointment 3: Sneha Patel with Dr. Priya Nair (Neurology)
    const apt3 = await Appointment.create({
      appointmentNumber: `APT-${today.replace(/-/g, '')}-103`,
      patientId: createdPatients[2].patient.id,
      doctorId: createdDoctors[1].doctor.id,
      appointmentDate: today,
      timeSlot: '11:20 AM',
      status: 'confirmed',
      reason: 'Throbbing migraine episodes and photophobia.',
      symptoms: 'Unilateral head pain lasting 8 hours, sensitivity to sound.'
    });

    await QueueToken.create({
      appointmentId: apt3.id,
      doctorId: createdDoctors[1].doctor.id,
      patientId: createdPatients[2].patient.id,
      tokenNumber: 1,
      tokenCode: `OPD-${createdDoctors[1].doctor.doctorCode}-001`,
      tokenDate: today,
      status: 'waiting',
      estimatedTime: '11:20 AM'
    });

    await Bill.create({
      billNumber: `INV-${today.replace(/-/g, '')}-5003`,
      appointmentId: apt3.id,
      patientId: createdPatients[2].patient.id,
      consultationFee: 750.00,
      medicineFee: 0.00,
      labFee: 0.00,
      otherCharges: 0.00,
      subtotal: 750.00,
      taxAmount: 0.00,
      discountAmount: 0.00,
      totalAmount: 750.00,
      paidAmount: 750.00,
      balanceAmount: 0.00,
      paymentStatus: 'paid',
      paymentMethod: 'credit_card',
      transactionReference: 'CARD-AUTH-991203',
      billDate: today
    });

    // 7. Seed Notifications
    console.log('[Seed] Creating Notifications...');
    await Notification.create({
      userId: createdPatients[0].user.id,
      recipientPhone: createdPatients[0].user.phone,
      title: 'Appointment Confirmed',
      message: `Your appointment with Dr. Ramesh Sharma is confirmed for today at 09:40 AM. OPD Token: #1`,
      channel: 'both',
      notificationType: 'appointment_confirmed',
      isRead: false,
      smsStatus: 'simulated'
    });

    await Notification.create({
      userId: createdPatients[0].user.id,
      recipientPhone: createdPatients[0].user.phone,
      title: 'Lab Report Ready',
      message: `Your Lipid Profile report is ready for viewing. Total Cholesterol is 215 mg/dL.`,
      channel: 'both',
      notificationType: 'lab_result_ready',
      isRead: true,
      smsStatus: 'simulated'
    });

    // 8. Seed Audit Logs
    console.log('[Seed] Creating Audit Logs...');
    await AuditLog.create({
      userId: admin.id,
      userName: admin.name,
      role: 'admin',
      action: 'SYSTEM_INITIALIZATION',
      entityType: 'System',
      entityId: '0',
      details: 'Hospital Management System database schema initialized with seed master data.',
      ipAddress: '127.0.0.1'
    });

    await AuditLog.create({
      userId: createdPatients[0].user.id,
      userName: createdPatients[0].user.name,
      role: 'patient',
      action: 'APPOINTMENT_BOOKED',
      entityType: 'Appointment',
      entityId: String(apt1.id),
      details: 'Booked appointment with Dr. Ramesh Sharma',
      ipAddress: '127.0.0.1'
    });

    console.log('========================================================================');
    console.log('🎉 [Seed Success] Database populated with comprehensive demo records!');
    console.log('========================================================================');
    console.log('👑 Admin Credentials:   email: admin@hospital.com        | pass: Admin@123');
    console.log('🩺 Doctor Credentials:  email: dr.sharma@hospital.com    | pass: Doctor@123');
    console.log('                        email: dr.priya@hospital.com     | pass: Doctor@123');
    console.log('                        email: dr.rajesh@hospital.com    | pass: Doctor@123');
    console.log('👤 Patient Credentials: email: patient.sai@hospital.com  | pass: Patient@123');
    console.log('                        email: patient.rahul@hospital.com| pass: Patient@123');
    console.log('========================================================================');

    process.exit(0);
  } catch (error) {
    console.error('❌ [Seed Error] Failed to seed database:', error.message);
    process.exit(1);
  }
}

seedDatabase();
