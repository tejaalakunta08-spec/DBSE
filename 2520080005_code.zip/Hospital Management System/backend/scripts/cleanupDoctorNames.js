const { sequelize, User } = require('../src/models');

async function cleanDoctors() {
  try {
    const doctors = await User.findAll({ where: { role: 'doctor' } });
    for (const doc of doctors) {
      const cleanName = doc.name.replace(/^(Dr\.\s*|Dr\s+)+/i, '').trim();
      if (cleanName !== doc.name) {
        console.log(`Updating doctor id ${doc.id}: "${doc.name}" -> "${cleanName}"`);
        await doc.update({ name: cleanName });
      }
    }

    // Also update notifications and audit logs if any contain Dr. Dr.
    await sequelize.query("UPDATE notifications SET message = REPLACE(message, 'Dr. Dr. ', 'Dr. ') WHERE message LIKE '%Dr. Dr.%'");
    await sequelize.query("UPDATE audit_logs SET details = REPLACE(details, 'Dr. Dr. ', 'Dr. ') WHERE details LIKE '%Dr. Dr.%'");

    const updated = await User.findAll({ where: { role: 'doctor' }, attributes: ['id', 'name', 'role'] });
    console.log('Doctors after update:', updated.map(u => u.toJSON()));
  } catch (err) {
    console.error('Error cleaning doctors:', err);
  } finally {
    await sequelize.close();
  }
}

cleanDoctors();
