require('dotenv').config();
const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

async function test() {
  const host = process.env.DB_HOST || '127.0.0.1';
  const port = process.env.DB_PORT || 3306;
  const user = process.env.DB_USER || 'root';
  const candidatePassword = process.argv[2] !== undefined ? process.argv[2] : (process.env.DB_PASSWORD || '');

  console.log(`Testing MySQL connection to ${user}@${host}:${port} with password: '${candidatePassword}'...`);
  try {
    const conn = await mysql.createConnection({ host, port, user, password: candidatePassword });
    console.log('✅ Connection to MySQL succeeded!');
    await conn.end();

    // Auto-update .env with the working password
    const envPath = path.join(__dirname, '..', '.env');
    if (fs.existsSync(envPath)) {
      let content = fs.readFileSync(envPath, 'utf8');
      content = content.replace(/DB_PASSWORD=.*/, `DB_PASSWORD=${candidatePassword}`);
      fs.writeFileSync(envPath, content, 'utf8');
      console.log(`[Auto-Config] Updated backend/.env with DB_PASSWORD=${candidatePassword}`);
    }

    process.exit(0);
  } catch (err) {
    console.error('❌ Connection failed:', err.message);
    process.exit(1);
  }
}

test();
