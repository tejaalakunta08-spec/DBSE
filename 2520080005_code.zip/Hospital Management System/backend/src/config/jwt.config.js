require('dotenv').config();

module.exports = {
  secret: process.env.JWT_SECRET || 'hospital_jwt_super_secret_key_2026_academic_project',
  expiresIn: process.env.JWT_EXPIRES_IN || '7d'
};
