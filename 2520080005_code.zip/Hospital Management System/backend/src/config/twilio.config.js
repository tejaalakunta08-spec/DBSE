require('dotenv').config();

let twilioClient = null;
const isConfigured = !!(
  process.env.TWILIO_ACCOUNT_SID &&
  process.env.TWILIO_AUTH_TOKEN &&
  process.env.TWILIO_PHONE_NUMBER
);

if (isConfigured) {
  try {
    const twilio = require('twilio');
    twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    console.log('[Twilio] Twilio client initialized successfully.');
  } catch (err) {
    console.warn('[Twilio] Failed to initialize Twilio client:', err.message);
  }
} else {
  console.log('[Twilio] Running in mock/simulation mode (no credentials provided). SMS will be logged to console & MySQL database.');
}

/**
 * Send SMS notification via Twilio or fallback simulator.
 * @param {string} to - Recipient phone number in E.164 format (+91...)
 * @param {string} body - SMS content
 * @returns {Promise<{success: boolean, sid?: string, mode: string, error?: string}>}
 */
async function sendSms(to, body) {
  if (isConfigured && twilioClient) {
    try {
      const message = await twilioClient.messages.create({
        body,
        from: process.env.TWILIO_PHONE_NUMBER,
        to
      });
      return { success: true, sid: message.sid, mode: 'live' };
    } catch (error) {
      console.error('[Twilio Error] Failed to send real SMS:', error.message);
      return { success: false, error: error.message, mode: 'live_failed' };
    }
  }

  // Graceful Mock SMS for academic demo / development
  console.log('----------------------------------------------------');
  console.log(`[SMS MOCK DISPATCH] To: ${to}`);
  console.log(`[SMS CONTENT] ${body}`);
  console.log('----------------------------------------------------');
  return {
    success: true,
    sid: `MOCK_SMS_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
    mode: 'simulated'
  };
}

module.exports = {
  sendSms,
  isConfigured
};
