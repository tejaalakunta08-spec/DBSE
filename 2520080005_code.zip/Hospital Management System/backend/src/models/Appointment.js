const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const Appointment = sequelize.define('Appointment', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  appointmentNumber: {
    type: DataTypes.STRING(40),
    allowNull: false,
    unique: true
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'patients',
      key: 'id'
    },
    onDelete: 'RESTRICT'
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'doctors',
      key: 'id'
    },
    onDelete: 'RESTRICT'
  },
  appointmentDate: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  timeSlot: {
    type: DataTypes.STRING(20),
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('pending', 'confirmed', 'in_consultation', 'completed', 'cancelled', 'no_show'),
    allowNull: false,
    defaultValue: 'confirmed'
  },
  reason: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  symptoms: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  cancelledBy: {
    type: DataTypes.ENUM('patient', 'doctor', 'admin', 'system'),
    allowNull: true
  },
  cancellationReason: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'appointments',
  indexes: [
    {
      fields: ['doctorId', 'appointmentDate']
    },
    {
      fields: ['patientId']
    },
    {
      fields: ['status']
    }
  ]
});

module.exports = Appointment;
