const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const PrescriptionItem = sequelize.define('PrescriptionItem', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  prescriptionId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'prescriptions',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  medicineId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'medicines',
      key: 'id'
    },
    onDelete: 'SET NULL'
  },
  medicineName: {
    type: DataTypes.STRING(120),
    allowNull: false
  },
  dosage: {
    type: DataTypes.STRING(60),
    allowNull: false // e.g. "500 mg"
  },
  frequency: {
    type: DataTypes.STRING(60),
    allowNull: false // e.g. "1-0-1 (Twice daily after food)"
  },
  durationDays: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 5
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 10
  },
  instructions: {
    type: DataTypes.STRING(255),
    allowNull: true
  }
}, {
  tableName: 'prescription_items',
  indexes: [
    {
      fields: ['prescriptionId']
    }
  ]
});

module.exports = PrescriptionItem;
