const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const AuditLog = sequelize.define('AuditLog', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  userName: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  role: {
    type: DataTypes.STRING(30),
    allowNull: true
  },
  action: {
    type: DataTypes.STRING(100),
    allowNull: false // e.g. "USER_LOGIN", "BOOK_APPOINTMENT", "GENERATE_BILL", "CALL_TOKEN"
  },
  entityType: {
    type: DataTypes.STRING(50),
    allowNull: true // e.g. "Appointment", "Bill", "MedicalRecord"
  },
  entityId: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  details: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  ipAddress: {
    type: DataTypes.STRING(45),
    allowNull: true
  },
  userAgent: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'audit_logs',
  indexes: [
    {
      fields: ['action']
    },
    {
      fields: ['userId']
    },
    {
      fields: ['createdAt']
    }
  ]
});

module.exports = AuditLog;
