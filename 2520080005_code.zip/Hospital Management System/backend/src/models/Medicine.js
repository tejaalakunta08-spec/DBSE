const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const Medicine = sequelize.define('Medicine', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  code: {
    type: DataTypes.STRING(30),
    allowNull: false,
    unique: true
  },
  name: {
    type: DataTypes.STRING(120),
    allowNull: false
  },
  genericName: {
    type: DataTypes.STRING(120),
    allowNull: true
  },
  category: {
    type: DataTypes.STRING(60),
    allowNull: false // e.g. "Antibiotics", "Analgesics", "Antihypertensives"
  },
  manufacturer: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  dosageForm: {
    type: DataTypes.ENUM('Tablet', 'Capsule', 'Syrup', 'Injection', 'Ointment', 'Drops', 'Inhaler'),
    allowNull: false,
    defaultValue: 'Tablet'
  },
  strength: {
    type: DataTypes.STRING(40),
    allowNull: true // e.g. "500mg", "10ml"
  },
  unitPrice: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 10.00
  },
  stockQuantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  reorderLevel: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 20
  },
  batchNumber: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  expiryDate: {
    type: DataTypes.DATEONLY,
    allowNull: true
  }
}, {
  tableName: 'medicines',
  indexes: [
    {
      fields: ['name']
    },
    {
      fields: ['category']
    }
  ]
});

module.exports = Medicine;
