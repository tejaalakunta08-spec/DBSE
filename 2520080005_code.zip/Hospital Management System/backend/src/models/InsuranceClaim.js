const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const InsuranceClaim = sequelize.define('InsuranceClaim', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  claimNumber: {
    type: DataTypes.STRING(40),
    allowNull: false,
    unique: true
  },
  billId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'bills',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'patients',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  providerName: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  policyNumber: {
    type: DataTypes.STRING(60),
    allowNull: false
  },
  claimAmount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  approvedAmount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
    defaultValue: 0.00
  },
  claimStatus: {
    type: DataTypes.ENUM('submitted', 'in_review', 'approved', 'rejected', 'settled'),
    allowNull: false,
    defaultValue: 'submitted'
  },
  submissionDate: {
    type: DataTypes.DATEONLY,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  adjudicationDate: {
    type: DataTypes.DATEONLY,
    allowNull: true
  },
  remarks: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'insurance_claims',
  indexes: [
    {
      fields: ['billId']
    },
    {
      fields: ['patientId']
    },
    {
      fields: ['claimStatus']
    }
  ]
});

module.exports = InsuranceClaim;
