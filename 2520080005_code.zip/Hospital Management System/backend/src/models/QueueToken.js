const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const QueueToken = sequelize.define('QueueToken', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  appointmentId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    unique: true,
    references: {
      model: 'appointments',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'doctors',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'patients',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  tokenNumber: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  tokenCode: {
    type: DataTypes.STRING(30),
    allowNull: false
  },
  tokenDate: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('waiting', 'serving', 'completed', 'skipped', 'cancelled'),
    allowNull: false,
    defaultValue: 'waiting'
  },
  estimatedTime: {
    type: DataTypes.STRING(20),
    allowNull: true
  },
  calledAt: {
    type: DataTypes.DATE,
    allowNull: true
  },
  completedAt: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  tableName: 'queue_tokens',
  indexes: [
    {
      fields: ['doctorId', 'tokenDate', 'status']
    },
    {
      fields: ['patientId']
    }
  ]
});

module.exports = QueueToken;
