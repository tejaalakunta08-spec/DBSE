const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const LabReport = sequelize.define('LabReport', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  reportNumber: {
    type: DataTypes.STRING(40),
    allowNull: false,
    unique: true
  },
  testId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'lab_tests',
      key: 'id'
    },
    onDelete: 'RESTRICT'
  },
  appointmentId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'appointments',
      key: 'id'
    },
    onDelete: 'SET NULL'
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'patients',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'doctors',
      key: 'id'
    },
    onDelete: 'RESTRICT'
  },
  prescribedDate: {
    type: DataTypes.DATEONLY,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  sampleCollectedDate: {
    type: DataTypes.DATE,
    allowNull: true
  },
  resultDate: {
    type: DataTypes.DATE,
    allowNull: true
  },
  resultValue: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  normalRangeSnapshot: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  unit: {
    type: DataTypes.STRING(40),
    allowNull: true
  },
  status: {
    type: DataTypes.ENUM('ordered', 'sample_collected', 'in_progress', 'completed', 'cancelled'),
    allowNull: false,
    defaultValue: 'ordered'
  },
  isAbnormal: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  technicianNotes: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'lab_reports',
  indexes: [
    {
      fields: ['patientId']
    },
    {
      fields: ['doctorId']
    },
    {
      fields: ['status']
    }
  ]
});

module.exports = LabReport;
