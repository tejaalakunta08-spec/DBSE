const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const InventoryTransaction = sequelize.define('InventoryTransaction', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  medicineId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'medicines',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  transactionType: {
    type: DataTypes.ENUM('stock_in', 'stock_out', 'dispensed', 'expired_loss', 'adjustment'),
    allowNull: false
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  unitCost: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true
  },
  referenceType: {
    type: DataTypes.STRING(50),
    allowNull: true // e.g. "Prescription", "PurchaseOrder", "Manual"
  },
  referenceId: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  performedBy: {
    type: DataTypes.STRING(100),
    allowNull: true
  }
}, {
  tableName: 'inventory_transactions',
  indexes: [
    {
      fields: ['medicineId']
    },
    {
      fields: ['transactionType']
    }
  ]
});

module.exports = InventoryTransaction;
