const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const MedicalRecord = sequelize.define('MedicalRecord', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  appointmentId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'appointments',
      key: 'id'
    },
    onDelete: 'SET NULL'
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'patients',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'doctors',
      key: 'id'
    },
    onDelete: 'RESTRICT'
  },
  visitDate: {
    type: DataTypes.DATEONLY,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  symptoms: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  diagnosis: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  bloodPressure: {
    type: DataTypes.STRING(20),
    allowNull: true // e.g. "120/80"
  },
  heartRate: {
    type: DataTypes.INTEGER,
    allowNull: true // e.g. 72
  },
  temperature: {
    type: DataTypes.DECIMAL(4, 1),
    allowNull: true // e.g. 98.6
  },
  weight: {
    type: DataTypes.DECIMAL(5, 2),
    allowNull: true // in kg
  },
  doctorNotes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  followUpDate: {
    type: DataTypes.DATEONLY,
    allowNull: true
  }
}, {
  tableName: 'medical_records',
  indexes: [
    {
      fields: ['patientId']
    },
    {
      fields: ['doctorId']
    }
  ]
});

module.exports = MedicalRecord;
