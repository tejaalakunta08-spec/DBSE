const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const LabTest = sequelize.define('LabTest', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  code: {
    type: DataTypes.STRING(30),
    allowNull: false,
    unique: true
  },
  name: {
    type: DataTypes.STRING(120),
    allowNull: false
  },
  category: {
    type: DataTypes.STRING(80),
    allowNull: false // e.g. "Hematology", "Biochemistry", "Microbiology", "Radiology"
  },
  standardFee: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 300.00
  },
  normalRange: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  unit: {
    type: DataTypes.STRING(40),
    allowNull: true
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  sampleRequired: {
    type: DataTypes.STRING(60),
    allowNull: true // e.g. "Blood - Serum", "Urine", "Swab"
  }
}, {
  tableName: 'lab_tests'
});

module.exports = LabTest;
