const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const Notification = sequelize.define('Notification', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  recipientPhone: {
    type: DataTypes.STRING(25),
    allowNull: true
  },
  recipientEmail: {
    type: DataTypes.STRING(120),
    allowNull: true
  },
  title: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  message: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  channel: {
    type: DataTypes.ENUM('in_app', 'sms', 'both'),
    allowNull: false,
    defaultValue: 'in_app'
  },
  notificationType: {
    type: DataTypes.ENUM(
      'appointment_booking',
      'appointment_confirmed',
      'appointment_cancelled',
      'queue_update',
      'prescription_ready',
      'bill_generated',
      'lab_result_ready',
      'general'
    ),
    allowNull: false,
    defaultValue: 'general'
  },
  isRead: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  smsStatus: {
    type: DataTypes.ENUM('none', 'pending', 'sent', 'failed', 'simulated'),
    defaultValue: 'none'
  },
  smsSid: {
    type: DataTypes.STRING(80),
    allowNull: true
  }
}, {
  tableName: 'notifications',
  indexes: [
    {
      fields: ['userId', 'isRead']
    }
  ]
});

module.exports = Notification;
