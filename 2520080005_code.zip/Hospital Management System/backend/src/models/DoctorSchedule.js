const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const DoctorSchedule = sequelize.define('DoctorSchedule', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'doctors',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  dayOfWeek: {
    type: DataTypes.ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
    allowNull: false
  },
  startTime: {
    type: DataTypes.TIME,
    allowNull: false,
    defaultValue: '09:00:00'
  },
  endTime: {
    type: DataTypes.TIME,
    allowNull: false,
    defaultValue: '17:00:00'
  },
  slotDurationMinutes: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 20
  },
  maxPatients: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 25
  },
  isAvailable: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
}, {
  tableName: 'doctor_schedules',
  indexes: [
    {
      unique: true,
      fields: ['doctorId', 'dayOfWeek']
    }
  ]
});

module.exports = DoctorSchedule;
