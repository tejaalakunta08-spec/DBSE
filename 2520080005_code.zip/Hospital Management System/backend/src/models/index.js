const { sequelize } = require('../config/db.config');
const User = require('./User');
const Patient = require('./Patient');
const Doctor = require('./Doctor');
const DoctorSchedule = require('./DoctorSchedule');
const Appointment = require('./Appointment');
const QueueToken = require('./QueueToken');
const MedicalRecord = require('./MedicalRecord');
const Prescription = require('./Prescription');
const PrescriptionItem = require('./PrescriptionItem');
const Medicine = require('./Medicine');
const InventoryTransaction = require('./InventoryTransaction');
const Bill = require('./Bill');
const InsuranceClaim = require('./InsuranceClaim');
const LabTest = require('./LabTest');
const LabReport = require('./LabReport');
const Notification = require('./Notification');
const AuditLog = require('./AuditLog');

// 1. User & Patient
User.hasOne(Patient, { foreignKey: 'userId', as: 'patientProfile', onDelete: 'CASCADE' });
Patient.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// 2. User & Doctor
User.hasOne(Doctor, { foreignKey: 'userId', as: 'doctorProfile', onDelete: 'CASCADE' });
Doctor.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// 3. Doctor & Schedule
Doctor.hasMany(DoctorSchedule, { foreignKey: 'doctorId', as: 'schedules', onDelete: 'CASCADE' });
DoctorSchedule.belongsTo(Doctor, { foreignKey: 'doctorId', as: 'doctor' });

// 4. Appointments
Patient.hasMany(Appointment, { foreignKey: 'patientId', as: 'appointments' });
Appointment.belongsTo(Patient, { foreignKey: 'patientId', as: 'patient' });

Doctor.hasMany(Appointment, { foreignKey: 'doctorId', as: 'appointments' });
Appointment.belongsTo(Doctor, { foreignKey: 'doctorId', as: 'doctor' });

// 5. Queue Tokens
Appointment.hasOne(QueueToken, { foreignKey: 'appointmentId', as: 'queueToken', onDelete: 'CASCADE' });
QueueToken.belongsTo(Appointment, { foreignKey: 'appointmentId', as: 'appointment' });

Doctor.hasMany(QueueToken, { foreignKey: 'doctorId', as: 'tokens' });
QueueToken.belongsTo(Doctor, { foreignKey: 'doctorId', as: 'doctor' });

Patient.hasMany(QueueToken, { foreignKey: 'patientId', as: 'tokens' });
QueueToken.belongsTo(Patient, { foreignKey: 'patientId', as: 'patient' });

// 6. Medical Records (EMR)
Patient.hasMany(MedicalRecord, { foreignKey: 'patientId', as: 'medicalRecords' });
MedicalRecord.belongsTo(Patient, { foreignKey: 'patientId', as: 'patient' });

Doctor.hasMany(MedicalRecord, { foreignKey: 'doctorId', as: 'medicalRecords' });
MedicalRecord.belongsTo(Doctor, { foreignKey: 'doctorId', as: 'doctor' });

Appointment.hasOne(MedicalRecord, { foreignKey: 'appointmentId', as: 'medicalRecord' });
MedicalRecord.belongsTo(Appointment, { foreignKey: 'appointmentId', as: 'appointment' });

// 7. Prescriptions & Items
MedicalRecord.hasOne(Prescription, { foreignKey: 'medicalRecordId', as: 'prescription' });
Prescription.belongsTo(MedicalRecord, { foreignKey: 'medicalRecordId', as: 'medicalRecord' });

Appointment.hasOne(Prescription, { foreignKey: 'appointmentId', as: 'prescription' });
Prescription.belongsTo(Appointment, { foreignKey: 'appointmentId', as: 'appointment' });

Patient.hasMany(Prescription, { foreignKey: 'patientId', as: 'prescriptions' });
Prescription.belongsTo(Patient, { foreignKey: 'patientId', as: 'patient' });

Doctor.hasMany(Prescription, { foreignKey: 'doctorId', as: 'prescriptions' });
Prescription.belongsTo(Doctor, { foreignKey: 'doctorId', as: 'doctor' });

Prescription.hasMany(PrescriptionItem, { foreignKey: 'prescriptionId', as: 'items', onDelete: 'CASCADE' });
PrescriptionItem.belongsTo(Prescription, { foreignKey: 'prescriptionId', as: 'prescription' });

Medicine.hasMany(PrescriptionItem, { foreignKey: 'medicineId', as: 'prescriptions' });
PrescriptionItem.belongsTo(Medicine, { foreignKey: 'medicineId', as: 'medicine' });

// 8. Pharmacy Inventory
Medicine.hasMany(InventoryTransaction, { foreignKey: 'medicineId', as: 'transactions', onDelete: 'CASCADE' });
InventoryTransaction.belongsTo(Medicine, { foreignKey: 'medicineId', as: 'medicine' });

// 9. Billing & Insurance
Appointment.hasOne(Bill, { foreignKey: 'appointmentId', as: 'bill' });
Bill.belongsTo(Appointment, { foreignKey: 'appointmentId', as: 'appointment' });

Patient.hasMany(Bill, { foreignKey: 'patientId', as: 'bills' });
Bill.belongsTo(Patient, { foreignKey: 'patientId', as: 'patient' });

Bill.hasOne(InsuranceClaim, { foreignKey: 'billId', as: 'insuranceClaim', onDelete: 'CASCADE' });
InsuranceClaim.belongsTo(Bill, { foreignKey: 'billId', as: 'bill' });

Patient.hasMany(InsuranceClaim, { foreignKey: 'patientId', as: 'insuranceClaims' });
InsuranceClaim.belongsTo(Patient, { foreignKey: 'patientId', as: 'patient' });

// 10. Laboratory
LabTest.hasMany(LabReport, { foreignKey: 'testId', as: 'reports' });
LabReport.belongsTo(LabTest, { foreignKey: 'testId', as: 'test' });

Patient.hasMany(LabReport, { foreignKey: 'patientId', as: 'labReports' });
LabReport.belongsTo(Patient, { foreignKey: 'patientId', as: 'patient' });

Doctor.hasMany(LabReport, { foreignKey: 'doctorId', as: 'prescribedReports' });
LabReport.belongsTo(Doctor, { foreignKey: 'doctorId', as: 'doctor' });

Appointment.hasMany(LabReport, { foreignKey: 'appointmentId', as: 'labReports' });
LabReport.belongsTo(Appointment, { foreignKey: 'appointmentId', as: 'appointment' });

// 11. Notifications
User.hasMany(Notification, { foreignKey: 'userId', as: 'notifications', onDelete: 'CASCADE' });
Notification.belongsTo(User, { foreignKey: 'userId', as: 'user' });

module.exports = {
  sequelize,
  User,
  Patient,
  Doctor,
  DoctorSchedule,
  Appointment,
  QueueToken,
  MedicalRecord,
  Prescription,
  PrescriptionItem,
  Medicine,
  InventoryTransaction,
  Bill,
  InsuranceClaim,
  LabTest,
  LabReport,
  Notification,
  AuditLog
};
