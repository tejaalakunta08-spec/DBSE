const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const Prescription = sequelize.define('Prescription', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  prescriptionCode: {
    type: DataTypes.STRING(40),
    allowNull: false,
    unique: true
  },
  medicalRecordId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'medical_records',
      key: 'id'
    },
    onDelete: 'SET NULL'
  },
  appointmentId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'appointments',
      key: 'id'
    },
    onDelete: 'SET NULL'
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'patients',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'doctors',
      key: 'id'
    },
    onDelete: 'RESTRICT'
  },
  status: {
    type: DataTypes.ENUM('prescribed', 'dispensed', 'cancelled'),
    allowNull: false,
    defaultValue: 'prescribed'
  },
  generalAdvice: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'prescriptions',
  indexes: [
    {
      fields: ['patientId']
    },
    {
      fields: ['doctorId']
    }
  ]
});

module.exports = Prescription;
