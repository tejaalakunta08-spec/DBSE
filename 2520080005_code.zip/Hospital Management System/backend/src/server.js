require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { sequelize, ensureDatabaseExists } = require('./config/db.config');
const routes = require('./routes');
const { errorHandler, notFoundHandler } = require('./middleware/error.middleware');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: '*', // Allow frontend during development
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('dev'));
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'UP',
    timestamp: new Date(),
    service: 'Hospital Management System API'
  });
});

// API Root
app.use('/api', routes);

// 404 and Error Handling
app.use(notFoundHandler);
app.use(errorHandler);

// Start Server with Database Connection
async function startServer() {
  try {
    await ensureDatabaseExists();
    await sequelize.authenticate();
    console.log('[MySQL] Connection to MySQL has been established successfully.');

    // Sync database models (alter: false for safe production, alter: true for schema updates)
    await sequelize.sync({ alter: false });
    console.log('[Sequelize] All normalized models were synchronized successfully.');

    app.listen(PORT, () => {
      console.log(`====================================================`);
      console.log(`🏥 Hospital Management & Appointment System API`);
      console.log(`🚀 Server running on: http://localhost:${PORT}`);
      console.log(`📡 Health Check: http://localhost:${PORT}/health`);
      console.log(`====================================================`);
    });
  } catch (error) {
    console.error('❌ Failed to start server / connect to MySQL:', error.message);
    console.error('👉 Tip: Check your MySQL credentials in backend/.env');
  }
}

// Start only if run directly
if (require.main === module) {
  startServer();
}

module.exports = app;
