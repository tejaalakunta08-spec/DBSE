const { AuditLog } = require('../models');

/**
 * Log sensitive hospital activity for compliance and security audit trails.
 */
async function recordAuditLog({
  userId = null,
  userName = null,
  role = null,
  action,
  entityType = null,
  entityId = null,
  details = null,
  req = null
}) {
  try {
    const ipAddress = req
      ? req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '127.0.0.1'
      : '127.0.0.1';
    const userAgent = req ? req.headers['user-agent'] : null;

    const actualUserId = userId || (req?.user ? req.user.id : null);
    const actualUserName = userName || (req?.user ? req.user.name : null);
    const actualRole = role || (req?.user ? req.user.role : 'system');

    await AuditLog.create({
      userId: actualUserId,
      userName: actualUserName,
      role: actualRole,
      action,
      entityType,
      entityId: entityId ? String(entityId) : null,
      details: typeof details === 'object' ? JSON.stringify(details) : details,
      ipAddress,
      userAgent
    });
  } catch (error) {
    console.error('[Audit Log Error] Failed to write audit record:', error.message);
  }
}

module.exports = {
  recordAuditLog
};
