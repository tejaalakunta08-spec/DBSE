const { Notification } = require('../models');
const { sendSms } = require('../config/twilio.config');

/**
 * Dispatch notification through in-app and/or Twilio SMS channels.
 */
async function createNotification({
  userId,
  recipientPhone = null,
  recipientEmail = null,
  title,
  message,
  channel = 'in_app',
  notificationType = 'general'
}) {
  try {
    let smsStatus = 'none';
    let smsSid = null;

    if ((channel === 'sms' || channel === 'both') && recipientPhone) {
      const smsResult = await sendSms(recipientPhone, `${title}: ${message}`);
      smsStatus = smsResult.mode === 'live' ? 'sent' : (smsResult.mode === 'simulated' ? 'simulated' : 'failed');
      smsSid = smsResult.sid || null;
    }

    const notification = await Notification.create({
      userId,
      recipientPhone,
      recipientEmail,
      title,
      message,
      channel,
      notificationType,
      isRead: false,
      smsStatus,
      smsSid
    });

    return notification;
  } catch (error) {
    console.error('[Notification Service Error]', error.message);
    return null;
  }
}

module.exports = {
  createNotification
};
