const express = require('express');
const router = express.Router();
const billingController = require('../controllers/billing.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { requireRoles } = require('../middleware/role.middleware');

router.use(verifyToken);

router.get('/', requireRoles('patient', 'doctor', 'admin'), billingController.getAllBills);
router.get('/:id', requireRoles('patient', 'doctor', 'admin'), billingController.getBillById);
router.post('/:id/pay', requireRoles('patient', 'admin'), billingController.processPayment);
router.post('/claim', requireRoles('patient', 'admin'), billingController.submitInsuranceClaim);
router.put('/claim/:id/adjudicate', requireRoles('admin'), billingController.adjudicateClaim);

module.exports = router;
