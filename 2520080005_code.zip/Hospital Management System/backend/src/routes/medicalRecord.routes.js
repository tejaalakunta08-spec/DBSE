const express = require('express');
const router = express.Router();
const recordController = require('../controllers/medicalRecord.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { requireRoles } = require('../middleware/role.middleware');

router.use(verifyToken);

router.post('/', requireRoles('doctor', 'admin'), recordController.createMedicalRecord);
router.get('/patient/:patientId', requireRoles('doctor', 'admin', 'patient'), recordController.getRecordsByPatient);
router.get('/:id', requireRoles('doctor', 'admin', 'patient'), recordController.getRecordById);

module.exports = router;
