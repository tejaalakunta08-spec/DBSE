const express = require('express');
const router = express.Router();
const appointmentController = require('../controllers/appointment.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { requireRoles } = require('../middleware/role.middleware');

router.use(verifyToken);

router.post('/', requireRoles('patient', 'doctor', 'admin'), appointmentController.bookAppointment);
router.get('/', requireRoles('patient', 'doctor', 'admin'), appointmentController.getAppointments);
router.get('/:id', requireRoles('patient', 'doctor', 'admin'), appointmentController.getAppointmentById);
router.put('/:id/status', requireRoles('doctor', 'admin'), appointmentController.updateAppointmentStatus);
router.post('/:id/cancel', requireRoles('patient', 'doctor', 'admin'), appointmentController.cancelAppointment);

module.exports = router;
