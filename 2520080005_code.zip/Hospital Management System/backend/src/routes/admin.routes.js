const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { requireRoles } = require('../middleware/role.middleware');

router.use(verifyToken);
router.use(requireRoles('admin'));

router.get('/stats', adminController.getDashboardStats);
router.get('/audit-logs', adminController.getAuditLogs);
router.put('/users/:userId/status', adminController.updateUserStatus);
router.post('/test-sms', adminController.testTwilioSms);

module.exports = router;
