const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { requireRoles } = require('../middleware/role.middleware');

// Public routes
router.post('/register', authController.registerPatient);
router.post('/login', authController.login);

// Protected routes
router.get('/me', verifyToken, authController.getMe);
router.post('/register-doctor', verifyToken, requireRoles('admin'), authController.registerDoctor);

module.exports = router;
