const express = require('express');
const router = express.Router();
const queueController = require('../controllers/queue.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { requireRoles } = require('../middleware/role.middleware');

router.use(verifyToken);

router.get('/live', requireRoles('patient', 'doctor', 'admin'), queueController.getLiveQueue);
router.get('/my-status', requireRoles('patient'), queueController.getMyTokenStatus);
router.post('/call-next', requireRoles('doctor', 'admin'), queueController.callNextToken);
router.put('/:id/status', requireRoles('doctor', 'admin'), queueController.updateTokenStatus);

module.exports = router;
