const express = require('express');
const router = express.Router();
const doctorController = require('../controllers/doctor.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { requireRoles } = require('../middleware/role.middleware');

// Public route to view doctors and departments
router.get('/', doctorController.getAllDoctors);
router.get('/departments', doctorController.getDepartments);
router.get('/:id', doctorController.getDoctorById);
router.get('/:id/slots', doctorController.getDoctorSlots);

// Protected routes
router.put('/:id/schedule', verifyToken, requireRoles('doctor', 'admin'), doctorController.updateSchedule);

module.exports = router;
