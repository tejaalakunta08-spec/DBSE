const express = require('express');
const router = express.Router();
const labController = require('../controllers/lab.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { requireRoles } = require('../middleware/role.middleware');

router.use(verifyToken);

router.get('/tests', labController.getAllLabTests);
router.post('/tests', requireRoles('admin'), labController.addLabTest);
router.post('/order', requireRoles('doctor', 'admin'), labController.orderLabTest);
router.put('/reports/:id', requireRoles('admin'), labController.updateLabReport);
router.get('/reports', requireRoles('patient', 'doctor', 'admin'), labController.getLabReports);

module.exports = router;
