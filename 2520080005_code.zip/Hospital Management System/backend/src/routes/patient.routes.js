const express = require('express');
const router = express.Router();
const patientController = require('../controllers/patient.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { requireRoles } = require('../middleware/role.middleware');

router.use(verifyToken);

router.get('/', requireRoles('admin', 'doctor'), patientController.getAllPatients);
router.get('/:id', requireRoles('admin', 'doctor', 'patient'), patientController.getPatientById);
router.put('/:id', requireRoles('admin', 'patient'), patientController.updatePatientProfile);
router.get('/:id/emr', requireRoles('admin', 'doctor', 'patient'), patientController.getPatientEMR);

module.exports = router;
