const express = require('express');
const router = express.Router();
const pharmacyController = require('../controllers/pharmacy.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { requireRoles } = require('../middleware/role.middleware');

router.use(verifyToken);

router.get('/medicines', pharmacyController.getAllMedicines);
router.post('/medicines', requireRoles('admin'), pharmacyController.addMedicine);
router.post('/medicines/:id/restock', requireRoles('admin'), pharmacyController.restockMedicine);
router.post('/prescriptions/:prescriptionId/dispense', requireRoles('admin'), pharmacyController.dispensePrescription);
router.get('/history', requireRoles('admin'), pharmacyController.getInventoryHistory);

module.exports = router;
