const express = require('express');
const router = express.Router();

const authRoutes = require('./auth.routes');
const patientRoutes = require('./patient.routes');
const doctorRoutes = require('./doctor.routes');
const appointmentRoutes = require('./appointment.routes');
const queueRoutes = require('./queue.routes');
const medicalRecordRoutes = require('./medicalRecord.routes');
const billingRoutes = require('./billing.routes');
const pharmacyRoutes = require('./pharmacy.routes');
const labRoutes = require('./lab.routes');
const adminRoutes = require('./admin.routes');
const notificationRoutes = require('./notification.routes');

router.use('/auth', authRoutes);
router.use('/patients', patientRoutes);
router.use('/doctors', doctorRoutes);
router.use('/appointments', appointmentRoutes);
router.use('/queue', queueRoutes);
router.use('/records', medicalRecordRoutes);
router.use('/billing', billingRoutes);
router.use('/pharmacy', pharmacyRoutes);
router.use('/lab', labRoutes);
router.use('/admin', adminRoutes);
router.use('/notifications', notificationRoutes);

module.exports = router;
