const jwt = require('jsonwebtoken');
const { User, Patient, Doctor, DoctorSchedule, sequelize } = require('../models');
const jwtConfig = require('../config/jwt.config');
const { recordAuditLog } = require('../services/audit.service');

function generateToken(user) {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name
    },
    jwtConfig.secret,
    { expiresIn: jwtConfig.expiresIn }
  );
}

// 1. Patient Self-Registration
exports.registerPatient = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const {
      name,
      email,
      password,
      phone,
      dob,
      gender,
      bloodGroup,
      address,
      emergencyContactName,
      emergencyContactPhone,
      allergies,
      chronicConditions,
      insuranceProvider,
      insurancePolicyNumber
    } = req.body;

    if (!name || !email || !password) {
      await t.rollback();
      return res.status(400).json({
        success: false,
        message: 'Name, email, and password are required fields.'
      });
    }

    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      await t.rollback();
      return res.status(409).json({
        success: false,
        message: 'An account with this email already exists.'
      });
    }

    // Create User record
    const user = await User.create({
      name,
      email,
      password,
      role: 'patient',
      phone: phone || null,
      status: 'active'
    }, { transaction: t });

    // Generate unique patient code e.g. PAT-10023
    const patientCode = `PAT-${Date.now().toString().slice(-5)}${Math.floor(Math.random() * 90 + 10)}`;

    const patient = await Patient.create({
      userId: user.id,
      patientCode,
      dob: dob || null,
      gender: gender || 'other',
      bloodGroup: bloodGroup || null,
      address: address || null,
      emergencyContactName: emergencyContactName || null,
      emergencyContactPhone: emergencyContactPhone || null,
      allergies: allergies || null,
      chronicConditions: chronicConditions || null,
      insuranceProvider: insuranceProvider || null,
      insurancePolicyNumber: insurancePolicyNumber || null
    }, { transaction: t });

    await t.commit();

    await recordAuditLog({
      userId: user.id,
      userName: user.name,
      role: user.role,
      action: 'PATIENT_REGISTRATION',
      entityType: 'User',
      entityId: user.id,
      details: { patientCode },
      req
    });

    const token = generateToken(user);

    return res.status(201).json({
      success: true,
      message: 'Registration successful! Welcome to the Hospital Management System.',
      data: {
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          patientProfile: patient
        }
      }
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};

// 2. Doctor Registration (By Admin)
exports.registerDoctor = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const {
      name,
      email,
      password,
      phone,
      department,
      specialization,
      qualification,
      experienceYears,
      consultationFee,
      roomNumber,
      bio,
      schedules // Array of { dayOfWeek, startTime, endTime, slotDurationMinutes, maxPatients }
    } = req.body;

    if (!name || !email || !password || !department || !specialization) {
      await t.rollback();
      return res.status(400).json({
        success: false,
        message: 'Name, email, password, department, and specialization are required.'
      });
    }

    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      await t.rollback();
      return res.status(409).json({
        success: false,
        message: 'An account with this email already exists.'
      });
    }

    const user = await User.create({
      name,
      email,
      password,
      role: 'doctor',
      phone: phone || null,
      status: 'active'
    }, { transaction: t });

    const doctorCode = `DOC-${Date.now().toString().slice(-4)}${Math.floor(Math.random() * 90 + 10)}`;

    const doctor = await Doctor.create({
      userId: user.id,
      doctorCode,
      department,
      specialization,
      qualification: qualification || 'MBBS, MD',
      experienceYears: experienceYears || 3,
      consultationFee: consultationFee || 500.00,
      roomNumber: roomNumber || 'OPD-101',
      bio: bio || `Specialist in ${specialization} with ${experienceYears || 3}+ years experience.`
    }, { transaction: t });

    // Seed default schedule if not provided
    const defaultDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const schedulesToCreate = (schedules && schedules.length > 0)
      ? schedules.map(s => ({ ...s, doctorId: doctor.id }))
      : defaultDays.map(day => ({
          doctorId: doctor.id,
          dayOfWeek: day,
          startTime: '09:00:00',
          endTime: '17:00:00',
          slotDurationMinutes: 20,
          maxPatients: 25,
          isAvailable: true
        }));

    await DoctorSchedule.bulkCreate(schedulesToCreate, { transaction: t });

    await t.commit();

    await recordAuditLog({
      action: 'DOCTOR_CREATED',
      entityType: 'Doctor',
      entityId: doctor.id,
      details: { doctorCode, department, specialization },
      req
    });

    return res.status(201).json({
      success: true,
      message: 'Doctor account created successfully with default schedule.',
      data: {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          doctorProfile: doctor
        }
      }
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};

// 3. User Login (Patient, Doctor, Admin)
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required.'
      });
    }

    const user = await User.findOne({
      where: { email },
      include: [
        {
          model: Patient,
          as: 'patientProfile'
        },
        {
          model: Doctor,
          as: 'doctorProfile',
          include: [{ model: DoctorSchedule, as: 'schedules' }]
        }
      ]
    });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    if (user.status !== 'active') {
      return res.status(403).json({
        success: false,
        message: 'Your account is deactivated. Please contact support.'
      });
    }

    const token = generateToken(user);

    await recordAuditLog({
      userId: user.id,
      userName: user.name,
      role: user.role,
      action: 'USER_LOGIN',
      entityType: 'User',
      entityId: user.id,
      req
    });

    return res.json({
      success: true,
      message: `Welcome back, ${user.name}!`,
      data: {
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          patientProfile: user.patientProfile,
          doctorProfile: user.doctorProfile
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

// 4. Get Current User Profile
exports.getMe = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['password'] },
      include: [
        { model: Patient, as: 'patientProfile' },
        {
          model: Doctor,
          as: 'doctorProfile',
          include: [{ model: DoctorSchedule, as: 'schedules' }]
        }
      ]
    });

    return res.json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};
