const { QueueToken, Appointment, Doctor, Patient, User } = require('../models');
const { Op } = require('sequelize');
const { createNotification } = require('../services/notification.service');
const { recordAuditLog } = require('../services/audit.service');

// 1. Get Live OPD Queue for Doctor / Department / Date
exports.getLiveQueue = async (req, res, next) => {
  try {
    const { doctorId, date } = req.query;
    const targetDate = date || new Date().toISOString().split('T')[0];

    const where = { tokenDate: targetDate };

    if (req.user.role === 'doctor') {
      where.doctorId = req.user.doctorProfile?.id;
    } else if (doctorId) {
      where.doctorId = doctorId;
    }

    const tokens = await QueueToken.findAll({
      where,
      include: [
        {
          model: Patient,
          as: 'patient',
          include: [{ model: User, as: 'user', attributes: ['name', 'phone', 'email'] }]
        },
        {
          model: Doctor,
          as: 'doctor',
          include: [{ model: User, as: 'user', attributes: ['name'] }]
        },
        {
          model: Appointment,
          as: 'appointment',
          attributes: ['id', 'appointmentNumber', 'timeSlot', 'reason', 'status']
        }
      ],
      order: [['tokenNumber', 'ASC']]
    });

    const currentlyServing = tokens.find(t => t.status === 'serving') || null;
    const waitingTokens = tokens.filter(t => t.status === 'waiting');
    const completedTokens = tokens.filter(t => t.status === 'completed');

    return res.json({
      success: true,
      data: {
        date: targetDate,
        totalTokens: tokens.length,
        currentlyServing,
        waitingCount: waitingTokens.length,
        completedCount: completedTokens.length,
        tokens
      }
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Logged-In Patient's Token Status for Today
exports.getMyTokenStatus = async (req, res, next) => {
  try {
    const patientId = req.user.patientProfile?.id;
    if (!patientId) {
      return res.status(400).json({ success: false, message: 'Patient profile not found.' });
    }

    const today = new Date().toISOString().split('T')[0];

    const myToken = await QueueToken.findOne({
      where: {
        patientId,
        tokenDate: today,
        status: { [Op.ne]: 'cancelled' }
      },
      include: [
        {
          model: Doctor,
          as: 'doctor',
          include: [{ model: User, as: 'user', attributes: ['name', 'phone'] }]
        },
        {
          model: Appointment,
          as: 'appointment'
        }
      ],
      order: [['id', 'DESC']]
    });

    if (!myToken) {
      return res.json({
        success: true,
        data: null,
        message: 'No active OPD token found for today.'
      });
    }

    // Find currently serving token for this doctor
    const currentServing = await QueueToken.findOne({
      where: {
        doctorId: myToken.doctorId,
        tokenDate: today,
        status: 'serving'
      }
    });

    // Calculate how many patients are ahead
    const patientsAhead = await QueueToken.count({
      where: {
        doctorId: myToken.doctorId,
        tokenDate: today,
        status: 'waiting',
        tokenNumber: { [Op.lt]: myToken.tokenNumber }
      }
    });

    return res.json({
      success: true,
      data: {
        myToken,
        currentlyServingTokenNumber: currentServing ? currentServing.tokenNumber : null,
        currentlyServingTokenCode: currentServing ? currentServing.tokenCode : 'None',
        patientsAhead,
        estimatedWaitMinutes: (patientsAhead + 1) * 15
      }
    });
  } catch (error) {
    next(error);
  }
};

// 3. Doctor Calls Next Token (Op: Waiting -> Serving)
exports.callNextToken = async (req, res, next) => {
  try {
    const doctorId = req.user.role === 'doctor' ? req.user.doctorProfile?.id : req.body.doctorId;
    if (!doctorId) {
      return res.status(400).json({ success: false, message: 'Doctor ID is required.' });
    }

    const today = new Date().toISOString().split('T')[0];

    // Auto-complete any currently serving token
    const currentServing = await QueueToken.findOne({
      where: { doctorId, tokenDate: today, status: 'serving' }
    });

    if (currentServing) {
      await currentServing.update({
        status: 'completed',
        completedAt: new Date()
      });
      // Also update its appointment
      await Appointment.update(
        { status: 'completed' },
        { where: { id: currentServing.appointmentId } }
      );
    }

    // Find next waiting token
    const nextToken = await QueueToken.findOne({
      where: { doctorId, tokenDate: today, status: 'waiting' },
      order: [['tokenNumber', 'ASC']],
      include: [
        {
          model: Patient,
          as: 'patient',
          include: [{ model: User, as: 'user' }]
        },
        {
          model: Doctor,
          as: 'doctor',
          include: [{ model: User, as: 'user' }]
        },
        {
          model: Appointment,
          as: 'appointment'
        }
      ]
    });

    if (!nextToken) {
      return res.json({
        success: true,
        message: 'No more waiting patients in queue for today.',
        data: null
      });
    }

    await nextToken.update({
      status: 'serving',
      calledAt: new Date()
    });

    await Appointment.update(
      { status: 'in_consultation' },
      { where: { id: nextToken.appointmentId } }
    );

    // Notify patient that doctor is ready
    const patientUser = nextToken.patient.user;
    await createNotification({
      userId: patientUser.id,
      recipientPhone: patientUser.phone,
      title: 'It is your turn!',
      message: `Token #${nextToken.tokenNumber} is now being called by Dr. ${nextToken.doctor.user.name} in Room ${nextToken.doctor.roomNumber || 'OPD'}. Please proceed to the consultation room.`,
      channel: patientUser.phone ? 'both' : 'in_app',
      notificationType: 'queue_update'
    });

    await recordAuditLog({
      action: 'QUEUE_TOKEN_CALLED',
      entityType: 'QueueToken',
      entityId: nextToken.id,
      details: { tokenCode: nextToken.tokenCode, tokenNumber: nextToken.tokenNumber },
      req
    });

    return res.json({
      success: true,
      message: `Now serving Token #${nextToken.tokenNumber} (${patientUser.name})`,
      data: nextToken
    });
  } catch (error) {
    next(error);
  }
};

// 4. Update Token Status (serving, completed, skipped)
exports.updateTokenStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const token = await QueueToken.findByPk(id, {
      include: [{ model: Appointment, as: 'appointment' }]
    });

    if (!token) {
      return res.status(404).json({ success: false, message: 'Queue token not found.' });
    }

    const updates = { status };
    if (status === 'serving') updates.calledAt = new Date();
    if (status === 'completed') updates.completedAt = new Date();

    await token.update(updates);

    if (token.appointment) {
      if (status === 'serving') await token.appointment.update({ status: 'in_consultation' });
      if (status === 'completed') await token.appointment.update({ status: 'completed' });
    }

    return res.json({
      success: true,
      message: `Token status updated to ${status}.`,
      data: token
    });
  } catch (error) {
    next(error);
  }
};
