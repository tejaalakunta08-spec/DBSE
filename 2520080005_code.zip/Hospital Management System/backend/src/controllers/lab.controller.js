const {
  LabTest,
  LabReport,
  Patient,
  Doctor,
  Appointment,
  User,
  Bill,
  sequelize
} = require('../models');
const { createNotification } = require('../services/notification.service');
const { recordAuditLog } = require('../services/audit.service');

// 1. Get All Lab Tests (Catalog)
exports.getAllLabTests = async (req, res, next) => {
  try {
    const tests = await LabTest.findAll({
      order: [['category', 'ASC'], ['name', 'ASC']]
    });
    return res.json({
      success: true,
      data: tests
    });
  } catch (error) {
    next(error);
  }
};

// 2. Add New Lab Test (Admin)
exports.addLabTest = async (req, res, next) => {
  try {
    const { name, category, standardFee, normalRange, unit, description, sampleRequired } = req.body;

    if (!name || !category || !standardFee) {
      return res.status(400).json({ success: false, message: 'Name, Category, and Fee are required.' });
    }

    const code = `LAB-${Date.now().toString().slice(-4)}${Math.floor(10 + Math.random() * 90)}`;

    const test = await LabTest.create({
      code,
      name,
      category,
      standardFee: parseFloat(standardFee),
      normalRange: normalRange || 'N/A',
      unit: unit || '',
      description: description || null,
      sampleRequired: sampleRequired || 'Blood'
    });

    return res.status(201).json({
      success: true,
      message: 'Diagnostic test added to catalog.',
      data: test
    });
  } catch (error) {
    next(error);
  }
};

// 3. Order / Prescribe Lab Test (Doctor/Admin)
exports.orderLabTest = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const { testId, patientId, appointmentId, technicianNotes } = req.body;

    let doctorId = req.body.doctorId;
    if (req.user.role === 'doctor') {
      doctorId = req.user.doctorProfile?.id;
    }

    const test = await LabTest.findByPk(testId, { transaction: t });
    if (!test) {
      await t.rollback();
      return res.status(404).json({ success: false, message: 'Lab test not found.' });
    }

    const reportNumber = `LBR-${Date.now().toString().slice(-6)}${Math.floor(10 + Math.random() * 90)}`;

    const report = await LabReport.create({
      reportNumber,
      testId,
      appointmentId: appointmentId || null,
      patientId,
      doctorId,
      prescribedDate: new Date().toISOString().split('T')[0],
      normalRangeSnapshot: test.normalRange,
      unit: test.unit,
      status: 'ordered',
      technicianNotes: technicianNotes || null
    }, { transaction: t });

    // Update appointment bill to include lab test fee
    if (appointmentId) {
      const bill = await Bill.findOne({ where: { appointmentId }, transaction: t });
      if (bill) {
        const testFee = parseFloat(test.standardFee) || 0;
        const newLabFee = (parseFloat(bill.labFee) || 0) + testFee;
        const newSubtotal = parseFloat(bill.consultationFee) + parseFloat(bill.medicineFee) + newLabFee + parseFloat(bill.otherCharges);
        const newTotal = newSubtotal - parseFloat(bill.discountAmount) + parseFloat(bill.taxAmount);
        const newBalance = newTotal - parseFloat(bill.paidAmount);

        await bill.update({
          labFee: newLabFee,
          subtotal: newSubtotal,
          totalAmount: newTotal,
          balanceAmount: newBalance
        }, { transaction: t });
      }
    }

    await t.commit();

    await recordAuditLog({
      action: 'LAB_TEST_ORDERED',
      entityType: 'LabReport',
      entityId: report.id,
      details: { testName: test.name, reportNumber },
      req
    });

    return res.status(201).json({
      success: true,
      message: `Diagnostic test '${test.name}' ordered successfully.`,
      data: report
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};

// 4. Update Lab Test Result / Status (Lab Technician or Admin)
exports.updateLabReport = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, resultValue, isAbnormal, sampleCollectedDate, resultDate, technicianNotes } = req.body;

    const report = await LabReport.findByPk(id, {
      include: [
        { model: LabTest, as: 'test' },
        { model: Patient, as: 'patient', include: [{ model: User, as: 'user' }] },
        { model: Doctor, as: 'doctor', include: [{ model: User, as: 'user' }] }
      ]
    });

    if (!report) {
      return res.status(404).json({ success: false, message: 'Lab report not found.' });
    }

    const updates = {};
    if (status) updates.status = status;
    if (resultValue !== undefined) updates.resultValue = resultValue;
    if (isAbnormal !== undefined) updates.isAbnormal = isAbnormal;
    if (technicianNotes !== undefined) updates.technicianNotes = technicianNotes;

    if (status === 'sample_collected' && !report.sampleCollectedDate) {
      updates.sampleCollectedDate = sampleCollectedDate || new Date();
    }
    if (status === 'completed') {
      updates.resultDate = resultDate || new Date();
    }

    await report.update(updates);

    // Notify patient if report is ready
    if (status === 'completed' && report.patient?.user) {
      await createNotification({
        userId: report.patient.user.id,
        recipientPhone: report.patient.user.phone,
        title: 'Laboratory Report Ready',
        message: `Your diagnostic test report for '${report.test.name}' (Report #${report.reportNumber}) is now available in your dashboard.`,
        channel: 'both',
        notificationType: 'lab_result_ready'
      });
    }

    await recordAuditLog({
      action: 'LAB_REPORT_UPDATED',
      entityType: 'LabReport',
      entityId: report.id,
      details: { status, isAbnormal },
      req
    });

    return res.json({
      success: true,
      message: 'Lab report updated successfully.',
      data: report
    });
  } catch (error) {
    next(error);
  }
};

// 5. Get Lab Reports (Role-Aware)
exports.getLabReports = async (req, res, next) => {
  try {
    const { status, patientId, testId } = req.query;
    const where = {};

    if (req.user.role === 'patient') {
      where.patientId = req.user.patientProfile?.id;
    } else if (patientId) {
      where.patientId = patientId;
    }

    if (status && status !== 'all') {
      where.status = status;
    }

    if (testId) {
      where.testId = testId;
    }

    const reports = await LabReport.findAll({
      where,
      include: [
        { model: LabTest, as: 'test' },
        { model: Patient, as: 'patient', include: [{ model: User, as: 'user', attributes: ['name', 'phone'] }] },
        { model: Doctor, as: 'doctor', include: [{ model: User, as: 'user', attributes: ['name'] }] },
        { model: Appointment, as: 'appointment', attributes: ['appointmentNumber', 'appointmentDate'] }
      ],
      order: [['prescribedDate', 'DESC']]
    });

    return res.json({
      success: true,
      count: reports.length,
      data: reports
    });
  } catch (error) {
    next(error);
  }
};
