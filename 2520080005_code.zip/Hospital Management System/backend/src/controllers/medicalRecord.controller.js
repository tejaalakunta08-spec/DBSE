const {
  MedicalRecord,
  Prescription,
  PrescriptionItem,
  Appointment,
  Patient,
  Doctor,
  Medicine,
  Bill,
  User,
  sequelize
} = require('../models');
const { createNotification } = require('../services/notification.service');
const { recordAuditLog } = require('../services/audit.service');

// 1. Create Medical Record (EMR) & Digital Prescription
exports.createMedicalRecord = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const {
      appointmentId,
      patientId,
      symptoms,
      diagnosis,
      bloodPressure,
      heartRate,
      temperature,
      weight,
      doctorNotes,
      followUpDate,
      prescriptionItems, // Array of { medicineId, medicineName, dosage, frequency, durationDays, quantity, instructions }
      generalAdvice
    } = req.body;

    let doctorId = req.body.doctorId;
    if (req.user.role === 'doctor') {
      doctorId = req.user.doctorProfile?.id;
    }

    if (!patientId || !doctorId || !symptoms || !diagnosis) {
      await t.rollback();
      return res.status(400).json({
        success: false,
        message: 'Patient, Doctor, Symptoms, and Diagnosis are required.'
      });
    }

    // 1. Create EMR Medical Record
    const medicalRecord = await MedicalRecord.create({
      appointmentId: appointmentId || null,
      patientId,
      doctorId,
      visitDate: new Date().toISOString().split('T')[0],
      symptoms,
      diagnosis,
      bloodPressure: bloodPressure || null,
      heartRate: heartRate || null,
      temperature: temperature || null,
      weight: weight || null,
      doctorNotes: doctorNotes || null,
      followUpDate: followUpDate || null
    }, { transaction: t });

    let createdPrescription = null;
    let medicineCost = 0;

    // 2. Create Prescription if medicines provided
    if (prescriptionItems && Array.isArray(prescriptionItems) && prescriptionItems.length > 0) {
      const prescCode = `RX-${Date.now().toString().slice(-6)}${Math.floor(10 + Math.random() * 90)}`;

      createdPrescription = await Prescription.create({
        prescriptionCode: prescCode,
        medicalRecordId: medicalRecord.id,
        appointmentId: appointmentId || null,
        patientId,
        doctorId,
        status: 'prescribed',
        generalAdvice: generalAdvice || null
      }, { transaction: t });

      // Add items & compute medicine cost
      for (const item of prescriptionItems) {
        let medPrice = 15; // default fallback
        if (item.medicineId) {
          const med = await Medicine.findByPk(item.medicineId, { transaction: t });
          if (med) medPrice = parseFloat(med.unitPrice) || 15;
        }

        const qty = item.quantity || 10;
        medicineCost += (medPrice * qty);

        await PrescriptionItem.create({
          prescriptionId: createdPrescription.id,
          medicineId: item.medicineId || null,
          medicineName: item.medicineName,
          dosage: item.dosage || '1 tablet',
          frequency: item.frequency || 'Twice daily',
          durationDays: item.durationDays || 5,
          quantity: qty,
          instructions: item.instructions || 'After meals'
        }, { transaction: t });
      }
    }

    // 3. Update appointment to completed
    if (appointmentId) {
      await Appointment.update(
        { status: 'completed' },
        { where: { id: appointmentId }, transaction: t }
      );

      // Update Bill with medicine cost if prescription exists
      if (medicineCost > 0) {
        const bill = await Bill.findOne({
          where: { appointmentId },
          transaction: t
        });

        if (bill) {
          const newMedicineFee = (parseFloat(bill.medicineFee) || 0) + medicineCost;
          const newSubtotal = parseFloat(bill.consultationFee) + newMedicineFee + parseFloat(bill.labFee) + parseFloat(bill.otherCharges);
          const newTotal = newSubtotal - parseFloat(bill.discountAmount) + parseFloat(bill.taxAmount);
          const newBalance = newTotal - parseFloat(bill.paidAmount);

          await bill.update({
            medicineFee: newMedicineFee,
            subtotal: newSubtotal,
            totalAmount: newTotal,
            balanceAmount: newBalance
          }, { transaction: t });
        }
      }
    }

    await t.commit();

    // 4. Send Notification to Patient
    const patient = await Patient.findByPk(patientId, {
      include: [{ model: User, as: 'user' }]
    });

    if (patient && patient.user) {
      await createNotification({
        userId: patient.user.id,
        recipientPhone: patient.user.phone,
        title: 'Medical Record & Prescription Available',
        message: `Your medical record for diagnosis '${diagnosis}' has been finalized. You can view your digital prescription in your dashboard.`,
        channel: 'both',
        notificationType: 'prescription_ready'
      });
    }

    await recordAuditLog({
      action: 'MEDICAL_RECORD_CREATED',
      entityType: 'MedicalRecord',
      entityId: medicalRecord.id,
      details: { diagnosis, hasPrescription: !!createdPrescription },
      req
    });

    return res.status(201).json({
      success: true,
      message: 'Medical Record & Digital Prescription created successfully.',
      data: {
        medicalRecord,
        prescription: createdPrescription
      }
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};

// 2. Get Medical Records by Patient ID
exports.getRecordsByPatient = async (req, res, next) => {
  try {
    const { patientId } = req.params;

    if (req.user.role === 'patient' && req.user.patientProfile?.id !== parseInt(patientId, 10)) {
      return res.status(403).json({ success: false, message: 'Unauthorized to view records.' });
    }

    const records = await MedicalRecord.findAll({
      where: { patientId },
      include: [
        {
          model: Doctor,
          as: 'doctor',
          include: [{ model: User, as: 'user', attributes: ['name', 'phone'] }]
        },
        {
          model: Prescription,
          as: 'prescription',
          include: [{ model: PrescriptionItem, as: 'items' }]
        },
        {
          model: Appointment,
          as: 'appointment'
        }
      ],
      order: [['visitDate', 'DESC']]
    });

    return res.json({
      success: true,
      data: records
    });
  } catch (error) {
    next(error);
  }
};

// 3. Get Single Medical Record By ID
exports.getRecordById = async (req, res, next) => {
  try {
    const { id } = req.params;

    const record = await MedicalRecord.findByPk(id, {
      include: [
        {
          model: Patient,
          as: 'patient',
          include: [{ model: User, as: 'user' }]
        },
        {
          model: Doctor,
          as: 'doctor',
          include: [{ model: User, as: 'user' }]
        },
        {
          model: Prescription,
          as: 'prescription',
          include: [{ model: PrescriptionItem, as: 'items' }]
        },
        {
          model: Appointment,
          as: 'appointment'
        }
      ]
    });

    if (!record) {
      return res.status(404).json({ success: false, message: 'Medical record not found.' });
    }

    return res.json({
      success: true,
      data: record
    });
  } catch (error) {
    next(error);
  }
};
