const {
  Medicine,
  InventoryTransaction,
  Prescription,
  PrescriptionItem,
  sequelize
} = require('../models');
const { Op } = require('sequelize');
const { recordAuditLog } = require('../services/audit.service');

// 1. Get All Medicines (with category filter, low stock alert)
exports.getAllMedicines = async (req, res, next) => {
  try {
    const { category, search, lowStock } = req.query;
    const where = {};

    if (category && category !== 'All') {
      where.category = category;
    }

    if (search) {
      where[Op.or] = [
        { name: { [Op.like]: `%${search}%` } },
        { genericName: { [Op.like]: `%${search}%` } },
        { code: { [Op.like]: `%${search}%` } }
      ];
    }

    if (lowStock === 'true') {
      where.stockQuantity = { [Op.lte]: sequelize.col('reorderLevel') };
    }

    const medicines = await Medicine.findAll({
      where,
      order: [['name', 'ASC']]
    });

    const lowStockCount = await Medicine.count({
      where: {
        stockQuantity: { [Op.lte]: sequelize.col('reorderLevel') }
      }
    });

    return res.json({
      success: true,
      lowStockCount,
      count: medicines.length,
      data: medicines
    });
  } catch (error) {
    next(error);
  }
};

// 2. Add New Medicine (Admin/Pharmacist)
exports.addMedicine = async (req, res, next) => {
  try {
    const {
      name,
      genericName,
      category,
      manufacturer,
      dosageForm,
      strength,
      unitPrice,
      stockQuantity,
      reorderLevel,
      batchNumber,
      expiryDate
    } = req.body;

    if (!name || !category || !unitPrice) {
      return res.status(400).json({
        success: false,
        message: 'Name, Category, and Unit Price are required.'
      });
    }

    const code = `MED-${Date.now().toString().slice(-4)}${Math.floor(10 + Math.random() * 90)}`;

    const medicine = await Medicine.create({
      code,
      name,
      genericName: genericName || null,
      category,
      manufacturer: manufacturer || 'Standard Pharmaceuticals',
      dosageForm: dosageForm || 'Tablet',
      strength: strength || '500mg',
      unitPrice: parseFloat(unitPrice),
      stockQuantity: parseInt(stockQuantity, 10) || 0,
      reorderLevel: parseInt(reorderLevel, 10) || 20,
      batchNumber: batchNumber || `BATCH-${Date.now().toString().slice(-5)}`,
      expiryDate: expiryDate || '2028-12-31'
    });

    // Record initial stock transaction if quantity > 0
    if (medicine.stockQuantity > 0) {
      await InventoryTransaction.create({
        medicineId: medicine.id,
        transactionType: 'stock_in',
        quantity: medicine.stockQuantity,
        unitCost: medicine.unitPrice,
        referenceType: 'InitialStock',
        notes: 'Initial opening stock',
        performedBy: req.user.name
      });
    }

    return res.status(201).json({
      success: true,
      message: 'Medicine added to inventory.',
      data: medicine
    });
  } catch (error) {
    next(error);
  }
};

// 3. Restock Medicine (Stock In)
exports.restockMedicine = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;
    const { quantity, unitCost, notes, batchNumber, expiryDate } = req.body;

    const qty = parseInt(quantity, 10);
    if (!qty || qty <= 0) {
      await t.rollback();
      return res.status(400).json({ success: false, message: 'Valid positive quantity required.' });
    }

    const medicine = await Medicine.findByPk(id, { transaction: t });
    if (!medicine) {
      await t.rollback();
      return res.status(404).json({ success: false, message: 'Medicine not found.' });
    }

    const newStock = medicine.stockQuantity + qty;
    const updates = { stockQuantity: newStock };
    if (batchNumber) updates.batchNumber = batchNumber;
    if (expiryDate) updates.expiryDate = expiryDate;

    await medicine.update(updates, { transaction: t });

    const transaction = await InventoryTransaction.create({
      medicineId: medicine.id,
      transactionType: 'stock_in',
      quantity: qty,
      unitCost: unitCost || medicine.unitPrice,
      referenceType: 'RestockOrder',
      notes: notes || 'Hospital pharmacy restocking',
      performedBy: req.user.name
    }, { transaction: t });

    await t.commit();

    await recordAuditLog({
      action: 'MEDICINE_RESTOCKED',
      entityType: 'Medicine',
      entityId: medicine.id,
      details: { added: qty, totalStock: newStock, medicineName: medicine.name },
      req
    });

    return res.json({
      success: true,
      message: `Successfully restocked ${qty} units of ${medicine.name}. Current stock: ${newStock}`,
      data: { medicine, transaction }
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};

// 4. Dispense Prescription (Stock Out / Dispense)
exports.dispensePrescription = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const { prescriptionId } = req.params;

    const prescription = await Prescription.findByPk(prescriptionId, {
      include: [{ model: PrescriptionItem, as: 'items' }],
      transaction: t
    });

    if (!prescription) {
      await t.rollback();
      return res.status(404).json({ success: false, message: 'Prescription not found.' });
    }

    if (prescription.status === 'dispensed') {
      await t.rollback();
      return res.status(400).json({ success: false, message: 'Prescription has already been dispensed.' });
    }

    // Deduct stock for each line item
    for (const item of prescription.items) {
      if (item.medicineId) {
        const medicine = await Medicine.findByPk(item.medicineId, { transaction: t });
        if (medicine) {
          const qty = item.quantity || 10;
          const newQty = Math.max(0, medicine.stockQuantity - qty);
          await medicine.update({ stockQuantity: newQty }, { transaction: t });

          await InventoryTransaction.create({
            medicineId: medicine.id,
            transactionType: 'dispensed',
            quantity: qty,
            referenceType: 'Prescription',
            referenceId: prescription.prescriptionCode,
            notes: `Dispensed to patient for Prescription #${prescription.prescriptionCode}`,
            performedBy: req.user.name
          }, { transaction: t });
        }
      }
    }

    await prescription.update({ status: 'dispensed' }, { transaction: t });

    await t.commit();

    await recordAuditLog({
      action: 'PRESCRIPTION_DISPENSED',
      entityType: 'Prescription',
      entityId: prescription.id,
      details: { code: prescription.prescriptionCode },
      req
    });

    return res.json({
      success: true,
      message: `Prescription #${prescription.prescriptionCode} has been successfully dispensed. Inventory updated.`,
      data: prescription
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};

// 5. Get Inventory Transaction Log
exports.getInventoryHistory = async (req, res, next) => {
  try {
    const history = await InventoryTransaction.findAll({
      include: [{ model: Medicine, as: 'medicine', attributes: ['id', 'name', 'code', 'category'] }],
      order: [['createdAt', 'DESC']],
      limit: 100
    });

    return res.json({
      success: true,
      data: history
    });
  } catch (error) {
    next(error);
  }
};
