const {
  Bill,
  InsuranceClaim,
  Appointment,
  Patient,
  Doctor,
  User,
  sequelize
} = require('../models');
const { createNotification } = require('../services/notification.service');
const { recordAuditLog } = require('../services/audit.service');

// 1. Get All Bills (Role-aware)
exports.getAllBills = async (req, res, next) => {
  try {
    const { status, patientId } = req.query;
    const where = {};

    if (req.user.role === 'patient') {
      where.patientId = req.user.patientProfile?.id;
    } else if (patientId) {
      where.patientId = patientId;
    }

    if (status && status !== 'all') {
      where.paymentStatus = status;
    }

    const bills = await Bill.findAll({
      where,
      include: [
        {
          model: Patient,
          as: 'patient',
          include: [{ model: User, as: 'user', attributes: ['name', 'phone', 'email'] }]
        },
        {
          model: Appointment,
          as: 'appointment',
          include: [
            {
              model: Doctor,
              as: 'doctor',
              include: [{ model: User, as: 'user', attributes: ['name'] }]
            }
          ]
        },
        {
          model: InsuranceClaim,
          as: 'insuranceClaim'
        }
      ],
      order: [['billDate', 'DESC']]
    });

    // Summary calculations
    let totalRevenue = 0;
    let pendingDues = 0;
    bills.forEach(b => {
      totalRevenue += parseFloat(b.paidAmount) || 0;
      pendingDues += parseFloat(b.balanceAmount) || 0;
    });

    return res.json({
      success: true,
      data: {
        totalRevenue: totalRevenue.toFixed(2),
        pendingDues: pendingDues.toFixed(2),
        count: bills.length,
        bills
      }
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Single Bill by ID
exports.getBillById = async (req, res, next) => {
  try {
    const { id } = req.params;

    const bill = await Bill.findByPk(id, {
      include: [
        {
          model: Patient,
          as: 'patient',
          include: [{ model: User, as: 'user' }]
        },
        {
          model: Appointment,
          as: 'appointment',
          include: [
            {
              model: Doctor,
              as: 'doctor',
              include: [{ model: User, as: 'user' }]
            }
          ]
        },
        {
          model: InsuranceClaim,
          as: 'insuranceClaim'
        }
      ]
    });

    if (!bill) {
      return res.status(404).json({ success: false, message: 'Invoice not found.' });
    }

    return res.json({
      success: true,
      data: bill
    });
  } catch (error) {
    next(error);
  }
};

// 3. Process Payment (Patient self-pay simulation or Admin cashier)
exports.processPayment = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;
    const { amount, paymentMethod, transactionReference } = req.body;

    const bill = await Bill.findByPk(id, {
      include: [{ model: Patient, as: 'patient', include: [{ model: User, as: 'user' }] }],
      transaction: t
    });

    if (!bill) {
      await t.rollback();
      return res.status(404).json({ success: false, message: 'Invoice not found.' });
    }

    const payAmount = parseFloat(amount) || parseFloat(bill.balanceAmount);
    if (payAmount <= 0) {
      await t.rollback();
      return res.status(400).json({ success: false, message: 'Payment amount must be greater than zero.' });
    }

    const currentPaid = parseFloat(bill.paidAmount) || 0;
    const totalAmount = parseFloat(bill.totalAmount) || 0;
    const newPaid = currentPaid + payAmount;
    const newBalance = Math.max(0, totalAmount - newPaid);
    const newStatus = newBalance === 0 ? 'paid' : 'partial';

    await bill.update({
      paidAmount: newPaid,
      balanceAmount: newBalance,
      paymentStatus: newStatus,
      paymentMethod: paymentMethod || 'online',
      transactionReference: transactionReference || `TXN-${Date.now().toString().slice(-8)}`
    }, { transaction: t });

    await t.commit();

    const patientUser = bill.patient?.user;
    if (patientUser) {
      await createNotification({
        userId: patientUser.id,
        recipientPhone: patientUser.phone,
        title: 'Payment Received',
        message: `Payment of Rs. ${payAmount.toFixed(2)} received for Invoice #${bill.billNumber}. Remaining Balance: Rs. ${newBalance.toFixed(2)}.`,
        channel: 'both',
        notificationType: 'bill_generated'
      });
    }

    await recordAuditLog({
      action: 'PAYMENT_PROCESSED',
      entityType: 'Bill',
      entityId: bill.id,
      details: { amount: payAmount, paymentMethod, newStatus },
      req
    });

    return res.json({
      success: true,
      message: `Payment of Rs. ${payAmount.toFixed(2)} recorded successfully. Invoice status: ${newStatus.toUpperCase()}`,
      data: bill
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};

// 4. Submit Insurance Claim
exports.submitInsuranceClaim = async (req, res, next) => {
  try {
    const { billId, providerName, policyNumber, claimAmount } = req.body;

    const bill = await Bill.findByPk(billId);
    if (!bill) {
      return res.status(404).json({ success: false, message: 'Invoice not found.' });
    }

    const claimNumber = `CLM-${Date.now().toString().slice(-6)}${Math.floor(10 + Math.random() * 90)}`;

    const claim = await InsuranceClaim.create({
      claimNumber,
      billId,
      patientId: bill.patientId,
      providerName: providerName || 'National Health Insurance',
      policyNumber: policyNumber || 'POL-992384',
      claimAmount: claimAmount || bill.totalAmount,
      claimStatus: 'submitted',
      submissionDate: new Date().toISOString().split('T')[0]
    });

    return res.status(201).json({
      success: true,
      message: 'Insurance claim submitted for verification.',
      data: claim
    });
  } catch (error) {
    next(error);
  }
};

// 5. Adjudicate Insurance Claim (Admin Action)
exports.adjudicateClaim = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;
    const { claimStatus, approvedAmount, remarks } = req.body; // 'approved', 'rejected', 'in_review'

    const claim = await InsuranceClaim.findByPk(id, {
      include: [{ model: Bill, as: 'bill' }],
      transaction: t
    });

    if (!claim) {
      await t.rollback();
      return res.status(404).json({ success: false, message: 'Insurance claim not found.' });
    }

    const appAmt = claimStatus === 'approved' ? (parseFloat(approvedAmount) || parseFloat(claim.claimAmount)) : 0.00;

    await claim.update({
      claimStatus,
      approvedAmount: appAmt,
      adjudicationDate: new Date().toISOString().split('T')[0],
      remarks: remarks || null
    }, { transaction: t });

    // If approved, adjust bill balance
    if (claimStatus === 'approved' && claim.bill) {
      const currentPaid = parseFloat(claim.bill.paidAmount) || 0;
      const totalAmount = parseFloat(claim.bill.totalAmount) || 0;
      const newPaid = currentPaid + appAmt;
      const newBalance = Math.max(0, totalAmount - newPaid);

      await claim.bill.update({
        paidAmount: newPaid,
        balanceAmount: newBalance,
        paymentStatus: newBalance === 0 ? 'paid' : 'partial',
        paymentMethod: 'insurance'
      }, { transaction: t });
    }

    await t.commit();

    await recordAuditLog({
      action: 'INSURANCE_CLAIM_ADJUDICATED',
      entityType: 'InsuranceClaim',
      entityId: claim.id,
      details: { claimStatus, approvedAmount: appAmt },
      req
    });

    return res.json({
      success: true,
      message: `Insurance claim #${claim.claimNumber} updated to ${claimStatus.toUpperCase()}.`,
      data: claim
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};
