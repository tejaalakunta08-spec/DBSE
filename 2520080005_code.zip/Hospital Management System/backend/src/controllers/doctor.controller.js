const { Doctor, User, DoctorSchedule, Appointment, sequelize } = require('../models');
const { Op } = require('sequelize');

// Helper to generate time slots between start and end time
function generateTimeSlots(startTimeStr, endTimeStr, durationMinutes = 20) {
  const slots = [];
  const [startHour, startMin] = startTimeStr.split(':').map(Number);
  const [endHour, endMin] = endTimeStr.split(':').map(Number);

  let current = new Date();
  current.setHours(startHour, startMin, 0, 0);

  const end = new Date();
  end.setHours(endHour, endMin, 0, 0);

  while (current < end) {
    const hours = current.getHours();
    const minutes = current.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const formattedHours = hours % 12 || 12;
    const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
    slots.push(`${formattedHours}:${formattedMinutes} ${ampm}`);

    current = new Date(current.getTime() + durationMinutes * 60000);
  }

  return slots;
}

// 1. Get All Doctors (with filters for department, search, availability)
exports.getAllDoctors = async (req, res, next) => {
  try {
    const { department, search } = req.query;

    const doctorWhere = {};
    if (department && department !== 'All') {
      doctorWhere.department = department;
    }

    const userWhere = { status: 'active' };
    if (search) {
      userWhere.name = { [Op.like]: `%${search}%` };
    }

    const doctors = await Doctor.findAll({
      where: doctorWhere,
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'avatar', 'status'],
          where: userWhere
        },
        {
          model: DoctorSchedule,
          as: 'schedules',
          where: { isAvailable: true },
          required: false
        }
      ],
      order: [['department', 'ASC']]
    });

    return res.json({
      success: true,
      data: doctors
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Doctor by ID
exports.getDoctorById = async (req, res, next) => {
  try {
    const { id } = req.params;

    const doctor = await Doctor.findByPk(id, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'avatar', 'status']
        },
        {
          model: DoctorSchedule,
          as: 'schedules'
        }
      ]
    });

    if (!doctor) {
      return res.status(404).json({
        success: false,
        message: 'Doctor not found.'
      });
    }

    return res.json({
      success: true,
      data: doctor
    });
  } catch (error) {
    next(error);
  }
};

// 3. Get Available Slots for a given Doctor & Date
exports.getDoctorSlots = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { date } = req.query; // YYYY-MM-DD

    if (!date) {
      return res.status(400).json({
        success: false,
        message: 'Target date (YYYY-MM-DD) is required to calculate slots.'
      });
    }

    const doctor = await Doctor.findByPk(id, {
      include: [{ model: DoctorSchedule, as: 'schedules' }]
    });

    if (!doctor) {
      return res.status(404).json({
        success: false,
        message: 'Doctor not found.'
      });
    }

    // Determine Day of Week from date
    const targetDate = new Date(`${date}T00:00:00`);
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayName = dayNames[targetDate.getDay()];

    const schedule = doctor.schedules.find(s => s.dayOfWeek === dayName && s.isAvailable);

    if (!schedule) {
      return res.json({
        success: true,
        data: {
          doctorName: doctor.user?.name,
          date,
          dayOfWeek: dayName,
          isAvailable: false,
          availableSlots: [],
          message: `Dr. ${doctor.user?.name || ''} does not have OPD slots on ${dayName}s.`
        }
      });
    }

    const allSlots = generateTimeSlots(schedule.startTime, schedule.endTime, schedule.slotDurationMinutes || 20);

    // Find existing booked appointments on this date
    const bookedAppointments = await Appointment.findAll({
      where: {
        doctorId: doctor.id,
        appointmentDate: date,
        status: { [Op.notIn]: ['cancelled', 'no_show'] }
      },
      attributes: ['timeSlot']
    });

    const bookedSlotsSet = new Set(bookedAppointments.map(a => a.timeSlot));

    const slotObjects = allSlots.map(slot => ({
      timeSlot: slot,
      isBooked: bookedSlotsSet.has(slot)
    }));

    return res.json({
      success: true,
      data: {
        doctorId: doctor.id,
        date,
        dayOfWeek: dayName,
        isAvailable: true,
        totalSlots: slotObjects.length,
        slots: slotObjects
      }
    });
  } catch (error) {
    next(error);
  }
};

// 4. Update Doctor Schedule (Doctor or Admin)
exports.updateSchedule = async (req, res, next) => {
  try {
    const doctorId = req.user.role === 'doctor' ? req.user.doctorProfile?.id : req.params.id;
    const { schedules } = req.body; // Array of schedules

    if (!doctorId) {
      return res.status(400).json({
        success: false,
        message: 'Doctor profile not found.'
      });
    }

    if (!schedules || !Array.isArray(schedules)) {
      return res.status(400).json({
        success: false,
        message: 'Schedules must be an array of daily schedules.'
      });
    }

    // Upsert or replace schedules
    for (const item of schedules) {
      const [existing] = await DoctorSchedule.findOrCreate({
        where: { doctorId, dayOfWeek: item.dayOfWeek },
        defaults: {
          doctorId,
          dayOfWeek: item.dayOfWeek,
          startTime: item.startTime || '09:00:00',
          endTime: item.endTime || '17:00:00',
          slotDurationMinutes: item.slotDurationMinutes || 20,
          maxPatients: item.maxPatients || 25,
          isAvailable: item.isAvailable !== undefined ? item.isAvailable : true
        }
      });

      if (existing) {
        await existing.update({
          startTime: item.startTime || existing.startTime,
          endTime: item.endTime || existing.endTime,
          slotDurationMinutes: item.slotDurationMinutes || existing.slotDurationMinutes,
          maxPatients: item.maxPatients || existing.maxPatients,
          isAvailable: item.isAvailable !== undefined ? item.isAvailable : existing.isAvailable
        });
      }
    }

    const updatedSchedules = await DoctorSchedule.findAll({ where: { doctorId } });

    return res.json({
      success: true,
      message: 'Schedule updated successfully.',
      data: updatedSchedules
    });
  } catch (error) {
    next(error);
  }
};

// 5. Get List of Distinct Departments
exports.getDepartments = async (req, res, next) => {
  try {
    const departments = await Doctor.findAll({
      attributes: [[sequelize.fn('DISTINCT', sequelize.col('department')), 'department']]
    });
    return res.json({
      success: true,
      data: departments.map(d => d.department)
    });
  } catch (error) {
    next(error);
  }
};
