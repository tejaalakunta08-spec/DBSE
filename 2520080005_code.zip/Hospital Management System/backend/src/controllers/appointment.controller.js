const {
  Appointment,
  QueueToken,
  Bill,
  Doctor,
  Patient,
  User,
  DoctorSchedule,
  sequelize
} = require('../models');
const { Op } = require('sequelize');
const { createNotification } = require('../services/notification.service');
const { recordAuditLog } = require('../services/audit.service');

// 1. Book Appointment (with Transaction, Token Creation, Bill Generation, Notification)
exports.bookAppointment = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const { doctorId, appointmentDate, timeSlot, reason, symptoms, notes } = req.body;

    let patientId = req.body.patientId;
    if (req.user.role === 'patient') {
      patientId = req.user.patientProfile?.id;
    }

    if (!patientId || !doctorId || !appointmentDate || !timeSlot || !reason) {
      await t.rollback();
      return res.status(400).json({
        success: false,
        message: 'Patient, Doctor, Appointment Date, Time Slot, and Reason are required.'
      });
    }

    const doctor = await Doctor.findByPk(doctorId, {
      include: [{ model: User, as: 'user' }],
      transaction: t
    });

    if (!doctor) {
      await t.rollback();
      return res.status(404).json({
        success: false,
        message: 'Selected doctor does not exist.'
      });
    }

    const patient = await Patient.findByPk(patientId, {
      include: [{ model: User, as: 'user' }],
      transaction: t
    });

    if (!patient) {
      await t.rollback();
      return res.status(404).json({
        success: false,
        message: 'Selected patient does not exist.'
      });
    }

    // Check if slot is already booked for this doctor on this date
    const existingSlot = await Appointment.findOne({
      where: {
        doctorId,
        appointmentDate,
        timeSlot,
        status: { [Op.notIn]: ['cancelled', 'no_show'] }
      },
      transaction: t
    });

    if (existingSlot) {
      await t.rollback();
      return res.status(409).json({
        success: false,
        message: `The time slot '${timeSlot}' on ${appointmentDate} is already booked. Please choose another slot.`
      });
    }

    // Generate unique appointment number
    const dateCode = appointmentDate.replace(/-/g, '');
    const randNum = Math.floor(100 + Math.random() * 900);
    const appointmentNumber = `APT-${dateCode}-${randNum}`;

    // 1. Create Appointment
    const appointment = await Appointment.create({
      appointmentNumber,
      patientId,
      doctorId,
      appointmentDate,
      timeSlot,
      status: 'confirmed',
      reason,
      symptoms: symptoms || null,
      notes: notes || null
    }, { transaction: t });

    // 2. Calculate next daily Queue Token for this doctor on this date
    const existingTokensCount = await QueueToken.count({
      where: { doctorId, tokenDate: appointmentDate },
      transaction: t
    });
    const nextTokenNumber = existingTokensCount + 1;
    const tokenCode = `OPD-${doctor.doctorCode}-${String(nextTokenNumber).padStart(3, '0')}`;

    const queueToken = await QueueToken.create({
      appointmentId: appointment.id,
      doctorId,
      patientId,
      tokenNumber: nextTokenNumber,
      tokenCode,
      tokenDate: appointmentDate,
      status: 'waiting',
      estimatedTime: timeSlot
    }, { transaction: t });

    // 3. Create Preliminary Bill for Consultation Fee
    const consultationFee = parseFloat(doctor.consultationFee) || 500.00;
    const billNumber = `INV-${dateCode}-${Math.floor(1000 + Math.random() * 9000)}`;

    const bill = await Bill.create({
      billNumber,
      appointmentId: appointment.id,
      patientId,
      consultationFee,
      medicineFee: 0.00,
      labFee: 0.00,
      otherCharges: 0.00,
      subtotal: consultationFee,
      taxAmount: 0.00,
      discountAmount: 0.00,
      totalAmount: consultationFee,
      paidAmount: 0.00,
      balanceAmount: consultationFee,
      paymentStatus: 'unpaid',
      paymentMethod: 'cash',
      billDate: appointmentDate
    }, { transaction: t });

    await t.commit();

    // 4. Send Confirmation Notification (In-App and SMS)
    const patientUser = patient.user;
    const doctorUser = doctor.user;
    const notificationMessage = `Your appointment with Dr. ${doctorUser.name} (${doctor.specialization}) on ${appointmentDate} at ${timeSlot} is confirmed. OPD Token: #${nextTokenNumber} (${tokenCode}).`;

    await createNotification({
      userId: patientUser.id,
      recipientPhone: patientUser.phone,
      recipientEmail: patientUser.email,
      title: 'Appointment Confirmed',
      message: notificationMessage,
      channel: patientUser.phone ? 'both' : 'in_app',
      notificationType: 'appointment_confirmed'
    });

    await recordAuditLog({
      action: 'APPOINTMENT_BOOKED',
      entityType: 'Appointment',
      entityId: appointment.id,
      details: {
        appointmentNumber,
        tokenCode,
        doctorName: doctorUser.name,
        patientName: patientUser.name,
        date: appointmentDate,
        timeSlot
      },
      req
    });

    return res.status(201).json({
      success: true,
      message: 'Appointment booked successfully with OPD token & initial invoice generated.',
      data: {
        appointment,
        queueToken,
        bill
      }
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};

// 2. Get Appointments (Role-Aware Listing with Filters)
exports.getAppointments = async (req, res, next) => {
  try {
    const { date, status, doctorId, patientId, search } = req.query;

    const where = {};

    // Role-based restrictions
    if (req.user.role === 'patient') {
      where.patientId = req.user.patientProfile?.id;
    } else if (req.user.role === 'doctor') {
      where.doctorId = req.user.doctorProfile?.id;
    } else if (doctorId) {
      where.doctorId = doctorId;
    } else if (patientId) {
      where.patientId = patientId;
    }

    if (date) {
      where.appointmentDate = date;
    }

    if (status && status !== 'all') {
      where.status = status;
    }

    const appointments = await Appointment.findAll({
      where,
      include: [
        {
          model: Patient,
          as: 'patient',
          include: [{ model: User, as: 'user', attributes: ['id', 'name', 'phone', 'email'] }]
        },
        {
          model: Doctor,
          as: 'doctor',
          include: [{ model: User, as: 'user', attributes: ['id', 'name', 'email'] }]
        },
        {
          model: QueueToken,
          as: 'queueToken'
        },
        {
          model: Bill,
          as: 'bill'
        }
      ],
      order: [
        ['appointmentDate', 'DESC'],
        ['timeSlot', 'ASC']
      ]
    });

    return res.json({
      success: true,
      count: appointments.length,
      data: appointments
    });
  } catch (error) {
    next(error);
  }
};

// 3. Get Appointment By ID
exports.getAppointmentById = async (req, res, next) => {
  try {
    const { id } = req.params;

    const appointment = await Appointment.findByPk(id, {
      include: [
        {
          model: Patient,
          as: 'patient',
          include: [{ model: User, as: 'user' }]
        },
        {
          model: Doctor,
          as: 'doctor',
          include: [{ model: User, as: 'user' }]
        },
        {
          model: QueueToken,
          as: 'queueToken'
        },
        {
          model: Bill,
          as: 'bill'
        }
      ]
    });

    if (!appointment) {
      return res.status(404).json({
        success: false,
        message: 'Appointment not found.'
      });
    }

    // Role verification
    if (req.user.role === 'patient' && appointment.patientId !== req.user.patientProfile?.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized.' });
    }
    if (req.user.role === 'doctor' && appointment.doctorId !== req.user.doctorProfile?.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized.' });
    }

    return res.json({
      success: true,
      data: appointment
    });
  } catch (error) {
    next(error);
  }
};

// 4. Cancel Appointment
exports.cancelAppointment = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;
    const { cancellationReason } = req.body;

    const appointment = await Appointment.findByPk(id, {
      include: [
        { model: Patient, as: 'patient', include: [{ model: User, as: 'user' }] },
        { model: Doctor, as: 'doctor', include: [{ model: User, as: 'user' }] },
        { model: QueueToken, as: 'queueToken' }
      ],
      transaction: t
    });

    if (!appointment) {
      await t.rollback();
      return res.status(404).json({ success: false, message: 'Appointment not found.' });
    }

    // Authorization check
    if (req.user.role === 'patient' && appointment.patientId !== req.user.patientProfile?.id) {
      await t.rollback();
      return res.status(403).json({ success: false, message: 'Unauthorized to cancel this appointment.' });
    }
    if (req.user.role === 'doctor' && appointment.doctorId !== req.user.doctorProfile?.id) {
      await t.rollback();
      return res.status(403).json({ success: false, message: 'Unauthorized to cancel this appointment.' });
    }

    if (appointment.status === 'completed') {
      await t.rollback();
      return res.status(400).json({ success: false, message: 'Cannot cancel an appointment that has already been completed.' });
    }

    await appointment.update({
      status: 'cancelled',
      cancelledBy: req.user.role,
      cancellationReason: cancellationReason || 'Cancelled by user request.'
    }, { transaction: t });

    // Cancel queue token
    if (appointment.queueToken) {
      await appointment.queueToken.update({ status: 'cancelled' }, { transaction: t });
    }

    await t.commit();

    // Send cancellation alert
    const patientUser = appointment.patient.user;
    await createNotification({
      userId: patientUser.id,
      recipientPhone: patientUser.phone,
      title: 'Appointment Cancelled',
      message: `Your appointment on ${appointment.appointmentDate} with Dr. ${appointment.doctor.user.name} has been cancelled. Reason: ${cancellationReason || 'User request.'}`,
      channel: patientUser.phone ? 'both' : 'in_app',
      notificationType: 'appointment_cancelled'
    });

    await recordAuditLog({
      action: 'APPOINTMENT_CANCELLED',
      entityType: 'Appointment',
      entityId: appointment.id,
      details: { cancelledBy: req.user.role, reason: cancellationReason },
      req
    });

    return res.json({
      success: true,
      message: 'Appointment cancelled successfully.',
      data: appointment
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};

// 5. Update Appointment Status (Doctor / Admin)
exports.updateAppointmentStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const appointment = await Appointment.findByPk(id);
    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found.' });
    }

    await appointment.update({ status });

    return res.json({
      success: true,
      message: `Appointment status updated to ${status}.`,
      data: appointment
    });
  } catch (error) {
    next(error);
  }
};
