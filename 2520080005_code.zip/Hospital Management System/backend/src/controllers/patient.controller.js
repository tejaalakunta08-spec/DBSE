const {
  Patient,
  User,
  MedicalRecord,
  Prescription,
  PrescriptionItem,
  Appointment,
  Doctor,
  Bill,
  LabReport,
  LabTest
} = require('../models');
const { Op } = require('sequelize');

// 1. Get All Patients (Admin & Doctor)
exports.getAllPatients = async (req, res, next) => {
  try {
    const { search } = req.query;

    const userWhere = {};
    if (search) {
      userWhere[Op.or] = [
        { name: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } },
        { phone: { [Op.like]: `%${search}%` } }
      ];
    }

    const patients = await Patient.findAll({
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'status'],
          where: userWhere
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    return res.json({
      success: true,
      data: patients
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Patient By ID (with EMR summary)
exports.getPatientById = async (req, res, next) => {
  try {
    const { id } = req.params;

    // RBAC: Patient can only view their own profile, unless Admin or Doctor
    if (req.user.role === 'patient' && req.user.patientProfile?.id !== parseInt(id, 10)) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized: You can only view your own patient profile.'
      });
    }

    const patient = await Patient.findByPk(id, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'avatar', 'status']
        },
        {
          model: MedicalRecord,
          as: 'medicalRecords',
          include: [
            {
              model: Doctor,
              as: 'doctor',
              include: [{ model: User, as: 'user', attributes: ['name', 'phone'] }]
            },
            {
              model: Prescription,
              as: 'prescription',
              include: [{ model: PrescriptionItem, as: 'items' }]
            }
          ]
        },
        {
          model: Appointment,
          as: 'appointments',
          include: [
            {
              model: Doctor,
              as: 'doctor',
              include: [{ model: User, as: 'user', attributes: ['name'] }]
            }
          ],
          limit: 10,
          order: [['appointmentDate', 'DESC']]
        },
        {
          model: LabReport,
          as: 'labReports',
          include: [{ model: LabTest, as: 'test' }]
        },
        {
          model: Bill,
          as: 'bills',
          limit: 5,
          order: [['createdAt', 'DESC']]
        }
      ]
    });

    if (!patient) {
      return res.status(404).json({
        success: false,
        message: 'Patient profile not found.'
      });
    }

    return res.json({
      success: true,
      data: patient
    });
  } catch (error) {
    next(error);
  }
};

// 3. Update Patient Profile
exports.updatePatientProfile = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (req.user.role === 'patient' && req.user.patientProfile?.id !== parseInt(id, 10)) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to update another patient profile.'
      });
    }

    const patient = await Patient.findByPk(id, {
      include: [{ model: User, as: 'user' }]
    });

    if (!patient) {
      return res.status(404).json({
        success: false,
        message: 'Patient not found.'
      });
    }

    const {
      name,
      phone,
      dob,
      gender,
      bloodGroup,
      address,
      emergencyContactName,
      emergencyContactPhone,
      allergies,
      chronicConditions,
      insuranceProvider,
      insurancePolicyNumber
    } = req.body;

    if (name || phone) {
      await patient.user.update({
        name: name || patient.user.name,
        phone: phone || patient.user.phone
      });
    }

    await patient.update({
      dob: dob !== undefined ? dob : patient.dob,
      gender: gender !== undefined ? gender : patient.gender,
      bloodGroup: bloodGroup !== undefined ? bloodGroup : patient.bloodGroup,
      address: address !== undefined ? address : patient.address,
      emergencyContactName: emergencyContactName !== undefined ? emergencyContactName : patient.emergencyContactName,
      emergencyContactPhone: emergencyContactPhone !== undefined ? emergencyContactPhone : patient.emergencyContactPhone,
      allergies: allergies !== undefined ? allergies : patient.allergies,
      chronicConditions: chronicConditions !== undefined ? chronicConditions : patient.chronicConditions,
      insuranceProvider: insuranceProvider !== undefined ? insuranceProvider : patient.insuranceProvider,
      insurancePolicyNumber: insurancePolicyNumber !== undefined ? insurancePolicyNumber : patient.insurancePolicyNumber
    });

    return res.json({
      success: true,
      message: 'Patient profile updated successfully.',
      data: patient
    });
  } catch (error) {
    next(error);
  }
};

// 4. Get Patient EMR History (Electronic Medical Records)
exports.getPatientEMR = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (req.user.role === 'patient' && req.user.patientProfile?.id !== parseInt(id, 10)) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to view these medical records.'
      });
    }

    const records = await MedicalRecord.findAll({
      where: { patientId: id },
      include: [
        {
          model: Doctor,
          as: 'doctor',
          include: [{ model: User, as: 'user', attributes: ['name', 'email'] }]
        },
        {
          model: Prescription,
          as: 'prescription',
          include: [{ model: PrescriptionItem, as: 'items' }]
        }
      ],
      order: [['visitDate', 'DESC']]
    });

    return res.json({
      success: true,
      data: records
    });
  } catch (error) {
    next(error);
  }
};
