const {
  User,
  Doctor,
  Patient,
  Appointment,
  Bill,
  Medicine,
  LabReport,
  QueueToken,
  AuditLog,
  sequelize
} = require('../models');
const { Op } = require('sequelize');
const { sendSms, isConfigured } = require('../config/twilio.config');
const { createNotification } = require('../services/notification.service');

// 1. Hospital Executive Overview Stats
exports.getDashboardStats = async (req, res, next) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    const [
      totalPatients,
      totalDoctors,
      todayAppointmentsCount,
      totalRevenue,
      lowStockCount,
      pendingLabTestsCount,
      activeQueueCount,
      recentAppointments
    ] = await Promise.all([
      Patient.count(),
      Doctor.count(),
      Appointment.count({ where: { appointmentDate: today } }),
      Bill.sum('paidAmount'),
      Medicine.count({ where: { stockQuantity: { [Op.lte]: sequelize.col('reorderLevel') } } }),
      LabReport.count({ where: { status: { [Op.in]: ['ordered', 'sample_collected', 'in_progress'] } } }),
      QueueToken.count({ where: { tokenDate: today, status: { [Op.in]: ['waiting', 'serving'] } } }),
      Appointment.findAll({
        limit: 6,
        order: [['appointmentDate', 'DESC'], ['id', 'DESC']],
        include: [
          { model: Patient, as: 'patient', include: [{ model: User, as: 'user', attributes: ['name'] }] },
          { model: Doctor, as: 'doctor', attributes: ['id', 'department', 'specialization'], include: [{ model: User, as: 'user', attributes: ['name'] }] }
        ]
      })
    ]);

    return res.json({
      success: true,
      data: {
        totalPatients,
        totalDoctors,
        todayAppointmentsCount,
        totalRevenue: (totalRevenue || 0).toFixed(2),
        lowStockCount,
        pendingLabTestsCount,
        activeQueueCount,
        recentAppointments,
        twilioConfigured: isConfigured
      }
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Audit Logs
exports.getAuditLogs = async (req, res, next) => {
  try {
    const { action, limit = 50 } = req.query;
    const where = {};
    if (action) where.action = action;

    const logs = await AuditLog.findAll({
      where,
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit, 10)
    });

    return res.json({
      success: true,
      data: logs
    });
  } catch (error) {
    next(error);
  }
};

// 3. Update User Status (Activate/Deactivate)
exports.updateUserStatus = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { status } = req.body; // 'active', 'inactive', 'suspended'

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    await user.update({ status });

    return res.json({
      success: true,
      message: `User status changed to ${status}.`,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// 4. Test Twilio SMS Endpoint
exports.testTwilioSms = async (req, res, next) => {
  try {
    const { phoneNumber, message } = req.body;

    if (!phoneNumber) {
      return res.status(400).json({ success: false, message: 'Phone number is required.' });
    }

    const result = await sendSms(
      phoneNumber,
      message || 'Hospital Management System: This is a test SMS alert from Twilio integration.'
    );

    return res.json({
      success: result.success,
      message: result.mode === 'live' ? 'Live SMS sent via Twilio!' : 'Mock SMS simulated (check console/logs).',
      result
    });
  } catch (error) {
    next(error);
  }
};
