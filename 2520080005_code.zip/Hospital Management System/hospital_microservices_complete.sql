-- ============================================================================
-- HOSPITAL MANAGEMENT & APPOINTMENT SYSTEM - COMPLETE MYSQL DATABASE SCRIPT
-- ARCHITECTURE: Microservices Architecture (Database-per-Service Pattern)
-- DATABASE ENGINE: MySQL 8.0+
-- CHARACTER SET: utf8mb4 COLLATE utf8mb4_unicode_ci
-- ============================================================================
-- Databases Provisioned:
--   1. hospital_auth_db          - Users, Patients, Doctors, Audit Logs
--   2. hospital_appointment_db   - Doctor Schedules, Appointments
--   3. hospital_emr_db           - Medical Records, Prescriptions, Prescription Items
--   4. hospital_queue_db         - Daily OPD Queue Tokens & Room Status
--   5. hospital_billing_db       - Invoices, Payments, Insurance Claims
--   6. hospital_pharmacy_db      - Medicines Inventory, Stock Transactions
--   7. hospital_lab_db           - Diagnostic Tests Catalog, Clinical Lab Reports
--   8. hospital_notification_db  - Twilio SMS Logs, In-App Notifications
-- ============================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- ============================================================================
-- DATABASE 1: hospital_auth_db
-- ============================================================================
CREATE DATABASE IF NOT EXISTS `hospital_auth_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `hospital_auth_db`;

-- Table 1.1: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(120) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'doctor', 'patient') NOT NULL DEFAULT 'patient',
  `phone` VARCHAR(20) DEFAULT NULL,
  `status` ENUM('active', 'inactive', 'suspended') NOT NULL DEFAULT 'active',
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_users_email` (`email`),
  INDEX `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 1.2: patients
DROP TABLE IF EXISTS `patients`;
CREATE TABLE `patients` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `userId` INT NOT NULL UNIQUE,
  `patientCode` VARCHAR(30) NOT NULL UNIQUE,
  `dob` DATE DEFAULT NULL,
  `gender` ENUM('male', 'female', 'other') DEFAULT 'male',
  `bloodGroup` VARCHAR(10) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `emergencyContactName` VARCHAR(100) DEFAULT NULL,
  `emergencyContactPhone` VARCHAR(20) DEFAULT NULL,
  `allergies` TEXT DEFAULT NULL,
  `chronicConditions` TEXT DEFAULT NULL,
  `insuranceProvider` VARCHAR(100) DEFAULT NULL,
  `insurancePolicyNumber` VARCHAR(60) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_patients_code` (`patientCode`),
  CONSTRAINT `fk_patients_user` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 1.3: doctors
DROP TABLE IF EXISTS `doctors`;
CREATE TABLE `doctors` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `userId` INT NOT NULL UNIQUE,
  `doctorCode` VARCHAR(30) NOT NULL UNIQUE,
  `department` VARCHAR(80) NOT NULL,
  `specialization` VARCHAR(100) NOT NULL,
  `qualification` VARCHAR(100) NOT NULL,
  `experienceYears` INT DEFAULT 0,
  `consultationFee` DECIMAL(10,2) NOT NULL DEFAULT 500.00,
  `roomNumber` VARCHAR(20) DEFAULT 'OPD-101',
  `bio` TEXT DEFAULT NULL,
  `isAvailable` TINYINT(1) DEFAULT 1,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_doctors_department` (`department`),
  INDEX `idx_doctors_code` (`doctorCode`),
  CONSTRAINT `fk_doctors_user` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 1.4: audit_logs
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `userId` INT DEFAULT NULL,
  `userName` VARCHAR(100) DEFAULT NULL,
  `userRole` VARCHAR(30) DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `entity` VARCHAR(60) NOT NULL,
  `entityId` VARCHAR(50) DEFAULT NULL,
  `details` TEXT DEFAULT NULL,
  `ipAddress` VARCHAR(45) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_audit_user` (`userId`),
  INDEX `idx_audit_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- DATABASE 2: hospital_appointment_db
-- ============================================================================
CREATE DATABASE IF NOT EXISTS `hospital_appointment_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `hospital_appointment_db`;

-- Table 2.1: doctor_schedules
DROP TABLE IF EXISTS `doctor_schedules`;
CREATE TABLE `doctor_schedules` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `doctorId` INT NOT NULL,
  `dayOfWeek` ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') NOT NULL,
  `startTime` TIME NOT NULL DEFAULT '09:00:00',
  `endTime` TIME NOT NULL DEFAULT '17:00:00',
  `slotDurationMinutes` INT NOT NULL DEFAULT 15,
  `maxPatients` INT NOT NULL DEFAULT 25,
  `isActive` TINYINT(1) DEFAULT 1,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_schedules_doctor_day` (`doctorId`, `dayOfWeek`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 2.2: appointments
DROP TABLE IF EXISTS `appointments`;
CREATE TABLE `appointments` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `appointmentNumber` VARCHAR(40) NOT NULL UNIQUE,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `appointmentDate` DATE NOT NULL,
  `timeSlot` VARCHAR(20) NOT NULL,
  `status` ENUM('pending', 'confirmed', 'in_consultation', 'completed', 'cancelled', 'no_show') NOT NULL DEFAULT 'confirmed',
  `reason` VARCHAR(255) NOT NULL,
  `notes` TEXT DEFAULT NULL,
  `cancelledReason` VARCHAR(255) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_appts_patient` (`patientId`),
  INDEX `idx_appts_doctor_date` (`doctorId`, `appointmentDate`),
  INDEX `idx_appts_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- DATABASE 3: hospital_emr_db
-- ============================================================================
CREATE DATABASE IF NOT EXISTS `hospital_emr_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `hospital_emr_db`;

-- Table 3.1: medical_records
DROP TABLE IF EXISTS `medical_records`;
CREATE TABLE `medical_records` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `appointmentId` INT DEFAULT NULL,
  `visitDate` DATE NOT NULL,
  `diagnosis` VARCHAR(255) NOT NULL,
  `symptoms` TEXT NOT NULL,
  `clinicalNotes` TEXT DEFAULT NULL,
  `bloodPressure` VARCHAR(20) DEFAULT NULL,
  `heartRate` INT DEFAULT NULL,
  `temperature` DECIMAL(4,1) DEFAULT NULL,
  `weight` DECIMAL(5,2) DEFAULT NULL,
  `height` DECIMAL(5,2) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_emr_patient` (`patientId`),
  INDEX `idx_emr_doctor` (`doctorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 3.2: prescriptions
DROP TABLE IF EXISTS `prescriptions`;
CREATE TABLE `prescriptions` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `medicalRecordId` INT NOT NULL,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `instructions` TEXT DEFAULT NULL,
  `status` ENUM('prescribed', 'partially_dispensed', 'dispensed', 'cancelled') NOT NULL DEFAULT 'prescribed',
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_presc_patient` (`patientId`),
  INDEX `idx_presc_record` (`medicalRecordId`),
  CONSTRAINT `fk_prescriptions_record` FOREIGN KEY (`medicalRecordId`) REFERENCES `medical_records` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 3.3: prescription_items
DROP TABLE IF EXISTS `prescription_items`;
CREATE TABLE `prescription_items` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `prescriptionId` INT NOT NULL,
  `medicineId` INT NOT NULL,
  `medicineName` VARCHAR(150) NOT NULL,
  `dosage` VARCHAR(50) NOT NULL,
  `frequency` VARCHAR(50) NOT NULL,
  `durationDays` INT NOT NULL DEFAULT 5,
  `instructions` VARCHAR(255) DEFAULT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `dispensedQuantity` INT NOT NULL DEFAULT 0,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_presc_items_rx` (`prescriptionId`),
  CONSTRAINT `fk_prescription_items_rx` FOREIGN KEY (`prescriptionId`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- DATABASE 4: hospital_queue_db
-- ============================================================================
CREATE DATABASE IF NOT EXISTS `hospital_queue_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `hospital_queue_db`;

-- Table 4.1: queue_tokens
DROP TABLE IF EXISTS `queue_tokens`;
CREATE TABLE `queue_tokens` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `tokenNumber` INT NOT NULL,
  `tokenCode` VARCHAR(30) NOT NULL,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `appointmentId` INT DEFAULT NULL,
  `queueDate` DATE NOT NULL,
  `status` ENUM('waiting', 'called', 'serving', 'completed', 'skipped', 'cancelled') NOT NULL DEFAULT 'waiting',
  `calledAt` DATETIME DEFAULT NULL,
  `servedAt` DATETIME DEFAULT NULL,
  `completedAt` DATETIME DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_queue_doctor_date_status` (`doctorId`, `queueDate`, `status`),
  INDEX `idx_queue_patient` (`patientId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- DATABASE 5: hospital_billing_db
-- ============================================================================
CREATE DATABASE IF NOT EXISTS `hospital_billing_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `hospital_billing_db`;

-- Table 5.1: bills
DROP TABLE IF EXISTS `bills`;
CREATE TABLE `bills` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `invoiceNumber` VARCHAR(40) NOT NULL UNIQUE,
  `patientId` INT NOT NULL,
  `appointmentId` INT DEFAULT NULL,
  `doctorId` INT DEFAULT NULL,
  `consultationFee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `pharmacyFee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `labFee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `otherCharges` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `discount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `tax` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `totalAmount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `paidAmount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `balanceAmount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `paymentStatus` ENUM('pending', 'partial', 'paid', 'refunded') NOT NULL DEFAULT 'pending',
  `paymentMethod` ENUM('cash', 'card', 'upi', 'insurance', 'net_banking') DEFAULT 'cash',
  `paymentDate` DATETIME DEFAULT NULL,
  `transactionReference` VARCHAR(100) DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_bills_patient` (`patientId`),
  INDEX `idx_bills_status` (`paymentStatus`),
  INDEX `idx_bills_invoice` (`invoiceNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 5.2: insurance_claims
DROP TABLE IF EXISTS `insurance_claims`;
CREATE TABLE `insurance_claims` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `billId` INT NOT NULL,
  `patientId` INT NOT NULL,
  `providerName` VARCHAR(120) NOT NULL,
  `policyNumber` VARCHAR(80) NOT NULL,
  `claimAmount` DECIMAL(10,2) NOT NULL,
  `approvedAmount` DECIMAL(10,2) DEFAULT NULL,
  `claimStatus` ENUM('submitted', 'under_review', 'approved', 'rejected') NOT NULL DEFAULT 'submitted',
  `rejectionReason` TEXT DEFAULT NULL,
  `settlementDate` DATE DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_claims_bill` (`billId`),
  INDEX `idx_claims_patient` (`patientId`),
  CONSTRAINT `fk_claims_bill` FOREIGN KEY (`billId`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- DATABASE 6: hospital_pharmacy_db
-- ============================================================================
CREATE DATABASE IF NOT EXISTS `hospital_pharmacy_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `hospital_pharmacy_db`;

-- Table 6.1: medicines
DROP TABLE IF EXISTS `medicines`;
CREATE TABLE `medicines` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `genericName` VARCHAR(150) DEFAULT NULL,
  `category` VARCHAR(80) NOT NULL,
  `dosageForm` VARCHAR(50) NOT NULL,
  `strength` VARCHAR(50) NOT NULL,
  `manufacturer` VARCHAR(120) NOT NULL,
  `unitPrice` DECIMAL(10,2) NOT NULL,
  `stockQuantity` INT NOT NULL DEFAULT 0,
  `reorderLevel` INT NOT NULL DEFAULT 20,
  `batchNumber` VARCHAR(60) NOT NULL,
  `expiryDate` DATE NOT NULL,
  `status` ENUM('available', 'low_stock', 'out_of_stock', 'expired') NOT NULL DEFAULT 'available',
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_meds_category` (`category`),
  INDEX `idx_meds_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 6.2: inventory_transactions
DROP TABLE IF EXISTS `inventory_transactions`;
CREATE TABLE `inventory_transactions` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `medicineId` INT NOT NULL,
  `type` ENUM('purchase', 'dispensed', 'adjustment', 'expired') NOT NULL,
  `quantity` INT NOT NULL,
  `balanceAfter` INT NOT NULL,
  `referenceId` VARCHAR(50) DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `performedBy` VARCHAR(100) DEFAULT 'System',
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_trans_medicine` (`medicineId`),
  CONSTRAINT `fk_trans_medicine` FOREIGN KEY (`medicineId`) REFERENCES `medicines` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- DATABASE 7: hospital_lab_db
-- ============================================================================
CREATE DATABASE IF NOT EXISTS `hospital_lab_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `hospital_lab_db`;

-- Table 7.1: lab_tests
DROP TABLE IF EXISTS `lab_tests`;
CREATE TABLE `lab_tests` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `code` VARCHAR(40) NOT NULL UNIQUE,
  `category` VARCHAR(80) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `turnaroundHours` INT NOT NULL DEFAULT 24,
  `sampleType` VARCHAR(60) NOT NULL,
  `normalRange` TEXT DEFAULT NULL,
  `units` VARCHAR(30) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `isActive` TINYINT(1) DEFAULT 1,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_tests_code` (`code`),
  INDEX `idx_tests_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 7.2: lab_reports
DROP TABLE IF EXISTS `lab_reports`;
CREATE TABLE `lab_reports` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `reportCode` VARCHAR(40) NOT NULL UNIQUE,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `appointmentId` INT DEFAULT NULL,
  `testId` INT NOT NULL,
  `testName` VARCHAR(150) NOT NULL,
  `sampleCollectedAt` DATETIME DEFAULT NULL,
  `resultData` TEXT DEFAULT NULL,
  `conclusion` TEXT DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `status` ENUM('ordered', 'sample_collected', 'processing', 'completed', 'cancelled') NOT NULL DEFAULT 'ordered',
  `completedAt` DATETIME DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_reports_patient` (`patientId`),
  INDEX `idx_reports_doctor` (`doctorId`),
  CONSTRAINT `fk_reports_test` FOREIGN KEY (`testId`) REFERENCES `lab_tests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- DATABASE 8: hospital_notification_db
-- ============================================================================
CREATE DATABASE IF NOT EXISTS `hospital_notification_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `hospital_notification_db`;

-- Table 8.1: notifications
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `userId` INT DEFAULT NULL,
  `recipientPhone` VARCHAR(25) DEFAULT NULL,
  `recipientEmail` VARCHAR(120) DEFAULT NULL,
  `title` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `channel` ENUM('in_app', 'sms', 'both') NOT NULL DEFAULT 'in_app',
  `notificationType` ENUM('appointment_booking', 'appointment_confirmed', 'appointment_cancelled', 'queue_update', 'prescription_ready', 'bill_generated', 'lab_result_ready', 'general') NOT NULL DEFAULT 'general',
  `isRead` TINYINT(1) DEFAULT 0,
  `smsStatus` ENUM('none', 'pending', 'sent', 'failed', 'simulated') DEFAULT 'none',
  `smsSid` VARCHAR(80) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_notifications_user_read` (`userId`, `isRead`),
  INDEX `idx_notifications_type` (`notificationType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- INITIAL SEED DATA INSERTION
-- Password Hashes:
--   'Admin@123'   -> $2a$10$wE8wM2gH.iSgq2K9qU1W.ehW5b0qY0GkHwBqvH9Sj2U5nC0p7zJ4e
--   'Doctor@123'  -> $2a$10$tZ2zS7vE5sVn7aY1rL9D.eO1v8oJ4FmIwPqpN6Tm9P1uD7r8vE0Wq
--   'Patient@123' -> $2a$10$dY8kM1vQ0nBn9wP2xK3C.uV0b7lE2GmDwKlpO5Sl8Q0tC6q7uD9Vp
-- ============================================================================

-- SEED: hospital_auth_db
USE `hospital_auth_db`;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `phone`, `status`) VALUES
(1, 'Super Hospital Admin', 'admin@hospital.com', '$2a$10$wE8wM2gH.iSgq2K9qU1W.ehW5b0qY0GkHwBqvH9Sj2U5nC0p7zJ4e', 'admin', '+919876543210', 'active'),
(2, 'Ramesh Sharma', 'dr.sharma@hospital.com', '$2a$10$tZ2zS7vE5sVn7aY1rL9D.eO1v8oJ4FmIwPqpN6Tm9P1uD7r8vE0Wq', 'doctor', '+919811122334', 'active'),
(3, 'Priya Nair', 'dr.priya@hospital.com', '$2a$10$tZ2zS7vE5sVn7aY1rL9D.eO1v8oJ4FmIwPqpN6Tm9P1uD7r8vE0Wq', 'doctor', '+919822233445', 'active'),
(4, 'Rajesh Patel', 'dr.rajesh@hospital.com', '$2a$10$tZ2zS7vE5sVn7aY1rL9D.eO1v8oJ4FmIwPqpN6Tm9P1uD7r8vE0Wq', 'doctor', '+919833344556', 'active'),
(5, 'Anita Desai', 'dr.anita@hospital.com', '$2a$10$tZ2zS7vE5sVn7aY1rL9D.eO1v8oJ4FmIwPqpN6Tm9P1uD7r8vE0Wq', 'doctor', '+919844455667', 'active'),
(6, 'Vikram Mehta', 'dr.vikram@hospital.com', '$2a$10$tZ2zS7vE5sVn7aY1rL9D.eO1v8oJ4FmIwPqpN6Tm9P1uD7r8vE0Wq', 'doctor', '+919855566778', 'active'),
(7, 'Sai Teja', 'patient.sai@hospital.com', '$2a$10$dY8kM1vQ0nBn9wP2xK3C.uV0b7lE2GmDwKlpO5Sl8Q0tC6q7uD9Vp', 'patient', '+919876500001', 'active'),
(8, 'Rahul Verma', 'rahul.verma@example.com', '$2a$10$dY8kM1vQ0nBn9wP2xK3C.uV0b7lE2GmDwKlpO5Sl8Q0tC6q7uD9Vp', 'patient', '+919876500002', 'active'),
(9, 'Anjali Roy', 'anjali.roy@example.com', '$2a$10$dY8kM1vQ0nBn9wP2xK3C.uV0b7lE2GmDwKlpO5Sl8Q0tC6q7uD9Vp', 'patient', '+919876500003', 'active'),
(10, 'Sunil Joshi', 'sunil.joshi@example.com', '$2a$10$dY8kM1vQ0nBn9wP2xK3C.uV0b7lE2GmDwKlpO5Sl8Q0tC6q7uD9Vp', 'patient', '+919876500004', 'active');

INSERT INTO `doctors` (`id`, `userId`, `doctorCode`, `department`, `specialization`, `qualification`, `experienceYears`, `consultationFee`, `roomNumber`, `bio`, `isAvailable`) VALUES
(1, 2, 'DOC-100002', 'Cardiology', 'Interventional Cardiology', 'MBBS, MD, DM (Cardiology), FACC', 14, 800.00, 'OPD-101', 'Senior consultant cardiologist specializing in heart failure, coronary interventions, and preventative cardiology.', 1),
(2, 3, 'DOC-100003', 'Neurology', 'Clinical Neurology & Epilepsy', 'MBBS, MD, DM (Neurology)', 10, 750.00, 'OPD-105', 'Leading neurologist focusing on migraine management, stroke rehabilitation, and neuropathy.', 1),
(3, 4, 'DOC-100004', 'Orthopedics', 'Joint Replacement & Arthroscopy', 'MBBS, MS (Ortho), M.Ch', 12, 700.00, 'OPD-202', 'Specialist in robotic knee and hip replacements, sports injury management, and spine disorders.', 1),
(4, 5, 'DOC-100005', 'Pediatrics', 'General Pediatrics & Neonatology', 'MBBS, MD (Pediatrics), DCH', 8, 600.00, 'OPD-108', 'Dedicated pediatrician providing comprehensive child health care, vaccinations, and growth assessments.', 1),
(5, 6, 'DOC-100006', 'Dermatology', 'Clinical Dermatology & Cosmetology', 'MBBS, MD (DVL)', 11, 650.00, 'OPD-210', 'Consultant dermatologist treating complex dermatoses, vitiligo, and aesthetic dermatology.', 1);

INSERT INTO `patients` (`id`, `userId`, `patientCode`, `dob`, `gender`, `bloodGroup`, `address`, `emergencyContactName`, `emergencyContactPhone`, `allergies`, `chronicConditions`, `insuranceProvider`, `insurancePolicyNumber`) VALUES
(1, 7, 'PAT-100007', '1998-05-15', 'male', 'O+', 'Plot 42, Hitech City, Hyderabad, Telangana', 'Lakshmi Teja', '+919876500001', 'Penicillin, Dust', 'Mild Hypertension', 'Star Health Allied Insurance', 'SH-POL-2024-8849'),
(2, 8, 'PAT-100008', '1985-09-22', 'male', 'B+', 'Flat 302, Green Glen Layout, Bangalore, Karnataka', 'Sneha Verma', '+919876500002', 'Sulfa drugs', 'Type 2 Diabetes', 'HDFC ERGO General Insurance', 'HE-MED-99234'),
(3, 9, 'PAT-100009', '1992-12-05', 'female', 'A+', 'B-14, Mayur Vihar Phase 1, New Delhi', 'Amit Roy', '+919876500003', 'None', 'Asthma', 'Care Health Insurance', 'CHI-2023-7712'),
(4, 10, 'PAT-100010', '1976-03-30', 'male', 'AB+', 'Shop 5, M.G. Road, Pune, Maharashtra', 'Kavita Joshi', '+919876500004', 'Aspirin', 'Osteoarthritis', 'ICICI Lombard', 'IL-HEALTH-4412');

INSERT INTO `audit_logs` (`userId`, `userName`, `userRole`, `action`, `entity`, `entityId`, `details`, `ipAddress`) VALUES
(1, 'Super Hospital Admin', 'admin', 'SYSTEM_INIT', 'System', '0', 'Initial microservices database provisioning and seeding completed.', '127.0.0.1'),
(1, 'Super Hospital Admin', 'admin', 'CREATE_DOCTOR', 'Doctor', '1', 'Registered Dr. Ramesh Sharma into Cardiology OPD-101.', '127.0.0.1');

-- ----------------------------------------------------------------------------
-- SEED DATA: hospital_appointment_db
-- ----------------------------------------------------------------------------
USE `hospital_appointment_db`;

INSERT INTO `doctor_schedules` (`doctorId`, `dayOfWeek`, `startTime`, `endTime`, `slotDurationMinutes`, `maxPatients`, `isActive`) VALUES
(1, 'Monday', '09:00:00', '13:00:00', 15, 16, 1),
(1, 'Tuesday', '09:00:00', '13:00:00', 15, 16, 1),
(1, 'Wednesday', '09:00:00', '13:00:00', 15, 16, 1),
(1, 'Thursday', '09:00:00', '13:00:00', 15, 16, 1),
(1, 'Friday', '09:00:00', '13:00:00', 15, 16, 1),
(1, 'Saturday', '09:00:00', '13:00:00', 15, 16, 1),
(2, 'Monday', '10:00:00', '14:00:00', 20, 12, 1),
(2, 'Wednesday', '10:00:00', '14:00:00', 20, 12, 1),
(2, 'Friday', '10:00:00', '14:00:00', 20, 12, 1),
(3, 'Tuesday', '14:00:00', '18:00:00', 15, 16, 1),
(3, 'Thursday', '14:00:00', '18:00:00', 15, 16, 1),
(3, 'Saturday', '14:00:00', '18:00:00', 15, 16, 1);

INSERT INTO `appointments` (`id`, `appointmentNumber`, `patientId`, `doctorId`, `appointmentDate`, `timeSlot`, `status`, `reason`, `notes`) VALUES
(1, 'APT-20261003-0001', 1, 1, '2026-10-03', '09:15 AM', 'confirmed', 'Routine cardiac evaluation and ECG review', 'Patient requested morning slot.'),
(2, 'APT-20261003-0002', 2, 1, '2026-10-03', '09:30 AM', 'confirmed', 'Evaluation of recurrent chest palpitations', 'Fasting blood test recommended.'),
(3, 'APT-20261003-0003', 3, 2, '2026-10-03', '10:20 AM', 'confirmed', 'Persistent severe migraine episodes', 'Previous scan attached in EMR.'),
(4, 'APT-20261003-0004', 4, 3, '2026-10-03', '02:15 PM', 'confirmed', 'Right knee acute joint inflammation', 'Post-arthroscopy follow up.');

-- ----------------------------------------------------------------------------
-- SEED DATA: hospital_emr_db
-- ----------------------------------------------------------------------------
USE `hospital_emr_db`;

INSERT INTO `medical_records` (`id`, `patientId`, `doctorId`, `appointmentId`, `visitDate`, `diagnosis`, `symptoms`, `clinicalNotes`, `bloodPressure`, `heartRate`, `temperature`, `weight`, `height`) VALUES
(1, 1, 1, 1, '2026-09-15', 'Mild Essential Hypertension', 'Occasional lightheadedness and exertional fatigue.', 'Resting BP mildly elevated at 138/88 mmHg. Advised low-sodium DASH diet and 30 mins brisk daily walk.', '138/88', 76, 98.4, 74.5, 175.0),
(2, 2, 2, 2, '2026-09-18', 'Unilateral Migraine with Aura', 'Unilateral pulsating headache, photophobia, nausea.', 'Visual scotoma reported before headaches. Advised prophylactic lifestyle modifications and symptom diary.', '122/80', 72, 98.6, 68.0, 168.0);

INSERT INTO `prescriptions` (`id`, `medicalRecordId`, `patientId`, `doctorId`, `instructions`, `status`) VALUES
(1, 1, 1, 1, 'Take blood pressure medication every morning after breakfast. Monitor BP weekly.', 'dispensed'),
(2, 2, 2, 2, 'Take acute migraine relief at immediate onset of aura.', 'prescribed');

INSERT INTO `prescription_items` (`prescriptionId`, `medicineId`, `medicineName`, `dosage`, `frequency`, `durationDays`, `instructions`, `quantity`, `dispensedQuantity`) VALUES
(1, 2, 'Telmisartan 40mg', '40mg', 'Once daily (morning)', 30, 'Take after breakfast with water.', 30, 30),
(1, 7, 'Vitamin D3 60000 IU', '60000 IU', 'Once weekly', 8, 'Take after heavy meal.', 8, 8),
(2, 1, 'Paracetamol 650mg', '650mg', 'As needed (SOS)', 5, 'Maximum 3 tablets in 24 hours.', 10, 0);

-- ----------------------------------------------------------------------------
-- SEED DATA: hospital_queue_db
-- ----------------------------------------------------------------------------
USE `hospital_queue_db`;

INSERT INTO `queue_tokens` (`id`, `tokenNumber`, `tokenCode`, `patientId`, `doctorId`, `appointmentId`, `queueDate`, `status`, `calledAt`, `servedAt`) VALUES
(1, 1, 'T-001', 1, 1, 1, '2026-10-03', 'serving', '2026-10-03 09:12:00', '2026-10-03 09:15:00'),
(2, 2, 'T-002', 2, 1, 2, '2026-10-03', 'waiting', NULL, NULL),
(3, 1, 'T-001', 3, 2, 3, '2026-10-03', 'waiting', NULL, NULL);

-- ----------------------------------------------------------------------------
-- SEED DATA: hospital_billing_db
-- ----------------------------------------------------------------------------
USE `hospital_billing_db`;

INSERT INTO `bills` (`id`, `invoiceNumber`, `patientId`, `appointmentId`, `doctorId`, `consultationFee`, `pharmacyFee`, `labFee`, `otherCharges`, `discount`, `tax`, `totalAmount`, `paidAmount`, `balanceAmount`, `paymentStatus`, `paymentMethod`, `paymentDate`, `transactionReference`, `notes`) VALUES
(1, 'INV-20261003-0001', 1, 1, 1, 800.00, 240.00, 500.00, 0.00, 0.00, 77.00, 1617.00, 1617.00, 0.00, 'paid', 'upi', '2026-10-03 09:14:00', 'UPI-TXN-9988221144', 'Consultation, Telmisartan 40mg, and Lipid Profile blood test.'),
(2, 'INV-20261003-0002', 2, 2, 1, 800.00, 0.00, 0.00, 0.00, 0.00, 40.00, 840.00, 0.00, 840.00, 'pending', 'cash', NULL, NULL, 'OPD consultation awaiting cashier payment.');

INSERT INTO `insurance_claims` (`id`, `billId`, `patientId`, `providerName`, `policyNumber`, `claimAmount`, `approvedAmount`, `claimStatus`, `settlementDate`) VALUES
(1, 1, 1, 'Star Health Allied Insurance', 'SH-POL-2024-8849', 1617.00, 1617.00, 'approved', '2026-10-03');

-- ----------------------------------------------------------------------------
-- SEED DATA: hospital_pharmacy_db
-- ----------------------------------------------------------------------------
USE `hospital_pharmacy_db`;

INSERT INTO `medicines` (`id`, `name`, `genericName`, `category`, `dosageForm`, `strength`, `manufacturer`, `unitPrice`, `stockQuantity`, `reorderLevel`, `batchNumber`, `expiryDate`, `status`) VALUES
(1, 'Dolo 650', 'Paracetamol', 'Analgesics / Antipyretic', 'Tablet', '650mg', 'Micro Labs Ltd', 3.50, 500, 50, 'BT-2026-D01', '2027-12-31', 'available'),
(2, 'Telma 40', 'Telmisartan', 'Antihypertensive', 'Tablet', '40mg', 'Glenmark Pharmaceuticals', 8.00, 250, 30, 'BT-2026-T40', '2028-06-30', 'available'),
(3, 'Amoxyclav 625', 'Amoxicillin + Clavulanate', 'Antibiotic', 'Tablet', '625mg', 'Alkem Laboratories', 18.50, 180, 25, 'BT-2026-AC6', '2027-09-30', 'available'),
(4, 'Pantocid 40', 'Pantoprazole', 'Antacid / PPI', 'Tablet', '40mg', 'Sun Pharma Ltd', 9.00, 320, 40, 'BT-2026-P40', '2028-01-31', 'available'),
(5, 'Azithral 500', 'Azithromycin', 'Antibiotic', 'Tablet', '500mg', 'Alembic Pharma', 22.00, 140, 20, 'BT-2026-AZ5', '2027-11-30', 'available'),
(6, 'Glycomet GP 1', 'Metformin + Glimepiride', 'Antidiabetic', 'Tablet', '500mg/1mg', 'USV Ltd', 11.00, 210, 30, 'BT-2026-G1', '2028-03-31', 'available'),
(7, 'Calcirol 60K', 'Cholecalciferol (Vit D3)', 'Vitamins / Minerals', 'Sachet', '60000 IU', 'Cadila Pharma', 32.00, 15, 20, 'BT-2026-D3', '2027-08-31', 'low_stock');

INSERT INTO `inventory_transactions` (`id`, `medicineId`, `type`, `quantity`, `balanceAfter`, `referenceId`, `notes`, `performedBy`) VALUES
(1, 1, 'purchase', 500, 500, 'PO-2026-001', 'Initial warehouse batch stocking.', 'Chief Pharmacist'),
(2, 2, 'purchase', 280, 280, 'PO-2026-002', 'Initial warehouse batch stocking.', 'Chief Pharmacist'),
(3, 2, 'dispensed', 30, 250, 'INV-20261003-0001', 'Dispensed for Patient Sai Teja (Rx-1).', 'Cashier Pharmacist');

-- ----------------------------------------------------------------------------
-- SEED DATA: hospital_lab_db
-- ----------------------------------------------------------------------------
USE `hospital_lab_db`;

INSERT INTO `lab_tests` (`id`, `name`, `code`, `category`, `price`, `turnaroundHours`, `sampleType`, `normalRange`, `units`, `description`, `isActive`) VALUES
(1, 'Complete Blood Count (CBC)', 'LAB-CBC', 'Hematology', 350.00, 6, 'Whole Blood (EDTA)', 'Hemoglobin: 13-17 g/dL, WBC: 4000-11000 /uL, Platelets: 1.5-4.5 Lakhs/uL', 'Various', 'Automated hemogram covering RBC, WBC, platelets, and differential count.', 1),
(2, 'Lipid Profile Screen', 'LAB-LIPID', 'Biochemistry', 500.00, 12, 'Serum (Fasting 12h)', 'Total Cholesterol: <200 mg/dL, HDL: >40 mg/dL, LDL: <100 mg/dL, Triglycerides: <150 mg/dL', 'mg/dL', 'Comprehensive assessment of cardiovascular dyslipidemia risk.', 1),
(3, 'Glycosylated Hemoglobin (HbA1c)', 'LAB-HBA1C', 'Biochemistry', 450.00, 8, 'Whole Blood (EDTA)', 'Normal: <5.7%, Prediabetes: 5.7-6.4%, Diabetes: >=6.5%', '%', '3-month rolling average index of glycemic blood glucose management.', 1),
(4, 'Thyroid Stimulating Hormone (TSH)', 'LAB-TSH', 'Endocrinology', 300.00, 12, 'Serum', 'Euthyroid range: 0.4 - 4.2 uIU/mL', 'uIU/mL', 'High-sensitivity third generation chemiluminescent TSH immunoassay.', 1),
(5, 'Liver Function Test (LFT)', 'LAB-LFT', 'Biochemistry', 650.00, 12, 'Serum', 'Bilirubin: 0.2-1.2 mg/dL, SGOT/AST: 5-40 U/L, SGPT/ALT: 7-56 U/L', 'Various', 'Hepatic enzymes, bilirubin metabolism, and serum protein profile.', 1);

INSERT INTO `lab_reports` (`id`, `reportCode`, `patientId`, `doctorId`, `appointmentId`, `testId`, `testName`, `sampleCollectedAt`, `resultData`, `conclusion`, `notes`, `status`, `completedAt`) VALUES
(1, 'REP-20261003-0001', 1, 1, 1, 2, 'Lipid Profile Screen', '2026-10-03 08:30:00', 'Total Cholesterol: 188 mg/dL\nHDL Cholesterol: 48 mg/dL\nLDL Cholesterol: 104 mg/dL\nTriglycerides: 142 mg/dL', 'Desirable lipid distribution with borderline optimal LDL.', 'Sample analyzed via automated chemistry analyzer.', 'completed', '2026-10-03 10:00:00');

-- ----------------------------------------------------------------------------
-- SEED DATA: hospital_notification_db
-- ----------------------------------------------------------------------------
USE `hospital_notification_db`;

INSERT INTO `notifications` (`id`, `userId`, `recipientPhone`, `recipientEmail`, `title`, `message`, `channel`, `notificationType`, `isRead`, `smsStatus`, `smsSid`) VALUES
(1, 7, '+919876500001', 'patient.sai@hospital.com', 'Appointment Confirmed', 'Hello Sai Teja, your appointment with Dr. Ramesh Sharma is confirmed for today at 09:15 AM. Token: #01.', 'both', 'appointment_confirmed', 1, 'simulated', 'SM-SIMULATED-001'),
(2, 7, '+919876500001', 'patient.sai@hospital.com', 'Live Queue Alert', 'Token #01 is currently serving in Room OPD-101. Please proceed to the consultation room.', 'both', 'queue_update', 1, 'simulated', 'SM-SIMULATED-002'),
(3, 7, '+919876500001', 'patient.sai@hospital.com', 'Invoice Paid & Settled', 'Your invoice #INV-20261003-0001 for Rs. 1617.00 has been successfully settled via UPI.', 'both', 'bill_generated', 0, 'simulated', 'SM-SIMULATED-003'),
(4, 8, '+919876500002', 'rahul.verma@example.com', 'Appointment Confirmed', 'Hello Rahul Verma, your appointment with Dr. Ramesh Sharma is confirmed for today at 09:30 AM. Token: #02.', 'both', 'appointment_confirmed', 0, 'simulated', 'SM-SIMULATED-004');

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================
SELECT 'hospital_auth_db' AS Database_Name, COUNT(*) AS Total_Users FROM `hospital_auth_db`.`users`
UNION ALL
SELECT 'hospital_appointment_db', COUNT(*) FROM `hospital_appointment_db`.`appointments`
UNION ALL
SELECT 'hospital_emr_db', COUNT(*) FROM `hospital_emr_db`.`medical_records`
UNION ALL
SELECT 'hospital_queue_db', COUNT(*) FROM `hospital_queue_db`.`queue_tokens`
UNION ALL
SELECT 'hospital_billing_db', COUNT(*) FROM `hospital_billing_db`.`bills`
UNION ALL
SELECT 'hospital_pharmacy_db', COUNT(*) FROM `hospital_pharmacy_db`.`medicines`
UNION ALL
SELECT 'hospital_lab_db', COUNT(*) FROM `hospital_lab_db`.`lab_tests`
UNION ALL
SELECT 'hospital_notification_db', COUNT(*) FROM `hospital_notification_db`.`notifications`;

-- ============================================================================
-- END OF MICROSERVICES MYSQL SCRIPT
-- ============================================================================

