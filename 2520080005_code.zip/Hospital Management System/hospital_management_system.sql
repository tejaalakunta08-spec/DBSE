-- ============================================================================
-- PROJECT: MedCare - Hospital Management & OPD Appointment System
-- DATABASE: MySQL 8.0 (Strictly Relational / Normalized Schema)
-- DESCRIPTION: Complete DDL (Table Definitions, PK, FK, Constraints, Indexes) 
--              and DML (Pre-Seeded Master & Operational Data)
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `hospital_management_db` 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `hospital_management_db`;

-- Disable Foreign Key checks during recreation
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- 1. TABLE: users
-- Core authentication and identity table with role-based access control (RBAC).
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'doctor', 'patient') NOT NULL DEFAULT 'patient',
  `phone` VARCHAR(20) DEFAULT NULL,
  `status` ENUM('active', 'inactive', 'suspended') NOT NULL DEFAULT 'active',
  `avatar` VARCHAR(255) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. TABLE: patients
-- Electronic Health Record (EHR) demographics, emergency contacts, insurance.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `patients`;
CREATE TABLE `patients` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `userId` INT NOT NULL,
  `patientCode` VARCHAR(30) NOT NULL,
  `dob` DATE DEFAULT NULL,
  `gender` ENUM('male', 'female', 'other') DEFAULT 'other',
  `bloodGroup` ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `emergencyContactName` VARCHAR(100) DEFAULT NULL,
  `emergencyContactPhone` VARCHAR(20) DEFAULT NULL,
  `allergies` TEXT DEFAULT NULL,
  `chronicConditions` TEXT DEFAULT NULL,
  `insuranceProvider` VARCHAR(100) DEFAULT NULL,
  `insurancePolicyNumber` VARCHAR(50) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `patients_user_id_unique` (`userId`),
  UNIQUE KEY `patients_code_unique` (`patientCode`),
  CONSTRAINT `fk_patients_user` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. TABLE: doctors
-- Specialist physician profiles, consultation fees, departments, room allocations.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `doctors`;
CREATE TABLE `doctors` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `userId` INT NOT NULL,
  `doctorCode` VARCHAR(30) NOT NULL,
  `department` VARCHAR(100) NOT NULL,
  `specialization` VARCHAR(120) NOT NULL,
  `qualification` VARCHAR(150) NOT NULL,
  `experienceYears` INT NOT NULL DEFAULT 1,
  `consultationFee` DECIMAL(10,2) NOT NULL DEFAULT 500.00,
  `roomNumber` VARCHAR(20) DEFAULT NULL,
  `bio` TEXT DEFAULT NULL,
  `isAvailableToday` TINYINT(1) DEFAULT 1,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `doctors_user_id_unique` (`userId`),
  UNIQUE KEY `doctors_code_unique` (`doctorCode`),
  INDEX `idx_doctors_department` (`department`),
  CONSTRAINT `fk_doctors_user` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. TABLE: doctor_schedules
-- Outpatient Department (OPD) weekly shift hours, slot durations, daily quotas.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `doctor_schedules`;
CREATE TABLE `doctor_schedules` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `doctorId` INT NOT NULL,
  `dayOfWeek` ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') NOT NULL,
  `startTime` TIME NOT NULL DEFAULT '09:00:00',
  `endTime` TIME NOT NULL DEFAULT '17:00:00',
  `slotDurationMinutes` INT NOT NULL DEFAULT 20,
  `maxPatients` INT NOT NULL DEFAULT 25,
  `isAvailable` TINYINT(1) DEFAULT 1,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_doctor_day_unique` (`doctorId`, `dayOfWeek`),
  CONSTRAINT `fk_doctor_schedules_doctor` FOREIGN KEY (`doctorId`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. TABLE: appointments
-- OPD bookings linking patients, doctors, scheduled slots, and visit reasons.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `appointments`;
CREATE TABLE `appointments` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `appointmentNumber` VARCHAR(40) NOT NULL,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `appointmentDate` DATE NOT NULL,
  `timeSlot` VARCHAR(20) NOT NULL,
  `status` ENUM('pending', 'confirmed', 'in_consultation', 'completed', 'cancelled', 'no_show') NOT NULL DEFAULT 'confirmed',
  `reason` VARCHAR(255) NOT NULL,
  `symptoms` TEXT DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `cancelledBy` ENUM('patient', 'doctor', 'admin', 'system') DEFAULT NULL,
  `cancellationReason` TEXT DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `appointments_number_unique` (`appointmentNumber`),
  INDEX `idx_appointments_doc_date` (`doctorId`, `appointmentDate`),
  INDEX `idx_appointments_patient` (`patientId`),
  INDEX `idx_appointments_status` (`status`),
  CONSTRAINT `fk_appointments_patient` FOREIGN KEY (`patientId`) REFERENCES `patients` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_appointments_doctor` FOREIGN KEY (`doctorId`) REFERENCES `doctors` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. TABLE: queue_tokens
-- Daily OPD sequential queue management with live wait tracking.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `queue_tokens`;
CREATE TABLE `queue_tokens` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `appointmentId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `patientId` INT NOT NULL,
  `tokenNumber` INT NOT NULL,
  `tokenCode` VARCHAR(30) NOT NULL,
  `tokenDate` DATE NOT NULL,
  `status` ENUM('waiting', 'serving', 'completed', 'skipped', 'cancelled') NOT NULL DEFAULT 'waiting',
  `estimatedTime` VARCHAR(20) DEFAULT NULL,
  `calledAt` DATETIME DEFAULT NULL,
  `completedAt` DATETIME DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `queue_tokens_appointment_unique` (`appointmentId`),
  INDEX `idx_queue_doc_date_status` (`doctorId`, `tokenDate`, `status`),
  INDEX `idx_queue_patient` (`patientId`),
  CONSTRAINT `fk_queue_appointment` FOREIGN KEY (`appointmentId`) REFERENCES `appointments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_queue_doctor` FOREIGN KEY (`doctorId`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_queue_patient` FOREIGN KEY (`patientId`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 7. TABLE: medical_records
-- Electronic Medical Record (EMR) visit summaries, diagnoses, vital signs.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `medical_records`;
CREATE TABLE `medical_records` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `appointmentId` INT DEFAULT NULL,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `visitDate` DATE NOT NULL,
  `symptoms` TEXT NOT NULL,
  `diagnosis` TEXT NOT NULL,
  `bloodPressure` VARCHAR(20) DEFAULT NULL,
  `heartRate` INT DEFAULT NULL,
  `temperature` DECIMAL(4,1) DEFAULT NULL,
  `weight` DECIMAL(5,2) DEFAULT NULL,
  `doctorNotes` TEXT DEFAULT NULL,
  `followUpDate` DATE DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_records_patient` (`patientId`),
  INDEX `idx_records_doctor` (`doctorId`),
  CONSTRAINT `fk_records_appointment` FOREIGN KEY (`appointmentId`) REFERENCES `appointments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_records_patient` FOREIGN KEY (`patientId`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_records_doctor` FOREIGN KEY (`doctorId`) REFERENCES `doctors` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 8. TABLE: medicines
-- Master pharmacy medicine catalog, stock levels, reorder thresholds.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `medicines`;
CREATE TABLE `medicines` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(30) NOT NULL,
  `name` VARCHAR(120) NOT NULL,
  `genericName` VARCHAR(120) DEFAULT NULL,
  `category` VARCHAR(60) NOT NULL,
  `manufacturer` VARCHAR(100) DEFAULT NULL,
  `dosageForm` ENUM('Tablet', 'Capsule', 'Syrup', 'Injection', 'Ointment', 'Drops', 'Inhaler') NOT NULL DEFAULT 'Tablet',
  `strength` VARCHAR(40) DEFAULT NULL,
  `unitPrice` DECIMAL(10,2) NOT NULL DEFAULT 10.00,
  `stockQuantity` INT NOT NULL DEFAULT 0,
  `reorderLevel` INT NOT NULL DEFAULT 20,
  `batchNumber` VARCHAR(50) DEFAULT NULL,
  `expiryDate` DATE DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `medicines_code_unique` (`code`),
  INDEX `idx_medicines_name` (`name`),
  INDEX `idx_medicines_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 9. TABLE: prescriptions
-- Digital prescription headers linked to clinical consultations.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `prescriptions`;
CREATE TABLE `prescriptions` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `prescriptionCode` VARCHAR(40) NOT NULL,
  `medicalRecordId` INT DEFAULT NULL,
  `appointmentId` INT DEFAULT NULL,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `status` ENUM('prescribed', 'dispensed', 'cancelled') NOT NULL DEFAULT 'prescribed',
  `generalAdvice` TEXT DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `prescriptions_code_unique` (`prescriptionCode`),
  INDEX `idx_prescriptions_patient` (`patientId`),
  INDEX `idx_prescriptions_doctor` (`doctorId`),
  CONSTRAINT `fk_prescriptions_record` FOREIGN KEY (`medicalRecordId`) REFERENCES `medical_records` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_prescriptions_appointment` FOREIGN KEY (`appointmentId`) REFERENCES `appointments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_prescriptions_patient` FOREIGN KEY (`patientId`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_prescriptions_doctor` FOREIGN KEY (`doctorId`) REFERENCES `doctors` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 10. TABLE: prescription_items
-- Individual prescribed drug lines with frequency, duration, and instructions.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `prescription_items`;
CREATE TABLE `prescription_items` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `prescriptionId` INT NOT NULL,
  `medicineId` INT DEFAULT NULL,
  `medicineName` VARCHAR(120) NOT NULL,
  `dosage` VARCHAR(60) NOT NULL,
  `frequency` VARCHAR(60) NOT NULL,
  `durationDays` INT NOT NULL DEFAULT 5,
  `quantity` INT NOT NULL DEFAULT 10,
  `instructions` VARCHAR(255) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_items_prescription` (`prescriptionId`),
  CONSTRAINT `fk_items_prescription` FOREIGN KEY (`prescriptionId`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_items_medicine` FOREIGN KEY (`medicineId`) REFERENCES `medicines` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 11. TABLE: inventory_transactions
-- Audit log of pharmacy stock-in, stock-out, and patient dispensing.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `inventory_transactions`;
CREATE TABLE `inventory_transactions` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `medicineId` INT NOT NULL,
  `transactionType` ENUM('stock_in', 'stock_out', 'dispensed', 'expired_loss', 'adjustment') NOT NULL,
  `quantity` INT NOT NULL,
  `unitCost` DECIMAL(10,2) DEFAULT NULL,
  `referenceType` VARCHAR(50) DEFAULT NULL,
  `referenceId` VARCHAR(50) DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `performedBy` VARCHAR(100) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_inventory_medicine` (`medicineId`),
  INDEX `idx_inventory_type` (`transactionType`),
  CONSTRAINT `fk_inventory_medicine` FOREIGN KEY (`medicineId`) REFERENCES `medicines` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 12. TABLE: bills
-- Itemized invoices tracking consultation, pharmacy, and laboratory fees.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `bills`;
CREATE TABLE `bills` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `billNumber` VARCHAR(40) NOT NULL,
  `appointmentId` INT DEFAULT NULL,
  `patientId` INT NOT NULL,
  `consultationFee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `medicineFee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `labFee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `otherCharges` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `taxAmount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `discountAmount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `totalAmount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `paidAmount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `balanceAmount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `paymentStatus` ENUM('unpaid', 'partial', 'paid', 'refunded') NOT NULL DEFAULT 'unpaid',
  `paymentMethod` ENUM('cash', 'credit_card', 'debit_card', 'upi', 'insurance', 'online') NOT NULL DEFAULT 'cash',
  `transactionReference` VARCHAR(100) DEFAULT NULL,
  `billDate` DATE NOT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bills_number_unique` (`billNumber`),
  INDEX `idx_bills_patient` (`patientId`),
  INDEX `idx_bills_status` (`paymentStatus`),
  INDEX `idx_bills_date` (`billDate`),
  CONSTRAINT `fk_bills_appointment` FOREIGN KEY (`appointmentId`) REFERENCES `appointments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_bills_patient` FOREIGN KEY (`patientId`) REFERENCES `patients` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 13. TABLE: insurance_claims
-- Third-party health insurance claim submission and adjudication records.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `insurance_claims`;
CREATE TABLE `insurance_claims` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `claimNumber` VARCHAR(40) NOT NULL,
  `billId` INT NOT NULL,
  `patientId` INT NOT NULL,
  `providerName` VARCHAR(100) NOT NULL,
  `policyNumber` VARCHAR(60) NOT NULL,
  `claimAmount` DECIMAL(10,2) NOT NULL,
  `approvedAmount` DECIMAL(10,2) DEFAULT 0.00,
  `claimStatus` ENUM('submitted', 'in_review', 'approved', 'rejected', 'settled') NOT NULL DEFAULT 'submitted',
  `submissionDate` DATE NOT NULL,
  `adjudicationDate` DATE DEFAULT NULL,
  `remarks` TEXT DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `claims_number_unique` (`claimNumber`),
  INDEX `idx_claims_bill` (`billId`),
  INDEX `idx_claims_patient` (`patientId`),
  INDEX `idx_claims_status` (`claimStatus`),
  CONSTRAINT `fk_claims_bill` FOREIGN KEY (`billId`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_claims_patient` FOREIGN KEY (`patientId`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 14. TABLE: lab_tests
-- Diagnostic pathology & radiological imaging investigation catalog.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `lab_tests`;
CREATE TABLE `lab_tests` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(30) NOT NULL,
  `name` VARCHAR(120) NOT NULL,
  `category` VARCHAR(80) NOT NULL,
  `standardFee` DECIMAL(10,2) NOT NULL DEFAULT 300.00,
  `normalRange` VARCHAR(100) DEFAULT NULL,
  `unit` VARCHAR(40) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `sampleRequired` VARCHAR(60) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lab_tests_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 15. TABLE: lab_reports
-- Patient specimen test findings, abnormal flags, pathologist remarks.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `lab_reports`;
CREATE TABLE `lab_reports` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `reportNumber` VARCHAR(40) NOT NULL,
  `testId` INT NOT NULL,
  `appointmentId` INT DEFAULT NULL,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `prescribedDate` DATE NOT NULL,
  `sampleCollectedDate` DATETIME DEFAULT NULL,
  `resultDate` DATETIME DEFAULT NULL,
  `resultValue` TEXT DEFAULT NULL,
  `normalRangeSnapshot` VARCHAR(100) DEFAULT NULL,
  `unit` VARCHAR(40) DEFAULT NULL,
  `status` ENUM('ordered', 'sample_collected', 'in_progress', 'completed', 'cancelled') NOT NULL DEFAULT 'ordered',
  `isAbnormal` TINYINT(1) DEFAULT 0,
  `technicianNotes` TEXT DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lab_reports_number_unique` (`reportNumber`),
  INDEX `idx_reports_patient` (`patientId`),
  INDEX `idx_reports_doctor` (`doctorId`),
  INDEX `idx_reports_status` (`status`),
  CONSTRAINT `fk_reports_test` FOREIGN KEY (`testId`) REFERENCES `lab_tests` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_reports_appointment` FOREIGN KEY (`appointmentId`) REFERENCES `appointments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_reports_patient` FOREIGN KEY (`patientId`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_reports_doctor` FOREIGN KEY (`doctorId`) REFERENCES `doctors` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 16. TABLE: notifications
-- In-app and Twilio SMS notification dispatch logs.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `userId` INT DEFAULT NULL,
  `recipientPhone` VARCHAR(25) DEFAULT NULL,
  `recipientEmail` VARCHAR(120) DEFAULT NULL,
  `title` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `channel` ENUM('in_app', 'sms', 'both') NOT NULL DEFAULT 'in_app',
  `notificationType` ENUM('appointment_booking', 'appointment_confirmed', 'appointment_cancelled', 'queue_update', 'prescription_ready', 'bill_generated', 'lab_result_ready', 'general') NOT NULL DEFAULT 'general',
  `isRead` TINYINT(1) DEFAULT 0,
  `smsStatus` ENUM('none', 'pending', 'sent', 'failed', 'simulated') DEFAULT 'none',
  `smsSid` VARCHAR(80) DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_notifications_user_read` (`userId`, `isRead`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 17. TABLE: audit_logs
-- Immutable chronological security audit trail of administrative & clinical actions.
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `userId` INT DEFAULT NULL,
  `userName` VARCHAR(100) DEFAULT NULL,
  `role` VARCHAR(30) DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `entityType` VARCHAR(50) DEFAULT NULL,
  `entityId` VARCHAR(50) DEFAULT NULL,
  `details` TEXT DEFAULT NULL,
  `ipAddress` VARCHAR(45) DEFAULT NULL,
  `userAgent` TEXT DEFAULT NULL,
  `createdAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_audit_action` (`action`),
  INDEX `idx_audit_user` (`userId`),
  INDEX `idx_audit_created` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Re-enable Foreign Key checks
SET FOREIGN_KEY_CHECKS = 1;


-- ============================================================================
-- DML: PRE-SEEDED MASTER & DEMO RECORDS
-- Passwords below are pre-hashed with bcrypt (Salt 10):
-- Admin: Admin@123 | Doctors: Doctor@123 | Patients: Patient@123
-- ============================================================================

-- 1. Insert Users (Admin, 5 Doctors, 3 Patients)
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `phone`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Super Hospital Admin', 'admin@hospital.com', '$2a$10$ej6Y8EEy/kQ/OvUvHz4LeONDAAP1Z2XORw7P3bCR7eLyt47..ldMu', 'admin', '+919876543210', 'active', NOW(), NOW()),
(2, 'Ramesh Sharma', 'dr.sharma@hospital.com', '$2a$10$pMJ4EyA8D3R4vBqsbwBQAuKsjttJOG3vowRMlPOdkr0JIdLAhg8hq', 'doctor', '+919811122334', 'active', NOW(), NOW()),
(3, 'Priya Nair', 'dr.priya@hospital.com', '$2a$10$CtWCdfTGqo8aO8Bho.K7OO045f552wMndkNTWJAbPMbp/Adu/Ph5W', 'doctor', '+919822233445', 'active', NOW(), NOW()),
(4, 'Rajesh Patel', 'dr.rajesh@hospital.com', '$2a$10$wdEAPNwfxsBCP6PGZufPAeX2VPORFCfA62Sid89H6Z27uTeip/gb6', 'doctor', '+919833344556', 'active', NOW(), NOW()),
(5, 'Anita Desai', 'dr.anita@hospital.com', '$2a$10$Ilnd2GxI.R.0MIblWUknfuy0tnqABQkgg3PaSL4O0Jrg7f7wDkP22', 'doctor', '+919844455667', 'active', NOW(), NOW()),
(6, 'Vikram Joshi', 'dr.vikram@hospital.com', '$2a$10$pN2vT0JXkBlFMty6RHmDIeNxJvErkZzRrWa7pecarH0wiRzh0swnK', 'doctor', '+919855566778', 'active', NOW(), NOW()),
(7, 'Lakshmi Sai Teja', 'patient.sai@hospital.com', '$2a$10$SaXvimWQ8FvXkVppECUEEOoWYXn1Medoq1yF0AMhPLFgw5XTpLsv.', 'patient', '+919100011223', 'active', NOW(), NOW()),
(8, 'Rahul Verma', 'patient.rahul@hospital.com', '$2a$10$dh6HyFKrdGk4CU9.03bpKeeRFrgk6c/yLFBQutDbAYtDdy4nAlYWe', 'patient', '+919200022334', 'active', NOW(), NOW()),
(9, 'Sneha Patel', 'patient.sneha@hospital.com', '$2a$10$fkn9BVqUi6RaW5Ng3Oh2Qumu54xXXD1lMQH5NPEu18k6HVJPPugTK', 'patient', '+919300033445', 'active', NOW(), NOW());

-- 2. Insert Patients Profiles
INSERT INTO `patients` (`id`, `userId`, `patientCode`, `dob`, `gender`, `bloodGroup`, `address`, `emergencyContactName`, `emergencyContactPhone`, `allergies`, `chronicConditions`, `insuranceProvider`, `insurancePolicyNumber`, `createdAt`, `updatedAt`) VALUES
(1, 7, 'PAT-10021', '2001-08-15', 'male', 'B+', 'H.No 4-22, Jubilee Hills, Hyderabad', 'Alakunta Srinivas', '+919100099887', 'Penicillin allergy', 'Mild Seasonal Asthma', 'Star Health Care Allied Insurance', 'SH-POL-8839210', NOW(), NOW()),
(2, 8, 'PAT-10022', '1995-04-12', 'male', 'O+', 'Flat 302, Green Meadows, Bengaluru', 'Meera Verma', '+919200088776', 'None', 'Hypertension', 'HDFC ERGO General Insurance', 'HE-9921445', NOW(), NOW()),
(3, 9, 'PAT-10023', '1998-11-20', 'female', 'A+', 'Villa 14, Lotus Palms, Ahmedabad', 'Kunal Patel', '+919300077665', 'Sulfa drugs', 'None', 'Care Health Insurance', 'CHI-7712398', NOW(), NOW());

-- 3. Insert Doctors Profiles
INSERT INTO `doctors` (`id`, `userId`, `doctorCode`, `department`, `specialization`, `qualification`, `experienceYears`, `consultationFee`, `roomNumber`, `bio`, `isAvailableToday`, `createdAt`, `updatedAt`) VALUES
(1, 2, 'DOC-CAR-101', 'Cardiology', 'Interventional Cardiology', 'MBBS, MD, DM (Cardiology), FACC', 14, 800.00, 'OPD-101', 'Senior consultant cardiologist specializing in heart failure and coronary interventions.', 1, NOW(), NOW()),
(2, 3, 'DOC-NEU-102', 'Neurology', 'Clinical Neurology & Epilepsy', 'MBBS, MD, DM (Neurology)', 10, 750.00, 'OPD-105', 'Leading neurologist focusing on migraine management, stroke rehabilitation, and neuropathy.', 1, NOW(), NOW()),
(3, 4, 'DOC-ORT-103', 'Orthopedics', 'Joint Replacement & Arthroscopy', 'MBBS, MS (Ortho), M.Ch', 12, 700.00, 'OPD-202', 'Specialist in robotic knee and hip replacements and sports injury management.', 1, NOW(), NOW()),
(4, 5, 'DOC-PED-104', 'Pediatrics', 'General Pediatrics & Neonatology', 'MBBS, MD (Pediatrics), DCH', 8, 600.00, 'OPD-108', 'Dedicated pediatrician providing comprehensive child health care and vaccinations.', 1, NOW(), NOW()),
(5, 6, 'DOC-GEN-105', 'General Medicine', 'Internal Medicine & Diabetology', 'MBBS, MD (Internal Medicine)', 15, 500.00, 'OPD-110', 'General physician expert in metabolic syndrome, lifestyle diseases, and hypertension.', 1, NOW(), NOW());

-- 4. Insert Doctor Schedules (Monday to Saturday)
INSERT INTO `doctor_schedules` (`doctorId`, `dayOfWeek`, `startTime`, `endTime`, `slotDurationMinutes`, `maxPatients`, `isAvailable`, `createdAt`, `updatedAt`) VALUES
(1, 'Monday', '09:00:00', '17:00:00', 20, 25, 1, NOW(), NOW()),
(1, 'Tuesday', '09:00:00', '17:00:00', 20, 25, 1, NOW(), NOW()),
(1, 'Wednesday', '09:00:00', '17:00:00', 20, 25, 1, NOW(), NOW()),
(1, 'Thursday', '09:00:00', '17:00:00', 20, 25, 1, NOW(), NOW()),
(1, 'Friday', '09:00:00', '17:00:00', 20, 25, 1, NOW(), NOW()),
(1, 'Saturday', '09:00:00', '13:00:00', 20, 15, 1, NOW(), NOW()),
(2, 'Monday', '09:00:00', '17:00:00', 20, 25, 1, NOW(), NOW()),
(2, 'Tuesday', '09:00:00', '17:00:00', 20, 25, 1, NOW(), NOW()),
(2, 'Wednesday', '09:00:00', '17:00:00', 20, 25, 1, NOW(), NOW()),
(2, 'Thursday', '09:00:00', '17:00:00', 20, 25, 1, NOW(), NOW()),
(2, 'Friday', '09:00:00', '17:00:00', 20, 25, 1, NOW(), NOW()),
(2, 'Saturday', '09:00:00', '13:00:00', 20, 15, 1, NOW(), NOW());

-- 5. Insert Medicines Catalog
INSERT INTO `medicines` (`id`, `code`, `name`, `genericName`, `category`, `manufacturer`, `dosageForm`, `strength`, `unitPrice`, `stockQuantity`, `reorderLevel`, `batchNumber`, `expiryDate`, `createdAt`, `updatedAt`) VALUES
(1, 'MED-1001', 'Paracetamol 650mg', 'Acetaminophen', 'Analgesics', 'Cipla Ltd', 'Tablet', '650mg', 3.50, 250, 50, 'BAT-PCM-01', '2027-10-15', NOW(), NOW()),
(2, 'MED-1002', 'Amoxicillin 500mg', 'Amoxicillin Trihydrate', 'Antibiotics', 'Sun Pharma', 'Capsule', '500mg', 12.00, 180, 40, 'BAT-AMX-02', '2026-12-31', NOW(), NOW()),
(3, 'MED-1003', 'Atorvastatin 20mg', 'Atorvastatin Calcium', 'Cardiovascular', 'Dr. Reddys', 'Tablet', '20mg', 18.50, 120, 30, 'BAT-ATV-03', '2028-04-20', NOW(), NOW()),
(4, 'MED-1004', 'Metformin 500mg ER', 'Metformin Hydrochloride', 'Antidiabetic', 'Torrent Pharma', 'Tablet', '500mg', 8.00, 300, 50, 'BAT-MET-04', '2027-08-30', NOW(), NOW()),
(5, 'MED-1005', 'Cetirizine 10mg', 'Cetirizine Dihydrochloride', 'Antihistamines', 'Alkem Labs', 'Tablet', '10mg', 4.50, 15, 25, 'BAT-CET-05', '2027-02-14', NOW(), NOW()),
(6, 'MED-1006', 'Omeprazole 20mg', 'Omeprazole', 'Gastrointestinal', 'Zydus Cadila', 'Capsule', '20mg', 9.00, 140, 30, 'BAT-OMP-06', '2027-11-25', NOW(), NOW()),
(7, 'MED-1007', 'Azithromycin 500mg', 'Azithromycin', 'Antibiotics', 'Lupin Ltd', 'Tablet', '500mg', 22.00, 8, 20, 'BAT-AZI-07', '2026-11-10', NOW(), NOW()),
(8, 'MED-1008', 'Cough Syrup 100ml', 'Dextromethorphan + Chlorpheniramine', 'Respiratory', 'Abbott', 'Syrup', '100ml', 110.00, 75, 15, 'BAT-CS-08', '2027-06-18', NOW(), NOW());

-- 6. Insert Diagnostic Lab Tests Catalog
INSERT INTO `lab_tests` (`id`, `code`, `name`, `category`, `standardFee`, `normalRange`, `unit`, `description`, `sampleRequired`, `createdAt`, `updatedAt`) VALUES
(1, 'LAB-101', 'Complete Blood Count (CBC)', 'Hematology', 350.00, 'WBC: 4000-11000 /mcL, Hb: 13-17 g/dL', 'Various', 'Analyzes red cells, white blood cells, and platelets.', 'Whole Blood (EDTA)', NOW(), NOW()),
(2, 'LAB-102', 'Lipid Profile Screen', 'Biochemistry', 650.00, 'Cholesterol < 200, LDL < 100, HDL > 40 mg/dL', 'mg/dL', 'Evaluates cardiac risk factors and cholesterol balance.', 'Blood - Serum (Fasting)', NOW(), NOW()),
(3, 'LAB-103', 'Fasting Blood Glucose & HbA1c', 'Endocrinology', 500.00, 'FBS: 70-99 mg/dL, HbA1c < 5.7%', 'mg/dL / %', 'Screening and management of diabetes mellitus.', 'Blood - Fluoride / EDTA', NOW(), NOW()),
(4, 'LAB-104', 'Liver Function Test (LFT)', 'Biochemistry', 750.00, 'ALT: 7-56 U/L, AST: 10-40 U/L, Bilirubin < 1.2 mg/dL', 'U/L', 'Measures liver enzymes, proteins, and bilirubin levels.', 'Blood - Serum', NOW(), NOW()),
(5, 'LAB-105', 'Thyroid Stimulating Hormone (TSH)', 'Endocrinology', 450.00, '0.4 - 4.0 mIU/L', 'mIU/L', 'Screens for hypo- and hyperthyroidism.', 'Blood - Serum', NOW(), NOW()),
(6, 'LAB-106', 'Chest X-Ray PA View', 'Radiology', 550.00, 'Clear lung fields, normal cardiac silhouette', 'Imaging', 'Digital radiological examination of lungs, ribs, and heart.', 'Radiological scan', NOW(), NOW());

-- 7. Insert Appointments
INSERT INTO `appointments` (`id`, `appointmentNumber`, `patientId`, `doctorId`, `appointmentDate`, `timeSlot`, `status`, `reason`, `symptoms`, `createdAt`, `updatedAt`) VALUES
(1, 'APT-20260930-101', 1, 1, CURDATE(), '09:40 AM', 'completed', 'Routine cardiac health review and occasional palpitations.', 'Shortness of breath on exertion, lightheadedness.', NOW(), NOW()),
(2, 'APT-20260930-102', 2, 1, CURDATE(), '10:00 AM', 'confirmed', 'Hypertension follow-up and blood pressure monitoring.', 'Mild morning headache.', NOW(), NOW()),
(3, 'APT-20260930-103', 3, 2, CURDATE(), '11:20 AM', 'confirmed', 'Throbbing migraine episodes and photophobia.', 'Unilateral head pain lasting 8 hours.', NOW(), NOW());

-- 8. Insert OPD Queue Tokens
INSERT INTO `queue_tokens` (`id`, `appointmentId`, `doctorId`, `patientId`, `tokenNumber`, `tokenCode`, `tokenDate`, `status`, `estimatedTime`, `calledAt`, `completedAt`, `createdAt`, `updatedAt`) VALUES
(1, 1, 1, 1, 1, 'OPD-DOC-CAR-001', CURDATE(), 'completed', '09:40 AM', NOW(), NOW(), NOW(), NOW()),
(2, 2, 1, 2, 2, 'OPD-DOC-CAR-002', CURDATE(), 'waiting', '10:00 AM', NULL, NULL, NOW(), NOW()),
(3, 3, 2, 3, 1, 'OPD-DOC-NEU-001', CURDATE(), 'waiting', '11:20 AM', NULL, NULL, NOW(), NOW());

-- 9. Insert Bills & Invoices
INSERT INTO `bills` (`id`, `billNumber`, `appointmentId`, `patientId`, `consultationFee`, `medicineFee`, `labFee`, `otherCharges`, `subtotal`, `taxAmount`, `discountAmount`, `totalAmount`, `paidAmount`, `balanceAmount`, `paymentStatus`, `paymentMethod`, `transactionReference`, `billDate`, `createdAt`, `updatedAt`) VALUES
(1, 'INV-20260930-5001', 1, 1, 800.00, 185.00, 650.00, 0.00, 1635.00, 0.00, 100.00, 1535.00, 1535.00, 0.00, 'paid', 'upi', 'UPI-REF-8849201948', CURDATE(), NOW(), NOW()),
(2, 'INV-20260930-5002', 2, 2, 800.00, 0.00, 0.00, 0.00, 800.00, 0.00, 0.00, 800.00, 0.00, 800.00, 'unpaid', 'cash', NULL, CURDATE(), NOW(), NOW()),
(3, 'INV-20260930-5003', 3, 3, 750.00, 0.00, 0.00, 0.00, 750.00, 0.00, 0.00, 750.00, 750.00, 0.00, 'paid', 'credit_card', 'CARD-AUTH-991203', CURDATE(), NOW(), NOW());

-- 10. Insert Insurance Claims
INSERT INTO `insurance_claims` (`id`, `claimNumber`, `billId`, `patientId`, `providerName`, `policyNumber`, `claimAmount`, `approvedAmount`, `claimStatus`, `submissionDate`, `adjudicationDate`, `remarks`, `createdAt`, `updatedAt`) VALUES
(1, 'CLM-202609-01', 1, 1, 'Star Health Care Allied Insurance', 'SH-POL-8839210', 1535.00, 1435.00, 'approved', CURDATE(), CURDATE(), 'Covered under cardiac preventive wellness package.', NOW(), NOW());

-- 11. Insert Medical Records (EMR)
INSERT INTO `medical_records` (`id`, `appointmentId`, `patientId`, `doctorId`, `visitDate`, `symptoms`, `diagnosis`, `bloodPressure`, `heartRate`, `temperature`, `weight`, `doctorNotes`, `followUpDate`, `createdAt`, `updatedAt`) VALUES
(1, 1, 1, 1, CURDATE(), 'Occasional palpitations after heavy meals, mild dyspnea.', 'Sinus Tachycardia, Borderline Dyslipidemia', '128/82', 84, 98.4, 68.50, 'Advised 30 minutes brisk walking daily. Low sodium, Mediterranean-style diet. Follow up in 30 days.', '2026-10-30', NOW(), NOW());

-- 12. Insert Prescriptions & Prescription Items
INSERT INTO `prescriptions` (`id`, `prescriptionCode`, `medicalRecordId`, `appointmentId`, `patientId`, `doctorId`, `status`, `generalAdvice`, `createdAt`, `updatedAt`) VALUES
(1, 'RX-202609-001', 1, 1, 1, 1, 'dispensed', 'Drink 3 liters of water daily. Avoid excess caffeine.', NOW(), NOW());

INSERT INTO `prescription_items` (`id`, `prescriptionId`, `medicineId`, `medicineName`, `dosage`, `frequency`, `durationDays`, `quantity`, `instructions`, `createdAt`, `updatedAt`) VALUES
(1, 1, 3, 'Atorvastatin 20mg', '1 tablet', '0-0-1 (Once daily at bedtime)', 30, 30, 'Take after dinner with water', NOW(), NOW());

-- 13. Insert Diagnostic Lab Reports
INSERT INTO `lab_reports` (`id`, `reportNumber`, `testId`, `appointmentId`, `patientId`, `doctorId`, `prescribedDate`, `sampleCollectedDate`, `resultDate`, `resultValue`, `normalRangeSnapshot`, `unit`, `status`, `isAbnormal`, `technicianNotes`, `createdAt`, `updatedAt`) VALUES
(1, 'LBR-202609-001', 2, 1, 1, 1, CURDATE(), NOW(), NOW(), 'Total Cholesterol: 215 mg/dL (Borderline High), Triglycerides: 160 mg/dL, HDL: 44 mg/dL, LDL: 139 mg/dL', 'Cholesterol < 200, LDL < 100, HDL > 40 mg/dL', 'mg/dL', 'completed', 1, 'Lipemic serum sample. Recheck recommended in 6-8 weeks.', NOW(), NOW());

-- 14. Insert Notifications
INSERT INTO `notifications` (`id`, `userId`, `recipientPhone`, `recipientEmail`, `title`, `message`, `channel`, `notificationType`, `isRead`, `smsStatus`, `smsSid`, `createdAt`, `updatedAt`) VALUES
(1, 7, '+919100011223', 'patient.sai@hospital.com', 'Appointment Confirmed', 'Your appointment with Dr. Ramesh Sharma is confirmed for today at 09:40 AM. OPD Token: #1', 'both', 'appointment_confirmed', 0, 'simulated', 'MOCK_SMS_1001', NOW(), NOW()),
(2, 7, '+919100011223', 'patient.sai@hospital.com', 'Lab Report Ready', 'Your Lipid Profile report is ready for viewing. Total Cholesterol is 215 mg/dL.', 'both', 'lab_result_ready', 1, 'simulated', 'MOCK_SMS_1002', NOW(), NOW());

-- 15. Insert Audit Logs
INSERT INTO `audit_logs` (`id`, `userId`, `userName`, `role`, `action`, `entityType`, `entityId`, `details`, `ipAddress`, `userAgent`, `createdAt`, `updatedAt`) VALUES
(1, 1, 'Super Hospital Admin', 'admin', 'SYSTEM_INITIALIZATION', 'System', '0', 'Hospital Management System database schema initialized with seed master data.', '127.0.0.1', 'Mozilla/5.0', NOW(), NOW()),
(2, 7, 'Lakshmi Sai Teja', 'patient', 'APPOINTMENT_BOOKED', 'Appointment', '1', 'Booked appointment with Dr. Ramesh Sharma in Cardiology', '127.0.0.1', 'Mozilla/5.0', NOW(), NOW()),
(3, 2, 'Dr. Ramesh Sharma', 'doctor', 'MEDICAL_RECORD_CREATED', 'MedicalRecord', '1', 'Clinical assessment completed and prescription RX-202609-001 issued.', '127.0.0.1', 'Mozilla/5.0', NOW(), NOW());

-- ============================================================================
-- VERIFICATION QUERIES (Useful for Viva / Examiners)
-- ============================================================================

-- A. View all Doctors with Departments and Consulting Fees
-- SELECT d.doctorCode, u.name AS doctor_name, d.department, d.specialization, d.consultationFee, d.roomNumber 
-- FROM doctors d JOIN users u ON d.userId = u.id;

-- B. View Today's Appointments with Patients, Doctors, and Queue Tokens
-- SELECT a.appointmentNumber, p.patientCode, up.name AS patient_name, ud.name AS doctor_name, 
--        d.department, a.appointmentDate, a.timeSlot, qt.tokenNumber, a.status 
-- FROM appointments a
-- JOIN patients p ON a.patientId = p.id
-- JOIN users up ON p.userId = up.id
-- JOIN doctors d ON a.doctorId = d.id
-- JOIN users ud ON d.userId = ud.id
-- LEFT JOIN queue_tokens qt ON a.id = qt.appointmentId;

-- C. Total Hospital Revenue & Balance Summary
-- SELECT SUM(paidAmount) AS total_revenue_collected, SUM(balanceAmount) AS total_outstanding_dues 
-- FROM bills;
