/**
 * Microservices Database Initialization Script
 * Creates 8 separate MySQL databases for each microservice following Database-per-Service pattern.
 */
const path = require('path');
const mysql = require(path.resolve(__dirname, '../backend/node_modules/mysql2/promise'));
require(path.resolve(__dirname, '../backend/node_modules/dotenv')).config({ path: path.resolve(__dirname, '../backend/.env') });

const DB_HOST = process.env.DB_HOST || '127.0.0.1';
const DB_PORT = process.env.DB_PORT || 3306;
const DB_USER = process.env.DB_USER || 'root';
const DB_PASSWORD = process.env.DB_PASSWORD || 'Teja@2007';

const databases = [
  'hospital_auth_db',
  'hospital_appointment_db',
  'hospital_emr_db',
  'hospital_queue_db',
  'hospital_billing_db',
  'hospital_pharmacy_db',
  'hospital_lab_db',
  'hospital_notification_db'
];

async function initDatabases() {
  console.log('=================================================================');
  console.log('🏥 Initializing 8 Separate MySQL Databases for Microservices Architecture');
  console.log('=================================================================');

  try {
    const connection = await mysql.createConnection({
      host: DB_HOST,
      port: DB_PORT,
      user: DB_USER,
      password: DB_PASSWORD
    });

    for (const db of databases) {
      await connection.query(`CREATE DATABASE IF NOT EXISTS \`${db}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`);
      console.log(`✅ Database created / verified: [${db}]`);
    }

    await connection.end();
    console.log('=================================================================');
    console.log('🎉 All 8 microservice databases initialized successfully in MySQL!');
    console.log('=================================================================');
  } catch (error) {
    console.error('❌ Failed to initialize microservice databases:', error.message);
    process.exit(1);
  }
}

if (require.main === module) {
  initDatabases();
}

module.exports = { initDatabases, databases };
