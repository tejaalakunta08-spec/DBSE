/**
 * End-to-End Microservices Integration Test Suite
 * Tests all 8 services through the API Gateway on Port 5000
 */

const GATEWAY_URL = 'http://127.0.0.1:5000/api';

async function runTests() {
  console.log('===============================================================');
  console.log('🧪 RUNNING COMPREHENSIVE MICROSERVICES INTEGRATION TESTS');
  console.log(`🌐 Target: API Gateway (${GATEWAY_URL})`);
  console.log('===============================================================\n');

  let passed = 0;
  let failed = 0;

  async function test(name, fn) {
    try {
      await fn();
      console.log(`  ✅ [PASS] ${name}`);
      passed++;
    } catch (err) {
      console.error(`  ❌ [FAIL] ${name}: ${err.message}`);
      failed++;
    }
  }

  // 1. Health Check
  await test('API Gateway Health Check', async () => {
    const res = await fetch('http://127.0.0.1:5000/health');
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (data.status !== 'UP') throw new Error(`Expected status UP, got ${data.status}`);
  });

  // 2. Auth Service: Public Doctors Directory
  await test('Auth Service: GET /doctors (Public)', async () => {
    const res = await fetch(`${GATEWAY_URL}/doctors`);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || !Array.isArray(data.data) || data.data.length === 0) {
      throw new Error('Failed to retrieve doctors list');
    }
  });

  // 3. Auth Service: Doctor Departments
  await test('Auth Service: GET /doctors/departments (Public)', async () => {
    const res = await fetch(`${GATEWAY_URL}/doctors/departments`);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || !Array.isArray(data.data)) {
      throw new Error('Failed to retrieve doctor departments');
    }
  });

  // 4. Appointment Service: Doctor Slots
  await test('Appointment Service: GET /doctors/1/slots (Public)', async () => {
    const today = new Date().toISOString().split('T')[0];
    const res = await fetch(`${GATEWAY_URL}/doctors/1/slots?date=${today}`);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    const slots = data.data.availableSlots || data.data.slots;
    if (!data.success || !Array.isArray(slots)) {
      throw new Error('Failed to retrieve doctor slots');
    }
  });

  // 5. Auth Service: Patient Login
  let patientToken = '';
  await test('Auth Service: Patient Login (patient.sai@hospital.com)', async () => {
    const res = await fetch(`${GATEWAY_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'patient.sai@hospital.com', password: 'Patient@123' })
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || !data.data.token) throw new Error('Token missing from login response');
    patientToken = data.data.token;
  });

  // 6. Auth Service: Doctor Login
  let doctorToken = '';
  await test('Auth Service: Doctor Login (dr.sharma@hospital.com)', async () => {
    const res = await fetch(`${GATEWAY_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'dr.sharma@hospital.com', password: 'Doctor@123' })
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || !data.data.token) throw new Error('Token missing from login response');
    doctorToken = data.data.token;
  });

  // 7. Auth Service: Admin Login
  let adminToken = '';
  await test('Auth Service: Admin Login (admin@hospital.com)', async () => {
    const res = await fetch(`${GATEWAY_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'admin@hospital.com', password: 'Admin@123' })
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || !data.data.token) throw new Error('Token missing from login response');
    adminToken = data.data.token;
  });

  // 8. Appointment Service: Patient Appointments
  await test('Appointment Service: GET /appointments/my (Patient Auth)', async () => {
    const res = await fetch(`${GATEWAY_URL}/appointments/my`, {
      headers: { 'Authorization': `Bearer ${patientToken}` }
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success) throw new Error('Failed to retrieve patient appointments');
  });

  // 9. Queue Service: Live Queue Status
  await test('Queue Service: GET /queue/my-status (Patient Auth)', async () => {
    const res = await fetch(`${GATEWAY_URL}/queue/my-status`, {
      headers: { 'Authorization': `Bearer ${patientToken}` }
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success) throw new Error('Failed to retrieve patient queue status');
  });

  // 10. Patient & EMR Service: Medical Records
  await test('EMR Service: GET /records/my (Patient Auth)', async () => {
    const res = await fetch(`${GATEWAY_URL}/records/my`, {
      headers: { 'Authorization': `Bearer ${patientToken}` }
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success) throw new Error('Failed to retrieve patient medical records');
  });

  // 11. Billing Service: Patient Bills
  await test('Billing Service: GET /billing (Patient Auth)', async () => {
    const res = await fetch(`${GATEWAY_URL}/billing`, {
      headers: { 'Authorization': `Bearer ${patientToken}` }
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || !data.data.bills) throw new Error('Failed to retrieve patient bills');
  });

  // 12. Pharmacy Service: Medicines List
  await test('Pharmacy Service: GET /pharmacy/medicines (Patient Auth)', async () => {
    const res = await fetch(`${GATEWAY_URL}/pharmacy/medicines`, {
      headers: { 'Authorization': `Bearer ${patientToken}` }
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || !Array.isArray(data.data)) throw new Error('Failed to retrieve pharmacy catalog');
  });

  // 13. Laboratory Service: Diagnostic Tests Catalog
  await test('Laboratory Service: GET /lab/tests (Patient Auth)', async () => {
    const res = await fetch(`${GATEWAY_URL}/lab/tests`, {
      headers: { 'Authorization': `Bearer ${patientToken}` }
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || !Array.isArray(data.data)) throw new Error('Failed to retrieve lab tests');
  });

  // 14. Notification Service: My Notifications
  await test('Notification Service: GET /notifications/my (Patient Auth)', async () => {
    const res = await fetch(`${GATEWAY_URL}/notifications/my`, {
      headers: { 'Authorization': `Bearer ${patientToken}` }
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success) throw new Error('Failed to retrieve user notifications');
  });

  // 15. API Gateway Aggregator: Executive Dashboard Stats
  await test('API Gateway: GET /admin/stats (Admin Auth Aggregator)', async () => {
    const res = await fetch(`${GATEWAY_URL}/admin/stats`, {
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || data.data.totalPatients === undefined || data.data.totalDoctors === undefined) {
      throw new Error('Invalid dashboard stats aggregated response');
    }
  });

  // 16. Auth Service (via Gateway): Admin Audit Logs
  await test('API Gateway -> Auth Service: GET /admin/audit-logs (Admin Auth)', async () => {
    const res = await fetch(`${GATEWAY_URL}/admin/audit-logs`, {
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || !Array.isArray(data.data)) throw new Error('Failed to retrieve audit logs');
  });

  // 17. Security / RBAC: Unauthorized Access Blocked
  await test('Security / RBAC: Patient blocked from /admin/stats (403 Forbidden)', async () => {
    const res = await fetch(`${GATEWAY_URL}/admin/stats`, {
      headers: { 'Authorization': `Bearer ${patientToken}` }
    });
    if (res.status !== 403) throw new Error(`Expected 403 Forbidden, got ${res.status}`);
  });

  // 18. Security: Unauthenticated Access Blocked
  await test('Security: Missing Token blocked from /admin/stats (401 Unauthorized)', async () => {
    const res = await fetch(`${GATEWAY_URL}/admin/stats`);
    if (res.status !== 401) throw new Error(`Expected 401 Unauthorized, got ${res.status}`);
  });

  console.log('\n===============================================================');
  console.log(`📊 TEST RESULTS: ${passed} PASSED | ${failed} FAILED`);
  console.log('===============================================================');

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runTests();
