/**
 * End-to-End Inter-Service Transaction Test
 * Verifies Appointment Service -> Queue Service -> Billing Service -> Notification Service
 */

const GATEWAY_URL = 'http://127.0.0.1:5000/api';

async function testBookingFlow() {
  console.log('===============================================================');
  console.log('🔄 TESTING DISTRIBUTED INTER-SERVICE BOOKING TRANSACTION');
  console.log('===============================================================\n');

  // 1. Patient Login
  const loginRes = await fetch(`${GATEWAY_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'patient.sai@hospital.com', password: 'Patient@123' })
  });
  const loginData = await loginRes.json();
  const token = loginData.data.token;
  console.log('1. Logged in as Patient: Sai Teja');

  // 2. Book appointment for today
  const today = new Date().toISOString().split('T')[0];
  const bookRes = await fetch(`${GATEWAY_URL}/appointments`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
      doctorId: 2, // Dr. Priya Nair
      appointmentDate: today,
      timeSlot: '04:30 PM - 04:50 PM',
      type: 'regular',
      reason: 'Migraine consultation with neurologist'
    })
  });

  const bookData = await bookRes.json();
  console.log('2. Book Appointment Response:', bookData.message);
  if (!bookData.success) {
    throw new Error(`Booking failed: ${JSON.stringify(bookData)}`);
  }

  const appointment = bookData.data;
  console.log(`   - Appointment ID: ${appointment.id}`);
  console.log(`   - Appointment Number: ${appointment.appointmentNumber}`);
  console.log(`   - OPD Token Generated: #${appointment.queueToken?.tokenNumber || 'N/A'} (Code: ${appointment.queueToken?.tokenCode || 'N/A'})`);

  // 3. Verify Queue Service has this token
  const queueRes = await fetch(`${GATEWAY_URL}/queue/my-status`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const queueData = await queueRes.json();
  console.log('3. Queue Service Verification:', queueData.data?.myToken ? `Active Token #${queueData.data.myToken.tokenNumber}` : 'No token');

  // 4. Verify Billing Service has generated the bill
  const billsRes = await fetch(`${GATEWAY_URL}/billing`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const billsData = await billsRes.json();
  const newBill = billsData.data.bills.find(b => b.appointmentId === appointment.id);
  console.log('4. Billing Service Verification:', newBill ? `Bill #${newBill.billNumber} for ₹${newBill.totalAmount}` : 'No bill found');

  // 5. Verify Notification Service logged the confirmation
  const notifRes = await fetch(`${GATEWAY_URL}/notifications/my`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const notifData = await notifRes.json();
  const notifCount = notifData.data?.notifications?.length || notifData.data?.length || 0;
  console.log(`5. Notification Service Verification: Found ${notifCount} notifications for patient.`);

  console.log('\n===============================================================');
  console.log('🎉 DISTRIBUTED INTER-SERVICE TRANSACTION COMPLETED SUCCESSFULLY!');
  console.log('===============================================================\n');
}

testBookingFlow().catch(console.error);
