const mysql = require('mysql2/promise');
require('dotenv').config({ path: './services/auth-service/.env' });

(async () => {
  const conn = await mysql.createConnection({
    host: '127.0.0.1',
    port: 3306,
    user: 'root',
    password: process.env.DB_PASSWORD || 'Teja@2007'
  });

  const query = `
    SELECT 'hospital_auth_db' AS db_name, 'users' AS table_name, COUNT(*) AS count FROM hospital_auth_db.users
    UNION ALL SELECT 'hospital_auth_db', 'doctors', COUNT(*) FROM hospital_auth_db.doctors
    UNION ALL SELECT 'hospital_auth_db', 'patients', COUNT(*) FROM hospital_auth_db.patients
    UNION ALL SELECT 'hospital_appointment_db', 'appointments', COUNT(*) FROM hospital_appointment_db.appointments
    UNION ALL SELECT 'hospital_emr_db', 'medical_records', COUNT(*) FROM hospital_emr_db.medical_records
    UNION ALL SELECT 'hospital_queue_db', 'queue_tokens', COUNT(*) FROM hospital_queue_db.queue_tokens
    UNION ALL SELECT 'hospital_billing_db', 'bills', COUNT(*) FROM hospital_billing_db.bills
    UNION ALL SELECT 'hospital_pharmacy_db', 'medicines', COUNT(*) FROM hospital_pharmacy_db.medicines
    UNION ALL SELECT 'hospital_lab_db', 'lab_tests', COUNT(*) FROM hospital_lab_db.lab_tests
    UNION ALL SELECT 'hospital_notification_db', 'notifications', COUNT(*) FROM hospital_notification_db.notifications;
  `;
  const [rows] = await conn.query(query);
  console.table(rows);
  await conn.end();
})();
