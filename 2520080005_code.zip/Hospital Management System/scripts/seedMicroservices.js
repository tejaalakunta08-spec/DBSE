/**
 * Unified Microservices Database Seeder
 * Populates all 8 independent MySQL microservice databases with realistic initial data.
 * Adheres strictly to the Database-per-Service concept with ID-based referencing.
 */

const authDb = require('../services/auth-service/src/models');
const appointmentDb = require('../services/appointment-service/src/models');
const emrDb = require('../services/emr-service/src/models');
const queueDb = require('../services/queue-service/src/models');
const billingDb = require('../services/billing-service/src/models');
const pharmacyDb = require('../services/pharmacy-service/src/models');
const labDb = require('../services/laboratory-service/src/models');
const notificationDb = require('../services/notification-service/src/models');

async function seedAllMicroservices() {
  console.log('===============================================================');
  console.log('🏥 STARTING UNIFIED MICROSERVICES DATABASE SEEDING');
  console.log('===============================================================');

  try {
    // -----------------------------------------------------------------
    // 1. AUTH & USER SERVICE (hospital_auth_db)
    // -----------------------------------------------------------------
    console.log('\n[1/8] 👤 Seeding Authentication & User Service (hospital_auth_db)...');
    await authDb.sequelize.sync({ force: true });

    // Admin User
    const adminUser = await authDb.User.create({
      name: 'Super Hospital Admin',
      email: 'admin@hospital.com',
      password: 'Admin@123',
      role: 'admin',
      phone: '+919876543210',
      status: 'active'
    });

    // Doctors
    const doctorData = [
      {
        name: 'Ramesh Sharma',
        email: 'dr.sharma@hospital.com',
        password: 'Doctor@123',
        phone: '+919811122334',
        department: 'Cardiology',
        specialization: 'Interventional Cardiology',
        qualification: 'MBBS, MD, DM (Cardiology), FACC',
        experienceYears: 14,
        consultationFee: 800.00,
        roomNumber: 'OPD-101',
        bio: 'Senior consultant cardiologist specializing in heart failure, coronary interventions, and preventative cardiology.'
      },
      {
        name: 'Priya Nair',
        email: 'dr.priya@hospital.com',
        password: 'Doctor@123',
        phone: '+919822233445',
        department: 'Neurology',
        specialization: 'Clinical Neurology & Epilepsy',
        qualification: 'MBBS, MD, DM (Neurology)',
        experienceYears: 10,
        consultationFee: 750.00,
        roomNumber: 'OPD-105',
        bio: 'Leading neurologist focusing on migraine management, stroke rehabilitation, and neuropathy.'
      },
      {
        name: 'Rajesh Patel',
        email: 'dr.rajesh@hospital.com',
        password: 'Doctor@123',
        phone: '+919833344556',
        department: 'Orthopedics',
        specialization: 'Joint Replacement & Arthroscopy',
        qualification: 'MBBS, MS (Ortho), M.Ch',
        experienceYears: 12,
        consultationFee: 700.00,
        roomNumber: 'OPD-202',
        bio: 'Specialist in robotic knee and hip replacements, sports injury management, and spine disorders.'
      },
      {
        name: 'Anita Desai',
        email: 'dr.anita@hospital.com',
        password: 'Doctor@123',
        phone: '+919844455667',
        department: 'Pediatrics',
        specialization: 'General Pediatrics & Neonatology',
        qualification: 'MBBS, MD (Pediatrics), DCH',
        experienceYears: 8,
        consultationFee: 600.00,
        roomNumber: 'OPD-108',
        bio: 'Dedicated pediatrician providing comprehensive child health care, vaccinations, and growth assessments.'
      },
      {
        name: 'Vikram Mehta',
        email: 'dr.vikram@hospital.com',
        password: 'Doctor@123',
        phone: '+919855566778',
        department: 'Dermatology',
        specialization: 'Clinical Dermatology & Cosmetology',
        qualification: 'MBBS, MD (DVL)',
        experienceYears: 11,
        consultationFee: 650.00,
        roomNumber: 'OPD-304',
        bio: 'Expert in clinical dermatology, psoriasis, chronic eczema, and laser skin treatments.'
      }
    ];

    const createdDoctors = [];
    for (const d of doctorData) {
      const user = await authDb.User.create({
        name: d.name,
        email: d.email,
        password: d.password,
        role: 'doctor',
        phone: d.phone,
        status: 'active'
      });

      const deptPrefix = d.department.substring(0, 3).toUpperCase();
      const doctorProfile = await authDb.Doctor.create({
        userId: user.id,
        doctorCode: `DOC-${deptPrefix}-${100 + user.id}`,
        department: d.department,
        specialization: d.specialization,
        qualification: d.qualification,
        experienceYears: d.experienceYears,
        consultationFee: d.consultationFee,
        roomNumber: d.roomNumber,
        bio: d.bio,
        isAvailableToday: true
      });

      createdDoctors.push({ user, profile: doctorProfile });
    }

    // Patients
    const patientData = [
      {
        name: 'Sai Teja',
        email: 'patient.sai@hospital.com',
        password: 'Patient@123',
        phone: '+919876543210',
        dob: '1998-05-15',
        gender: 'male',
        bloodGroup: 'O+',
        address: 'Plot 42, Hitech City, Hyderabad, Telangana',
        emergencyContactName: 'Lakshmi Teja',
        emergencyContactPhone: '+919876500001',
        allergies: 'Penicillin, Dust',
        chronicConditions: 'Mild Hypertension',
        insuranceProvider: 'Star Health Allied Insurance',
        insurancePolicyNumber: 'SH-POL-2024-8849'
      },
      {
        name: 'Ananya Verma',
        email: 'ananya.verma@example.com',
        password: 'Patient@123',
        phone: '+919876543211',
        dob: '2001-09-22',
        gender: 'female',
        bloodGroup: 'B+',
        address: 'B-204, Green Glen Layout, Bellandur, Bengaluru',
        emergencyContactName: 'Sanjay Verma',
        emergencyContactPhone: '+919876500002',
        allergies: 'Sulfa drugs',
        chronicConditions: 'Asthma',
        insuranceProvider: 'Care Health Insurance',
        insurancePolicyNumber: 'CHI-9021-3829'
      },
      {
        name: 'Rahul Kumar',
        email: 'rahul.kumar@example.com',
        password: 'Patient@123',
        phone: '+919876543212',
        dob: '1985-11-04',
        gender: 'male',
        bloodGroup: 'A+',
        address: '12/4 MG Road, Indiranagar, Bengaluru',
        emergencyContactName: 'Pooja Kumar',
        emergencyContactPhone: '+919876500003',
        allergies: 'None',
        chronicConditions: 'Type 2 Diabetes',
        insuranceProvider: 'HDFC ERGO General Insurance',
        insurancePolicyNumber: 'HDFC-MED-7741'
      },
      {
        name: 'Sneha Patil',
        email: 'sneha.patil@example.com',
        password: 'Patient@123',
        phone: '+919876543213',
        dob: '1992-03-30',
        gender: 'female',
        bloodGroup: 'AB+',
        address: '502 Skylark Towers, Kothrud, Pune',
        emergencyContactName: 'Ajay Patil',
        emergencyContactPhone: '+919876500004',
        allergies: 'Peanuts',
        chronicConditions: 'None',
        insuranceProvider: 'ICICI Lombard Health Care',
        insurancePolicyNumber: 'ICICI-HLT-5510'
      }
    ];

    const createdPatients = [];
    for (const p of patientData) {
      const user = await authDb.User.create({
        name: p.name,
        email: p.email,
        password: p.password,
        role: 'patient',
        phone: p.phone,
        status: 'active'
      });

      const patientProfile = await authDb.Patient.create({
        userId: user.id,
        patientCode: `PAT-${100000 + user.id}`,
        dob: p.dob,
        gender: p.gender,
        bloodGroup: p.bloodGroup,
        address: p.address,
        emergencyContactName: p.emergencyContactName,
        emergencyContactPhone: p.emergencyContactPhone,
        allergies: p.allergies,
        chronicConditions: p.chronicConditions,
        insuranceProvider: p.insuranceProvider,
        insurancePolicyNumber: p.insurancePolicyNumber
      });

      createdPatients.push({ user, profile: patientProfile });
    }

    await authDb.AuditLog.create({
      userId: adminUser.id,
      userName: adminUser.name,
      userRole: adminUser.role,
      action: 'SYSTEM_BOOTSTRAP',
      entity: 'System',
      entityId: '0',
      details: 'Microservices database initial bootstrap completed successfully.',
      ipAddress: '127.0.0.1'
    });

    console.log(`✅ Auth Service seeded: 1 Admin, ${createdDoctors.length} Doctors, ${createdPatients.length} Patients.`);

    // -----------------------------------------------------------------
    // 2. APPOINTMENT SERVICE (hospital_appointment_db)
    // -----------------------------------------------------------------
    console.log('\n[2/8] 📅 Seeding Appointment Service (hospital_appointment_db)...');
    await appointmentDb.sequelize.sync({ force: true });

    // Doctor Weekly Schedules
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    for (const d of createdDoctors) {
      for (const day of days) {
        await appointmentDb.DoctorSchedule.create({
          doctorId: d.profile.id,
          dayOfWeek: day,
          startTime: '09:00:00',
          endTime: '17:00:00',
          slotDurationMinutes: 20,
          maxPatientsPerDay: 24,
          isAvailable: true
        });
      }
    }

    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

    const apt1 = await appointmentDb.Appointment.create({
      appointmentNumber: 'APT-2026-0001',
      patientId: createdPatients[0].profile.id,
      doctorId: createdDoctors[0].profile.id,
      appointmentDate: today,
      timeSlot: '09:00 AM - 09:20 AM',
      status: 'confirmed',
      reason: 'Periodic cardiology review and mild chest heaviness checkup.',
      symptoms: 'Mild chest tightness upon climbing stairs'
    });

    const apt2 = await appointmentDb.Appointment.create({
      appointmentNumber: 'APT-2026-0002',
      patientId: createdPatients[1].profile.id,
      doctorId: createdDoctors[0].profile.id,
      appointmentDate: today,
      timeSlot: '09:20 AM - 09:40 AM',
      status: 'in_consultation',
      reason: 'Palpitations during morning workout.',
      symptoms: 'Rapid heartbeat for 10-15 minutes'
    });

    const apt3 = await appointmentDb.Appointment.create({
      appointmentNumber: 'APT-2026-0003',
      patientId: createdPatients[2].profile.id,
      doctorId: createdDoctors[1].profile.id,
      appointmentDate: today,
      timeSlot: '10:00 AM - 10:20 AM',
      status: 'confirmed',
      reason: 'Follow up on chronic migraine prescription.',
      symptoms: 'Headache on left side'
    });

    const apt4 = await appointmentDb.Appointment.create({
      appointmentNumber: 'APT-2026-0004',
      patientId: createdPatients[3].profile.id,
      doctorId: createdDoctors[2].profile.id,
      appointmentDate: tomorrow,
      timeSlot: '11:00 AM - 11:20 AM',
      status: 'confirmed',
      reason: 'Right knee joint pain after jogging.',
      symptoms: 'Swelling and stiffness in knee'
    });

    console.log('✅ Appointment Service seeded with doctor schedules and sample appointments.');

    // -----------------------------------------------------------------
    // 3. QUEUE & TOKEN SERVICE (hospital_queue_db)
    // -----------------------------------------------------------------
    console.log('\n[3/8] 🔢 Seeding Queue & Token Service (hospital_queue_db)...');
    await queueDb.sequelize.sync({ force: true });

    await queueDb.QueueToken.create({
      tokenNumber: 1,
      tokenCode: `OPD-DOC-${createdDoctors[0].profile.id}-001`,
      appointmentId: apt1.id,
      patientId: createdPatients[0].profile.id,
      doctorId: createdDoctors[0].profile.id,
      tokenDate: today,
      queueDate: today,
      status: 'waiting',
      estimatedTime: '09:00 AM'
    });

    await queueDb.QueueToken.create({
      tokenNumber: 2,
      tokenCode: `OPD-DOC-${createdDoctors[0].profile.id}-002`,
      appointmentId: apt2.id,
      patientId: createdPatients[1].profile.id,
      doctorId: createdDoctors[0].profile.id,
      tokenDate: today,
      queueDate: today,
      status: 'serving',
      estimatedTime: '09:20 AM'
    });

    await queueDb.QueueToken.create({
      tokenNumber: 1,
      tokenCode: `OPD-DOC-${createdDoctors[1].profile.id}-001`,
      appointmentId: apt3.id,
      patientId: createdPatients[2].profile.id,
      doctorId: createdDoctors[1].profile.id,
      tokenDate: today,
      queueDate: today,
      status: 'waiting',
      estimatedTime: '10:00 AM'
    });

    console.log('✅ Queue Service seeded with active OPD tokens for today.');

    // -----------------------------------------------------------------
    // 4. PATIENT & EMR SERVICE (hospital_emr_db)
    // -----------------------------------------------------------------
    console.log('\n[4/8] 📋 Seeding Patient & EMR Service (hospital_emr_db)...');
    await emrDb.sequelize.sync({ force: true });

    const record1 = await emrDb.MedicalRecord.create({
      patientId: createdPatients[0].profile.id,
      doctorId: createdDoctors[0].profile.id,
      appointmentId: apt1.id,
      visitDate: today,
      symptoms: 'Mild chest discomfort after strenuous exercise. Normal resting pulse.',
      diagnosis: 'Early Stage 1 Essential Hypertension with sinus rhythm',
      clinicalNotes: 'Patient advised to reduce sodium intake, perform 30 min daily walking, and monitor BP morning and evening.',
      bloodPressure: '135/88',
      heartRate: 74,
      temperature: 98.4,
      weight: 72.0,
      doctorNotes: 'Advised low sodium diet, Telmisartan 40mg daily, follow-up after 4 weeks.'
    });

    const pres1 = await emrDb.Prescription.create({
      prescriptionCode: 'RX-2026-0001',
      medicalRecordId: record1.id,
      appointmentId: apt1.id,
      patientId: createdPatients[0].profile.id,
      doctorId: createdDoctors[0].profile.id,
      status: 'prescribed',
      generalAdvice: 'Take Telmisartan after breakfast every morning with water.'
    });

    await emrDb.PrescriptionItem.create({
      prescriptionId: pres1.id,
      medicineName: 'Telmisartan 40mg',
      dosage: '40mg',
      frequency: 'Once Daily (OD)',
      durationDays: 30,
      quantity: 30,
      instructions: 'Take in morning after food'
    });

    await emrDb.PrescriptionItem.create({
      prescriptionId: pres1.id,
      medicineName: 'Atorvastatin 10mg',
      dosage: '10mg',
      frequency: 'Once at night (HS)',
      durationDays: 30,
      quantity: 30,
      instructions: 'Take after dinner'
    });

    console.log('✅ EMR Service seeded with clinical records and electronic prescriptions.');

    // -----------------------------------------------------------------
    // 5. BILLING & INSURANCE SERVICE (hospital_billing_db)
    // -----------------------------------------------------------------
    console.log('\n[5/8] 💳 Seeding Billing & Insurance Service (hospital_billing_db)...');
    await billingDb.sequelize.sync({ force: true });

    const bill1 = await billingDb.Bill.create({
      billNumber: 'INV-2026-0001',
      patientId: createdPatients[0].profile.id,
      appointmentId: apt1.id,
      consultationFee: 800.00,
      medicineFee: 420.00,
      labFee: 600.00,
      otherCharges: 0.00,
      subtotal: 1820.00,
      taxAmount: 0.00,
      discountAmount: 100.00,
      totalAmount: 1720.00,
      paidAmount: 1720.00,
      balanceAmount: 0.00,
      paymentStatus: 'paid',
      paymentMethod: 'upi',
      transactionReference: 'UPI-TXN-884920482',
      billDate: today
    });

    const bill2 = await billingDb.Bill.create({
      billNumber: 'INV-2026-0002',
      patientId: createdPatients[1].profile.id,
      appointmentId: apt2.id,
      consultationFee: 750.00,
      medicineFee: 0.00,
      labFee: 0.00,
      otherCharges: 0.00,
      subtotal: 750.00,
      taxAmount: 0.00,
      discountAmount: 0.00,
      totalAmount: 750.00,
      paidAmount: 0.00,
      balanceAmount: 750.00,
      paymentStatus: 'unpaid',
      paymentMethod: 'cash',
      billDate: today
    });

    await billingDb.InsuranceClaim.create({
      billId: bill1.id,
      claimNumber: 'CLM-2026-0001',
      patientId: createdPatients[0].profile.id,
      insuranceProvider: 'Star Health Allied Insurance',
      policyNumber: 'SH-POL-2024-8849',
      claimAmount: 1720.00,
      approvedAmount: 1500.00,
      status: 'approved',
      settlementDate: today,
      notes: 'Consultation and baseline ECG claim settled under comprehensive outpatient cover.'
    });

    console.log('✅ Billing Service seeded with invoices and insurance claims.');

    // -----------------------------------------------------------------
    // 6. PHARMACY & INVENTORY SERVICE (hospital_pharmacy_db)
    // -----------------------------------------------------------------
    console.log('\n[6/8] 💊 Seeding Pharmacy & Inventory Service (hospital_pharmacy_db)...');
    await pharmacyDb.sequelize.sync({ force: true });

    const medicines = [
      { name: 'Paracetamol 650mg (Dolo)', genericName: 'Paracetamol', category: 'Analgesic', manufacturer: 'Micro Labs', batchNumber: 'ML-2026-P01', stockQuantity: 250, unitPrice: 3.50, reorderLevel: 50, expiryDate: '2027-12-31' },
      { name: 'Telmisartan 40mg', genericName: 'Telmisartan', category: 'Antihypertensive', manufacturer: 'Cipla Ltd', batchNumber: 'CIP-TEL-88', stockQuantity: 180, unitPrice: 12.00, reorderLevel: 40, expiryDate: '2027-08-31' },
      { name: 'Atorvastatin 10mg', genericName: 'Atorvastatin Calcium', category: 'Lipid-lowering', manufacturer: 'Sun Pharma', batchNumber: 'SUN-ATO-44', stockQuantity: 140, unitPrice: 14.50, reorderLevel: 30, expiryDate: '2027-06-30' },
      { name: 'Metformin 500mg', genericName: 'Metformin HCl', category: 'Antidiabetic', manufacturer: 'USV Ltd', batchNumber: 'USV-MET-99', stockQuantity: 300, unitPrice: 4.00, reorderLevel: 50, expiryDate: '2028-01-31' },
      { name: 'Amoxicillin 500mg', genericName: 'Amoxicillin Trihydrate', category: 'Antibiotic', manufacturer: 'Alkem Laboratories', batchNumber: 'ALK-AMX-12', stockQuantity: 90, unitPrice: 18.00, reorderLevel: 25, expiryDate: '2026-11-30' },
      { name: 'Pantoprazole 40mg (Pan-40)', genericName: 'Pantoprazole Sodium', category: 'Antacid / PPI', manufacturer: 'Alkem Laboratories', batchNumber: 'ALK-PAN-05', stockQuantity: 210, unitPrice: 11.00, reorderLevel: 40, expiryDate: '2027-10-31' },
      { name: 'Azithromycin 500mg', genericName: 'Azithromycin', category: 'Antibiotic', manufacturer: 'Cipla Ltd', batchNumber: 'CIP-AZI-22', stockQuantity: 15, unitPrice: 24.00, reorderLevel: 25, expiryDate: '2026-09-30' }, // Low stock!
      { name: 'Cetirizine 10mg', genericName: 'Cetirizine HCl', category: 'Antihistamine', manufacturer: 'Dr. Reddy\'s', batchNumber: 'DRL-CET-31', stockQuantity: 8, unitPrice: 2.50, reorderLevel: 20, expiryDate: '2027-05-31' } // Low stock!
    ];

    for (const med of medicines) {
      const createdMed = await pharmacyDb.Medicine.create(med);
      await pharmacyDb.InventoryTransaction.create({
        medicineId: createdMed.id,
        type: 'purchase',
        quantity: med.stockQuantity,
        previousStock: 0,
        currentStock: med.stockQuantity,
        referenceNote: 'Opening balance stock verification',
        createdByUserId: adminUser.id
      });
    }

    console.log(`✅ Pharmacy Service seeded with ${medicines.length} medications (including 2 low-stock warning triggers).`);

    // -----------------------------------------------------------------
    // 7. LABORATORY SERVICE (hospital_lab_db)
    // -----------------------------------------------------------------
    console.log('\n[7/8] 🔬 Seeding Laboratory Service (hospital_lab_db)...');
    await labDb.sequelize.sync({ force: true });

    const tests = [
      { testCode: 'LAB-CBC', name: 'Complete Blood Count (CBC)', category: 'Hematology', price: 450.00, turnaroundHours: 4, normalRange: 'WBC: 4000-11000/uL, RBC: 4.5-5.5 M/uL, Platelets: 1.5-4.5 L/uL', description: 'Comprehensive panel measuring red blood cells, white blood cells, and platelets.' },
      { testCode: 'LAB-LIPID', name: 'Lipid Profile Comprehensive', category: 'Biochemistry', price: 650.00, turnaroundHours: 6, normalRange: 'Total Chol: <200 mg/dL, HDL: >40 mg/dL, LDL: <100 mg/dL, Triglycerides: <150 mg/dL', description: 'Assesses cardiovascular risk through cholesterol and triglyceride fractions.' },
      { testCode: 'LAB-HBA1C', name: 'HbA1c Glycated Hemoglobin', category: 'Biochemistry', price: 550.00, turnaroundHours: 4, normalRange: '< 5.7% (Normal), 5.7% - 6.4% (Prediabetic), >= 6.5% (Diabetic)', description: 'Gold standard biomarker for 3-month average blood glucose control.' },
      { testCode: 'LAB-LFT', name: 'Liver Function Test (LFT)', category: 'Biochemistry', price: 750.00, turnaroundHours: 6, normalRange: 'SGOT: 5-40 U/L, SGPT: 7-56 U/L, Bilirubin: 0.2-1.2 mg/dL', description: 'Measures bilirubin, alkaline phosphatase, and hepatic transaminases.' },
      { testCode: 'LAB-KFT', name: 'Kidney Function Test (KFT/RFT)', category: 'Biochemistry', price: 600.00, turnaroundHours: 5, normalRange: 'Serum Creatinine: 0.7-1.3 mg/dL, Blood Urea: 15-40 mg/dL', description: 'Evaluates renal clearance, blood urea nitrogen, and serum electrolytes.' }
    ];

    const createdTests = [];
    for (const t of tests) {
      const ct = await labDb.LabTest.create(t);
      createdTests.push(ct);
    }

    await labDb.LabReport.create({
      reportNumber: 'REP-2026-0001',
      labTestId: createdTests[1].id,
      patientId: createdPatients[0].profile.id,
      doctorId: createdDoctors[0].profile.id,
      appointmentId: apt1.id,
      prescribedDate: today,
      resultValue: JSON.stringify({
        totalCholesterol: '185 mg/dL (Desirable)',
        hdl: '48 mg/dL (Normal)',
        ldl: '105 mg/dL (Optimal)',
        triglycerides: '138 mg/dL (Normal)'
      }),
      remarks: 'Normal lipid profile with adequate HDL protection and healthy LDL boundaries.',
      status: 'completed',
      technicianNotes: 'Conducted by Dr. Suresh Rao, MD Pathology'
    });

    await labDb.LabReport.create({
      reportNumber: 'REP-2026-0002',
      labTestId: createdTests[0].id,
      patientId: createdPatients[1].profile.id,
      doctorId: createdDoctors[0].profile.id,
      appointmentId: apt2.id,
      prescribedDate: today,
      status: 'sample_collected',
      technicianNotes: 'Blood sample received by Senior Phlebotomist Anjali'
    });

    console.log('✅ Laboratory Service seeded with test catalog and diagnostic reports.');

    // -----------------------------------------------------------------
    // 8. NOTIFICATION SERVICE (hospital_notification_db)
    // -----------------------------------------------------------------
    console.log('\n[8/8] 🔔 Seeding Notification Service (hospital_notification_db)...');
    await notificationDb.sequelize.sync({ force: true });

    await notificationDb.Notification.create({
      userId: createdPatients[0].user.id,
      title: 'Appointment Confirmed',
      message: `Your appointment with Dr. Ramesh Sharma is confirmed for today at 09:00 AM. Token #1.`,
      eventType: 'appointment_confirmed',
      channel: 'sms',
      isRead: false
    });

    await notificationDb.Notification.create({
      userId: createdDoctors[0].user.id,
      title: 'New Patient Booked',
      message: `Patient Sai Teja has booked a consultation for today at 09:00 AM.`,
      eventType: 'appointment_booked',
      channel: 'in_app',
      isRead: false
    });

    console.log('✅ Notification Service seeded with notifications.');

    console.log('\n===============================================================');
    console.log('🎉 ALL 8 MICROSERVICES SEEDED SUCCESSFULLY WITH CLEAN DATA!');
    console.log('===============================================================');
    console.log('Credentials Summary:');
    console.log('  👑 Admin:   admin@hospital.com        / Admin@123');
    console.log('  🩺 Doctor:  dr.sharma@hospital.com    / Doctor@123');
    console.log('  🧑 Patient: patient.sai@hospital.com  / Patient@123');
    console.log('===============================================================\n');

    process.exit(0);
  } catch (error) {
    console.error('❌ Error during microservices seeding:', error);
    process.exit(1);
  }
}

seedAllMicroservices();
