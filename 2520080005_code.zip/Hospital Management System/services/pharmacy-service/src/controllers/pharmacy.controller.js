const { Medicine, InventoryTransaction, sequelize } = require('../models');
const { Op } = require('sequelize');

// 1. Get Medicines Catalog
exports.getMedicines = async (req, res, next) => {
  try {
    const { lowStock, category, search } = req.query;
    const where = {};

    if (lowStock === 'true') {
      where.stockQuantity = { [Op.lte]: sequelize.col('reorderLevel') };
    }

    if (category) {
      where.category = category;
    }

    const medicines = await Medicine.findAll({
      where,
      order: [['name', 'ASC']]
    });

    let filtered = medicines;
    if (search) {
      const q = search.toLowerCase();
      filtered = medicines.filter(m =>
        m.name.toLowerCase().includes(q) ||
        m.category.toLowerCase().includes(q) ||
        (m.genericName && m.genericName.toLowerCase().includes(q))
      );
    }

    return res.json({
      success: true,
      data: filtered
    });
  } catch (error) {
    next(error);
  }
};

// 2. Add New Medicine (Admin Only)
exports.addMedicine = async (req, res, next) => {
  try {
    const {
      name,
      genericName,
      category,
      dosageForm,
      strength,
      manufacturer,
      unitPrice,
      stockQuantity,
      reorderLevel,
      expiryDate,
      batchNumber,
      isPrescriptionRequired
    } = req.body;

    const initialStock = stockQuantity ? parseInt(stockQuantity, 10) : 0;

    const medicine = await Medicine.create({
      name,
      genericName,
      category: category || 'General',
      dosageForm: dosageForm || 'Tablet',
      strength,
      manufacturer,
      unitPrice: unitPrice || 50.00,
      stockQuantity: initialStock,
      reorderLevel: reorderLevel || 20,
      expiryDate: expiryDate || '2028-12-31',
      batchNumber: batchNumber || `BATCH-${Math.floor(1000 + Math.random() * 9000)}`,
      isPrescriptionRequired: isPrescriptionRequired !== undefined ? isPrescriptionRequired : true
    });

    if (initialStock > 0) {
      await InventoryTransaction.create({
        medicineId: medicine.id,
        type: 'purchase',
        quantity: initialStock,
        previousStock: 0,
        currentStock: initialStock,
        referenceNote: 'Initial stock intake on registration',
        createdByUserId: req.user?.id || null
      });
    }

    return res.status(201).json({
      success: true,
      message: `Medicine ${medicine.name} added to pharmacy inventory.`,
      data: medicine
    });
  } catch (error) {
    next(error);
  }
};

// 3. Restock Medicine
exports.restockMedicine = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { quantity, referenceNote } = req.body;

    const addQty = parseInt(quantity, 10);
    if (isNaN(addQty) || addQty <= 0) {
      return res.status(400).json({ success: false, message: 'Valid positive quantity is required.' });
    }

    const medicine = await Medicine.findByPk(id);
    if (!medicine) {
      return res.status(404).json({ success: false, message: 'Medicine not found.' });
    }

    const prev = medicine.stockQuantity;
    const curr = prev + addQty;

    await medicine.update({ stockQuantity: curr });

    const tx = await InventoryTransaction.create({
      medicineId: medicine.id,
      type: 'purchase',
      quantity: addQty,
      previousStock: prev,
      currentStock: curr,
      referenceNote: referenceNote || 'Manual warehouse restocking',
      createdByUserId: req.user?.id || null
    });

    return res.json({
      success: true,
      message: `Stock updated. ${addQty} units added to ${medicine.name}. Current stock: ${curr}.`,
      data: {
        medicine,
        transaction: tx
      }
    });
  } catch (error) {
    next(error);
  }
};

// 4. Get Inventory Transactions History
exports.getInventoryTransactions = async (req, res, next) => {
  try {
    const { limit = 50 } = req.query;
    const transactions = await InventoryTransaction.findAll({
      include: [{ model: Medicine, as: 'medicine', attributes: ['id', 'name', 'category'] }],
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit, 10)
    });

    return res.json({
      success: true,
      data: transactions
    });
  } catch (error) {
    next(error);
  }
};
