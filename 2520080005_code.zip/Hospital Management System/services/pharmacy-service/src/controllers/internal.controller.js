const { Medicine, InventoryTransaction, sequelize } = require('../models');
const { Op } = require('sequelize');

// Inter-Service: Deduct stock when prescription is dispensed
exports.deductStockInternal = async (req, res, next) => {
  try {
    const { medicineId, quantity, referenceNote, userId } = req.body;
    const deductQty = parseInt(quantity, 10);

    const medicine = await Medicine.findByPk(medicineId);
    if (!medicine) {
      return res.status(404).json({ success: false, message: 'Medicine not found.' });
    }

    const prev = medicine.stockQuantity;
    const curr = Math.max(0, prev - deductQty);

    await medicine.update({ stockQuantity: curr });

    const tx = await InventoryTransaction.create({
      medicineId: medicine.id,
      type: 'dispensed',
      quantity: deductQty,
      previousStock: prev,
      currentStock: curr,
      referenceNote: referenceNote || 'Dispensed for prescription',
      createdByUserId: userId || null
    });

    return res.json({
      success: true,
      message: 'Stock deducted successfully.',
      data: { medicine, transaction: tx }
    });
  } catch (error) {
    next(error);
  }
};

// Inter-Service: Low Stock Count for Dashboard
exports.getStatsInternal = async (req, res, next) => {
  try {
    const lowStockCount = await Medicine.count({
      where: {
        stockQuantity: { [Op.lte]: sequelize.col('reorderLevel') }
      }
    });

    const totalMedicines = await Medicine.count();

    return res.json({
      success: true,
      data: { lowStockCount, totalMedicines }
    });
  } catch (error) {
    next(error);
  }
};
