const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const Medicine = sequelize.define('Medicine', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  genericName: {
    type: DataTypes.STRING(150),
    allowNull: true
  },
  category: {
    type: DataTypes.STRING(80),
    allowNull: false
  },
  dosageForm: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  strength: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  manufacturer: {
    type: DataTypes.STRING(150),
    allowNull: true
  },
  unitPrice: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  stockQuantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  reorderLevel: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 20
  },
  expiryDate: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  batchNumber: {
    type: DataTypes.STRING(60),
    allowNull: false
  },
  isPrescriptionRequired: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
}, {
  tableName: 'medicines',
  indexes: [
    { fields: ['name'] },
    { fields: ['category'] },
    { fields: ['stockQuantity'] }
  ]
});

module.exports = Medicine;
