const { sequelize } = require('../config/db.config');
const Medicine = require('./Medicine');
const InventoryTransaction = require('./InventoryTransaction');

Medicine.hasMany(InventoryTransaction, { foreignKey: 'medicineId', as: 'transactions', onDelete: 'CASCADE' });
InventoryTransaction.belongsTo(Medicine, { foreignKey: 'medicineId', as: 'medicine' });

module.exports = {
  sequelize,
  Medicine,
  InventoryTransaction
};
