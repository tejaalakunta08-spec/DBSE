const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const InventoryTransaction = sequelize.define('InventoryTransaction', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  medicineId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  type: {
    type: DataTypes.ENUM('purchase', 'dispensed', 'adjustment', 'expired'),
    allowNull: false
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  previousStock: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  currentStock: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  referenceNote: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  createdByUserId: {
    type: DataTypes.INTEGER,
    allowNull: true
  }
}, {
  tableName: 'inventory_transactions',
  indexes: [
    { fields: ['medicineId'] },
    { fields: ['type'] }
  ]
});

module.exports = InventoryTransaction;
