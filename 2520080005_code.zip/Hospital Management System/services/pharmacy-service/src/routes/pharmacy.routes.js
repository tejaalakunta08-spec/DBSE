const express = require('express');
const router = express.Router();
const pharmacyController = require('../controllers/pharmacy.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

// Public/Doctor/Patient: View medicines catalog
router.get('/medicines', pharmacyController.getMedicines);

// Admin-only management
router.post('/medicines', verifyToken, requireRoles('admin'), pharmacyController.addMedicine);
router.post('/medicines/:id/restock', verifyToken, requireRoles('admin'), pharmacyController.restockMedicine);
router.get('/inventory', verifyToken, requireRoles('admin'), pharmacyController.getInventoryTransactions);

module.exports = router;
