const express = require('express');
const router = express.Router();
const internalController = require('../controllers/internal.controller');

router.post('/medicines/deduct-stock', internalController.deductStockInternal);
router.get('/stats', internalController.getStatsInternal);

module.exports = router;
