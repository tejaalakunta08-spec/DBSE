const express = require('express');
const router = express.Router();

const pharmacyRoutes = require('./pharmacy.routes');
const internalRoutes = require('./internal.routes');

router.use('/pharmacy', pharmacyRoutes);
router.use('/internal', internalRoutes);

module.exports = router;
