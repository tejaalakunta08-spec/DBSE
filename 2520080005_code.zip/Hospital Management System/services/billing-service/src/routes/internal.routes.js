const express = require('express');
const router = express.Router();
const internalController = require('../controllers/internal.controller');

router.post('/create', internalController.createBillInternal);
router.post('/billing/create', internalController.createBillInternal);
router.get('/stats', internalController.getStatsInternal);

module.exports = router;
