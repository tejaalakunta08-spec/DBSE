const express = require('express');
const router = express.Router();

const billingRoutes = require('./billing.routes');
const internalRoutes = require('./internal.routes');

router.use('/billing', billingRoutes);
router.use('/internal', internalRoutes);

module.exports = router;
