const express = require('express');
const router = express.Router();
const billingController = require('../controllers/billing.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

router.use(verifyToken);

router.get('/', billingController.getBills);
router.post('/:id/pay', billingController.payBill);
router.post('/claim', billingController.submitClaim);
router.put('/claim/:id/adjudicate', requireRoles('admin'), billingController.adjudicateClaim);

module.exports = router;
