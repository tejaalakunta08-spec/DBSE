require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { sequelize, ensureDatabaseExists } = require('./config/db.config');
const routes = require('./routes');
const { errorHandler, notFoundHandler } = require('./middleware/error.middleware');

const app = express();
const PORT = process.env.PORT || 5005;

app.use(cors({ origin: '*', credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('dev'));
}

// Health check
app.get('/health', (req, res) => {
  res.json({
    service: 'Billing & Insurance Service',
    status: 'UP',
    port: PORT,
    database: 'hospital_billing_db',
    timestamp: new Date()
  });
});

app.use('/api', routes);
app.use('/', routes);

app.use(notFoundHandler);
app.use(errorHandler);

async function startServer() {
  try {
    await ensureDatabaseExists();
    await sequelize.authenticate();
    console.log('[Billing Service] Connected to MySQL database: hospital_billing_db');
    await sequelize.sync({ alter: false });
    console.log('[Billing Service] Models synchronized.');

    app.listen(PORT, '0.0.0.0', () => {
      console.log(`💳 [Billing Service] Running on http://127.0.0.1:${PORT}`);
    });
  } catch (error) {
    console.error('❌ [Billing Service] Failed to start:', error.message);
  }
}

if (require.main === module) {
  startServer();
}

module.exports = app;
