const { sequelize } = require('../config/db.config');
const Bill = require('./Bill');
const InsuranceClaim = require('./InsuranceClaim');

Bill.hasOne(InsuranceClaim, { foreignKey: 'billId', as: 'claim', onDelete: 'CASCADE' });
InsuranceClaim.belongsTo(Bill, { foreignKey: 'billId', as: 'bill' });

module.exports = {
  sequelize,
  Bill,
  InsuranceClaim
};
