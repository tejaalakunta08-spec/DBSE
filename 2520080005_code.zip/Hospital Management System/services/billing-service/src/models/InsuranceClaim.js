const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const InsuranceClaim = sequelize.define('InsuranceClaim', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  claimNumber: {
    type: DataTypes.STRING(30),
    allowNull: false,
    unique: true
  },
  billId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    unique: true
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  insuranceProvider: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  policyNumber: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  claimAmount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  approvedAmount: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00
  },
  status: {
    type: DataTypes.ENUM('submitted', 'in_review', 'approved', 'rejected'),
    allowNull: false,
    defaultValue: 'submitted'
  },
  rejectionReason: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  submittedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  adjudicatedAt: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  tableName: 'insurance_claims'
});

module.exports = InsuranceClaim;
