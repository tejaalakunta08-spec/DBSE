const { Bill, InsuranceClaim } = require('../models');
const authClient = require('../services/authClient.service');
const notificationClient = require('../services/notificationClient.service');

// 1. Get Bills (Patient sees own bills, Admin sees all bills)
exports.getBills = async (req, res, next) => {
  try {
    const where = {};
    if (req.user.role === 'patient') {
      const patientId = req.user.patientProfile?.id;
      if (patientId) where.patientId = patientId;
    }

    const bills = await Bill.findAll({
      where,
      include: [{ model: InsuranceClaim, as: 'claim' }],
      order: [['billDate', 'DESC'], ['id', 'DESC']]
    });

    let totalRevenue = 0;
    let pendingDues = 0;

    // Enrich with Patient details from Auth Service
    const enriched = await Promise.all(
      bills.map(async (b) => {
        totalRevenue += parseFloat(b.paidAmount) || 0;
        pendingDues += parseFloat(b.balanceAmount) || 0;
        const patient = await authClient.getPatientById(b.patientId);
        return {
          ...b.toJSON(),
          patient: patient ? { id: patient.id, patientCode: patient.patientCode, user: { name: patient.name, phone: patient.phone, email: patient.email } } : null
        };
      })
    );

    return res.json({
      success: true,
      data: {
        totalRevenue: totalRevenue.toFixed(2),
        pendingDues: pendingDues.toFixed(2),
        count: enriched.length,
        bills: enriched
      }
    });
  } catch (error) {
    next(error);
  }
};

// 2. Pay Bill (Cash, Card, UPI, etc.)
exports.payBill = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { paymentMethod, amount } = req.body;

    const bill = await Bill.findByPk(id);
    if (!bill) {
      return res.status(404).json({ success: false, message: 'Bill not found.' });
    }

    if (bill.paymentStatus === 'paid') {
      return res.status(400).json({ success: false, message: 'Bill is already fully paid.' });
    }

    const payAmount = amount ? parseFloat(amount) : parseFloat(bill.balanceAmount || bill.totalAmount);
    const newPaidAmount = parseFloat(bill.paidAmount || 0) + payAmount;
    const newBalance = Math.max(0, parseFloat(bill.totalAmount) - newPaidAmount);
    const isFull = newBalance === 0;

    const paymentRef = `PAY-${Date.now().toString().slice(-8)}`;

    await bill.update({
      paidAmount: newPaidAmount,
      balanceAmount: newBalance,
      paymentStatus: isFull ? 'paid' : 'partial',
      paymentMethod: paymentMethod === 'upi' ? 'upi' : (paymentMethod === 'card' ? 'credit_card' : (paymentMethod || 'cash')),
      transactionReference: paymentRef
    });

    // Inter-Service Notification: Send Payment Receipt Alert
    const patientData = await authClient.getPatientById(bill.patientId);
    if (patientData?.phone) {
      await notificationClient.sendNotification({
        userId: patientData.userId,
        phone: patientData.phone,
        title: 'Payment Received',
        message: `Payment of ₹${payAmount.toFixed(2)} received for Bill #${bill.billNumber}. Ref: ${paymentRef}. Thank you!`,
        channel: 'both',
        eventType: 'payment_received'
      });
    }

    return res.json({
      success: true,
      message: `Payment of ₹${payAmount.toFixed(2)} processed successfully.`,
      data: bill
    });
  } catch (error) {
    next(error);
  }
};

// 3. Submit Insurance Claim
exports.submitClaim = async (req, res, next) => {
  try {
    const { billId, insuranceProvider, policyNumber, claimAmount } = req.body;

    const bill = await Bill.findByPk(billId);
    if (!bill) {
      return res.status(404).json({ success: false, message: 'Bill not found.' });
    }

    const claimNumber = `CLM-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;

    const claim = await InsuranceClaim.create({
      claimNumber,
      billId: bill.id,
      patientId: bill.patientId,
      insuranceProvider,
      policyNumber,
      claimAmount: claimAmount || bill.balanceAmount || bill.totalAmount,
      status: 'submitted',
      submittedAt: new Date()
    });

    return res.status(201).json({
      success: true,
      message: `Insurance claim #${claimNumber} submitted for adjudication.`,
      data: claim
    });
  } catch (error) {
    next(error);
  }
};

// 4. Adjudicate Insurance Claim (Admin Only)
exports.adjudicateClaim = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, approvedAmount, rejectionReason } = req.body;

    const claim = await InsuranceClaim.findByPk(id, {
      include: [{ model: Bill, as: 'bill' }]
    });

    if (!claim) {
      return res.status(404).json({ success: false, message: 'Insurance claim not found.' });
    }

    const updates = {
      status,
      adjudicatedAt: new Date()
    };

    if (status === 'approved') {
      const approved = approvedAmount ? parseFloat(approvedAmount) : parseFloat(claim.claimAmount);
      updates.approvedAmount = approved;

      // Adjust bill
      if (claim.bill) {
        const newPaid = parseFloat(claim.bill.paidAmount || 0) + approved;
        const newBalance = Math.max(0, parseFloat(claim.bill.totalAmount) - newPaid);
        await claim.bill.update({
          paidAmount: newPaid,
          balanceAmount: newBalance,
          paymentStatus: newBalance === 0 ? 'paid' : 'partial',
          paymentMethod: 'insurance',
          transactionReference: `INS-CLAIM-${claim.claimNumber}`
        });
      }
    } else if (status === 'rejected') {
      updates.rejectionReason = rejectionReason || 'Claim not covered under policy terms.';
    }

    await claim.update(updates);

    // Inter-Service Notification: Send claim decision SMS
    const patientData = await authClient.getPatientById(claim.patientId);
    if (patientData?.phone) {
      await notificationClient.sendNotification({
        userId: patientData.userId,
        phone: patientData.phone,
        title: `Insurance Claim ${status.toUpperCase()}`,
        message: status === 'approved'
          ? `Your insurance claim #${claim.claimNumber} was approved for ₹${parseFloat(updates.approvedAmount || 0).toFixed(2)}.`
          : `Your insurance claim #${claim.claimNumber} was rejected: ${updates.rejectionReason}`,
        channel: 'both',
        eventType: 'claim_adjudicated'
      });
    }

    return res.json({
      success: true,
      message: `Insurance claim #${claim.claimNumber} has been ${status}.`,
      data: claim
    });
  } catch (error) {
    next(error);
  }
};
