const { Bill, InsuranceClaim } = require('../models');

// Inter-Service: Create Consultation Bill (Called by Appointment Service)
exports.createBillInternal = async (req, res, next) => {
  try {
    const { patientId, appointmentId, consultationFee, medicineCharges, labCharges, billDate } = req.body;

    const fee = consultationFee ? parseFloat(consultationFee) : 500.00;
    const med = medicineCharges ? parseFloat(medicineCharges) : 0.00;
    const lab = labCharges ? parseFloat(labCharges) : 0.00;
    const total = fee + med + lab;

    const billNumber = `INV-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;

    const bill = await Bill.create({
      billNumber,
      patientId: parseInt(patientId, 10),
      appointmentId: appointmentId ? parseInt(appointmentId, 10) : null,
      consultationFee: fee,
      medicineFee: med,
      labFee: lab,
      otherCharges: 0.00,
      subtotal: total,
      taxAmount: 0.00,
      discountAmount: 0.00,
      totalAmount: total,
      paidAmount: 0.00,
      balanceAmount: total,
      paymentStatus: 'unpaid',
      paymentMethod: 'cash',
      billDate: billDate || new Date().toISOString().split('T')[0]
    });

    return res.status(201).json({
      success: true,
      data: bill
    });
  } catch (error) {
    next(error);
  }
};

// Inter-Service: Get Revenue & Stats for Dashboard
exports.getStatsInternal = async (req, res, next) => {
  try {
    const totalRevenue = await Bill.sum('paidAmount');
    const pendingClaims = await InsuranceClaim.count({ where: { status: 'submitted' } });

    return res.json({
      success: true,
      data: {
        totalRevenue: (totalRevenue || 0).toFixed(2),
        pendingClaims
      }
    });
  } catch (error) {
    next(error);
  }
};
