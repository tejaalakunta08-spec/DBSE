const { authServiceUrl } = require('../config/services.config');

const cache = new Map();

exports.getPatientById = async (patientId) => {
  const cacheKey = `patient_${patientId}`;
  if (cache.has(cacheKey)) return cache.get(cacheKey);

  try {
    const res = await fetch(`${authServiceUrl}/internal/patients/${patientId}`);
    if (!res.ok) return null;
    const json = await res.json();
    if (json.success) {
      cache.set(cacheKey, json.data);
      setTimeout(() => cache.delete(cacheKey), 30000);
      return json.data;
    }
    return null;
  } catch (error) {
    console.warn(`[Billing -> Auth Service] Error fetching patient ${patientId}:`, error.message);
    return null;
  }
};
