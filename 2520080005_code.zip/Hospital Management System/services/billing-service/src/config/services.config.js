require('dotenv').config();

module.exports = {
  authServiceUrl: process.env.AUTH_SERVICE_URL || 'http://127.0.0.1:5001',
  notificationServiceUrl: process.env.NOTIFICATION_SERVICE_URL || 'http://127.0.0.1:5008'
};
