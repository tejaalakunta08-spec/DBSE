const { MedicalRecord, Prescription, PrescriptionItem } = require('../models');
const authClient = require('../services/authClient.service');
const pharmacyClient = require('../services/pharmacyClient.service');
const notificationClient = require('../services/notificationClient.service');

// 1. Create New Consultation Medical Record + Prescription
exports.createRecord = async (req, res, next) => {
  try {
    const {
      patientId,
      appointmentId,
      symptoms,
      diagnosis,
      clinicalNotes,
      bloodPressure,
      heartRate,
      temperature,
      weightKg,
      medicines,
      prescriptionInstructions
    } = req.body;

    let doctorId = req.body.doctorId;
    if (req.user.role === 'doctor' && req.user.doctorProfile?.id) {
      doctorId = req.user.doctorProfile.id;
    }

    if (!patientId || !diagnosis) {
      return res.status(400).json({ success: false, message: 'patientId and diagnosis are required.' });
    }

    const today = new Date().toISOString().split('T')[0];

    const record = await MedicalRecord.create({
      patientId: parseInt(patientId, 10),
      doctorId: doctorId ? parseInt(doctorId, 10) : 1,
      appointmentId: appointmentId ? parseInt(appointmentId, 10) : null,
      visitDate: today,
      symptoms,
      diagnosis,
      clinicalNotes,
      bloodPressure,
      heartRate,
      temperature,
      weightKg
    });

    let prescription = null;
    if (Array.isArray(medicines) && medicines.length > 0) {
      const rxNumber = `RX-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;
      prescription = await Prescription.create({
        prescriptionNumber: rxNumber,
        medicalRecordId: record.id,
        patientId: record.patientId,
        doctorId: record.doctorId,
        issueDate: today,
        instructions: prescriptionInstructions || 'Take medications as directed.'
      });

      for (const med of medicines) {
        await PrescriptionItem.create({
          prescriptionId: prescription.id,
          medicineId: med.medicineId || null,
          medicineName: med.medicineName || med.name || 'Medicine',
          dosage: med.dosage || '1 tablet',
          frequency: med.frequency || 'Once daily',
          durationDays: med.durationDays || 5,
          quantity: med.quantity || 10,
          instructions: med.instructions || 'After meals'
        });

        // Inter-Service: Deduct stock in Pharmacy Service
        if (med.medicineId) {
          await pharmacyClient.deductStock(
            med.medicineId,
            med.quantity || 10,
            `Dispensed for Prescription #${rxNumber}`
          );
        }
      }
    }

    // Inter-Service: Send alert to Patient
    const patientData = await authClient.getPatientById(patientId);
    if (patientData?.phone) {
      await notificationClient.sendNotification({
        userId: patientData.userId,
        phone: patientData.phone,
        title: 'New Medical Consultation Recorded',
        message: `Your medical consultation for ${diagnosis} has been completed. View diagnosis & prescription in Medical Records.`,
        channel: 'both',
        eventType: 'prescription_issued'
      });
    }

    const fullRecord = await MedicalRecord.findByPk(record.id, {
      include: [
        {
          model: Prescription,
          as: 'prescription',
          include: [{ model: PrescriptionItem, as: 'items' }]
        }
      ]
    });

    return res.status(201).json({
      success: true,
      message: 'Medical consultation & prescription recorded successfully.',
      data: fullRecord
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Medical Records for a Patient
exports.getPatientRecords = async (req, res, next) => {
  try {
    const { patientId } = req.params;

    // Security check: Patients can only view their own EMR
    if (req.user.role === 'patient') {
      const myPatientId = req.user.patientProfile?.id;
      if (myPatientId && parseInt(patientId, 10) !== myPatientId) {
        return res.status(403).json({ success: false, message: 'Unauthorized to view other patient medical records.' });
      }
    }

    const records = await MedicalRecord.findAll({
      where: { patientId },
      include: [
        {
          model: Prescription,
          as: 'prescription',
          include: [{ model: PrescriptionItem, as: 'items' }]
        }
      ],
      order: [['visitDate', 'DESC'], ['id', 'DESC']]
    });

    // Enrich with Doctor & Patient info from Auth Service
    const enriched = await Promise.all(
      records.map(async (rec) => {
        const [doctor, patient] = await Promise.all([
          authClient.getDoctorById(rec.doctorId),
          authClient.getPatientById(rec.patientId)
        ]);
        return {
          ...rec.toJSON(),
          doctor: doctor ? { id: doctor.id, department: doctor.department, user: { name: doctor.name } } : null,
          patient: patient ? { id: patient.id, user: { name: patient.name } } : null
        };
      })
    );

    return res.json({
      success: true,
      data: enriched
    });
  } catch (error) {
    next(error);
  }
};

// 3. Get Record by ID
exports.getRecordById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const record = await MedicalRecord.findByPk(id, {
      include: [
        {
          model: Prescription,
          as: 'prescription',
          include: [{ model: PrescriptionItem, as: 'items' }]
        }
      ]
    });

    if (!record) {
      return res.status(404).json({ success: false, message: 'Medical record not found.' });
    }

    if (req.user.role === 'patient') {
      const myPatientId = req.user.patientProfile?.id;
      if (myPatientId && record.patientId !== myPatientId) {
        return res.status(403).json({ success: false, message: 'Unauthorized to view this record.' });
      }
    }

    const [doctor, patient] = await Promise.all([
      authClient.getDoctorById(record.doctorId),
      authClient.getPatientById(record.patientId)
    ]);

    return res.json({
      success: true,
      data: {
        ...record.toJSON(),
        doctor: doctor ? { id: doctor.id, department: doctor.department, user: { name: doctor.name } } : null,
        patient: patient ? { id: patient.id, user: { name: patient.name } } : null
      }
    });
  } catch (error) {
    next(error);
  }
};

// 4. Get Current Patient's Medical Records
exports.getMyRecords = async (req, res, next) => {
  try {
    let patientId = req.user.patientProfile?.id || (req.headers['x-patient-id'] ? parseInt(req.headers['x-patient-id'], 10) : null);
    if (!patientId && req.user.id) {
      const userProfile = await authClient.getUserById(req.user.id);
      patientId = userProfile?.patientProfile?.id;
    }
    if (!patientId) {
      return res.status(400).json({ success: false, message: 'Patient profile not found.' });
    }
    req.params.patientId = patientId;
    return exports.getPatientRecords(req, res, next);
  } catch (error) {
    next(error);
  }
};
