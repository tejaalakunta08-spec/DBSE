const { MedicalRecord } = require('../models');

// Inter-Service: Get Patient Records Count
exports.getStatsInternal = async (req, res, next) => {
  try {
    const totalRecords = await MedicalRecord.count();
    return res.json({ success: true, data: { totalRecords } });
  } catch (error) {
    next(error);
  }
};
