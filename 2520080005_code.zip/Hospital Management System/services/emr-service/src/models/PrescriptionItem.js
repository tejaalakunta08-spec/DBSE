const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const PrescriptionItem = sequelize.define('PrescriptionItem', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  prescriptionId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  medicineId: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  medicineName: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  dosage: {
    type: DataTypes.STRING(80),
    allowNull: false
  },
  frequency: {
    type: DataTypes.STRING(80),
    allowNull: false
  },
  durationDays: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 5
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 10
  },
  instructions: {
    type: DataTypes.STRING(255),
    allowNull: true
  }
}, {
  tableName: 'prescription_items'
});

module.exports = PrescriptionItem;
