const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const MedicalRecord = sequelize.define('MedicalRecord', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  appointmentId: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  visitDate: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  symptoms: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  diagnosis: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  bloodPressure: {
    type: DataTypes.STRING(20),
    allowNull: true
  },
  heartRate: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  temperature: {
    type: DataTypes.DECIMAL(4, 1),
    allowNull: true
  },
  weight: {
    type: DataTypes.DECIMAL(5, 2),
    allowNull: true
  },
  doctorNotes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  clinicalNotes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  followUpDate: {
    type: DataTypes.DATEONLY,
    allowNull: true
  }
}, {
  tableName: 'medical_records',
  indexes: [
    { fields: ['patientId'] },
    { fields: ['doctorId'] },
    { fields: ['visitDate'] }
  ]
});

module.exports = MedicalRecord;
