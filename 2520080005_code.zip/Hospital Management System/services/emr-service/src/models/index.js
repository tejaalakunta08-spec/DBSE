const { sequelize } = require('../config/db.config');
const MedicalRecord = require('./MedicalRecord');
const Prescription = require('./Prescription');
const PrescriptionItem = require('./PrescriptionItem');

// Associations within EMR Database
MedicalRecord.hasOne(Prescription, { foreignKey: 'medicalRecordId', as: 'prescription', onDelete: 'CASCADE' });
Prescription.belongsTo(MedicalRecord, { foreignKey: 'medicalRecordId', as: 'medicalRecord' });

Prescription.hasMany(PrescriptionItem, { foreignKey: 'prescriptionId', as: 'items', onDelete: 'CASCADE' });
PrescriptionItem.belongsTo(Prescription, { foreignKey: 'prescriptionId', as: 'prescription' });

module.exports = {
  sequelize,
  MedicalRecord,
  Prescription,
  PrescriptionItem
};
