const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const Prescription = sequelize.define('Prescription', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  prescriptionCode: {
    type: DataTypes.STRING(40),
    allowNull: false,
    unique: true
  },
  medicalRecordId: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  appointmentId: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('prescribed', 'dispensed', 'cancelled'),
    allowNull: false,
    defaultValue: 'prescribed'
  },
  generalAdvice: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'prescriptions',
  indexes: [
    { fields: ['patientId'] },
    { fields: ['doctorId'] }
  ]
});

module.exports = Prescription;
