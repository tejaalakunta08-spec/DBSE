const { pharmacyServiceUrl } = require('../config/services.config');

exports.deductStock = async (medicineId, quantity, referenceNote) => {
  try {
    const res = await fetch(`${pharmacyServiceUrl}/internal/medicines/deduct-stock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ medicineId, quantity, referenceNote })
    });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data || null;
  } catch (error) {
    console.warn(`[EMR -> Pharmacy Service] Error deducting stock for medicine ${medicineId}:`, error.message);
    return null;
  }
};
