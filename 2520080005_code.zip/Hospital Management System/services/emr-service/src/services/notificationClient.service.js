const { notificationServiceUrl } = require('../config/services.config');

exports.sendNotification = async (notificationData) => {
  try {
    const res = await fetch(`${notificationServiceUrl}/internal/notifications/send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(notificationData)
    });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data || null;
  } catch (error) {
    console.warn('[EMR -> Notification Service] Error sending notification:', error.message);
    return null;
  }
};
