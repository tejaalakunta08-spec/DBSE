const express = require('express');
const router = express.Router();
const medicalRecordController = require('../controllers/medicalRecord.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

router.use(verifyToken);

router.post('/', requireRoles('doctor', 'admin'), medicalRecordController.createRecord);
router.get('/', medicalRecordController.getMyRecords);
router.get('/my', medicalRecordController.getMyRecords);
router.get('/patient/:patientId', medicalRecordController.getPatientRecords);
router.get('/:id', medicalRecordController.getRecordById);

module.exports = router;
