const express = require('express');
const router = express.Router();

const recordRoutes = require('./medicalRecord.routes');
const internalRoutes = require('./internal.routes');

router.use('/records', recordRoutes);
router.use('/internal', internalRoutes);

module.exports = router;
