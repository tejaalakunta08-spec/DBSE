const { Appointment } = require('../models');
const authClient = require('../services/authClient.service');

// Inter-Service: Get Appointment Details by ID
exports.getAppointmentById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const appointment = await Appointment.findByPk(id);
    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found.' });
    }
    return res.json({ success: true, data: appointment });
  } catch (error) {
    next(error);
  }
};

// Inter-Service: Get Stats for Executive Dashboard
exports.getStatsInternal = async (req, res, next) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const todayAppointmentsCount = await Appointment.count({
      where: { appointmentDate: today }
    });

    const recent = await Appointment.findAll({
      limit: 6,
      order: [['appointmentDate', 'DESC'], ['id', 'DESC']]
    });

    const recentAppointments = await Promise.all(
      recent.map(async (apt) => {
        const [doctor, patient] = await Promise.all([
          authClient.getDoctorById(apt.doctorId),
          authClient.getPatientById(apt.patientId)
        ]);
        return {
          ...apt.toJSON(),
          doctor: doctor ? { id: doctor.id, department: doctor.department, user: { name: doctor.name } } : null,
          patient: patient ? { id: patient.id, user: { name: patient.name } } : null
        };
      })
    );

    return res.json({
      success: true,
      data: {
        todayAppointmentsCount,
        recentAppointments
      }
    });
  } catch (error) {
    next(error);
  }
};
