const { Appointment, DoctorSchedule } = require('../models');
const { Op } = require('sequelize');
const authClient = require('../services/authClient.service');
const queueClient = require('../services/queueClient.service');
const billingClient = require('../services/billingClient.service');
const notificationClient = require('../services/notificationClient.service');

// 1. Book New Appointment
exports.bookAppointment = async (req, res, next) => {
  try {
    const { doctorId, appointmentDate, timeSlot, type, reason } = req.body;
    let patientId = req.body.patientId;

    // If patient is booking, use their patient profile ID
    if (req.user.role === 'patient') {
      if (!patientId && req.user.patientProfile?.id) {
        patientId = req.user.patientProfile.id;
      }
    }

    if (!doctorId || !appointmentDate || !timeSlot) {
      return res.status(400).json({ success: false, message: 'Doctor, date, and time slot are required.' });
    }

    if (!patientId) {
      return res.status(400).json({ success: false, message: 'Valid patient profile ID is required.' });
    }

    // Check if slot is already booked
    const existing = await Appointment.findOne({
      where: {
        doctorId,
        appointmentDate,
        timeSlot,
        status: { [Op.in]: ['booked', 'confirmed'] }
      }
    });

    if (existing) {
      return res.status(409).json({ success: false, message: 'This time slot has already been booked. Please select another slot.' });
    }

    const appointmentNumber = `APT-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;

    const appointment = await Appointment.create({
      appointmentNumber,
      patientId: parseInt(patientId, 10),
      doctorId: parseInt(doctorId, 10),
      appointmentDate,
      timeSlot,
      type: type || 'regular',
      status: 'confirmed',
      reason
    });

    // Inter-Service 1: Fetch Doctor & Patient details from Auth Service
    const [doctorData, patientData] = await Promise.all([
      authClient.getDoctorById(doctorId),
      authClient.getPatientById(patientId)
    ]);

    // Inter-Service 2: Generate OPD Queue Token in Queue Service
    const today = new Date().toISOString().split('T')[0];
    let queueToken = null;
    if (appointmentDate === today) {
      queueToken = await queueClient.generateToken({
        appointmentId: appointment.id,
        patientId: appointment.patientId,
        doctorId: appointment.doctorId,
        queueDate: appointmentDate,
        estimatedTime: timeSlot
      });
    }

    // Inter-Service 3: Auto-generate Consultation Bill in Billing Service
    const consultationFee = doctorData?.consultationFee ? parseFloat(doctorData.consultationFee) : 500.00;
    await billingClient.createConsultationBill({
      patientId: appointment.patientId,
      appointmentId: appointment.id,
      consultationFee,
      billDate: appointmentDate
    });

    // Inter-Service 4: Send SMS / Notification via Notification Service
    const doctorName = doctorData?.name ? `Dr. ${doctorData.name}` : 'Doctor';
    const patientPhone = patientData?.phone;
    const patientUserId = patientData?.userId || req.user.id;

    if (patientPhone) {
      await notificationClient.sendNotification({
        userId: patientUserId,
        phone: patientPhone,
        title: 'Appointment Confirmed',
        message: `Your appointment with ${doctorName} is confirmed for ${appointmentDate} at ${timeSlot}.${queueToken ? ` OPD Token: #${queueToken.tokenNumber}` : ''}`,
        channel: 'both',
        eventType: 'appointment_confirmed'
      });
    }

    return res.status(201).json({
      success: true,
      message: 'Appointment booked successfully!',
      data: {
        ...appointment.toJSON(),
        doctor: doctorData ? { id: doctorData.id, department: doctorData.department, roomNumber: doctorData.roomNumber, user: { name: doctorData.name, email: doctorData.email } } : null,
        patient: patientData ? { id: patientData.id, patientCode: patientData.patientCode, user: { name: patientData.name, phone: patientData.phone } } : null,
        queueToken
      }
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Appointments (Filtered by Patient / Doctor / Admin)
exports.getAppointments = async (req, res, next) => {
  try {
    const { date, status } = req.query;
    const where = {};

    if (req.user.role === 'patient') {
      const patientId = req.user.patientProfile?.id;
      if (patientId) where.patientId = patientId;
    } else if (req.user.role === 'doctor') {
      const doctorId = req.user.doctorProfile?.id;
      if (doctorId) where.doctorId = doctorId;
    }

    if (date) where.appointmentDate = date;
    if (status) where.status = status;

    const appointments = await Appointment.findAll({
      where,
      order: [['appointmentDate', 'DESC'], ['id', 'DESC']]
    });

    // Enrich with Auth Service data (Doctor & Patient names)
    const enriched = await Promise.all(
      appointments.map(async (apt) => {
        const [doctor, patient] = await Promise.all([
          authClient.getDoctorById(apt.doctorId),
          authClient.getPatientById(apt.patientId)
        ]);

        return {
          ...apt.toJSON(),
          doctor: doctor ? { id: doctor.id, department: doctor.department, roomNumber: doctor.roomNumber, specialization: doctor.specialization, user: { name: doctor.name, email: doctor.email } } : null,
          patient: patient ? { id: patient.id, patientCode: patient.patientCode, user: { name: patient.name, phone: patient.phone } } : null
        };
      })
    );

    return res.json({
      success: true,
      data: enriched
    });
  } catch (error) {
    next(error);
  }
};

// 3. Cancel Appointment
exports.cancelAppointment = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { cancellationReason } = req.body;

    const appointment = await Appointment.findByPk(id);
    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found.' });
    }

    if (req.user.role === 'patient') {
      const patientId = req.user.patientProfile?.id;
      if (patientId && appointment.patientId !== patientId) {
        return res.status(403).json({ success: false, message: 'Unauthorized to cancel this appointment.' });
      }
    }

    await appointment.update({
      status: 'cancelled',
      cancellationReason: cancellationReason || 'Cancelled by user'
    });

    // Inter-Service Notification: Send cancellation alert
    const patientData = await authClient.getPatientById(appointment.patientId);
    if (patientData?.phone) {
      await notificationClient.sendNotification({
        userId: patientData.userId,
        phone: patientData.phone,
        title: 'Appointment Cancelled',
        message: `Your appointment #${appointment.appointmentNumber} has been cancelled.`,
        channel: 'both',
        eventType: 'appointment_cancelled'
      });
    }

    return res.json({
      success: true,
      message: 'Appointment cancelled successfully.',
      data: appointment
    });
  } catch (error) {
    next(error);
  }
};

// 4. Update Appointment Status (Admin / Doctor)
exports.updateAppointmentStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const appointment = await Appointment.findByPk(id);
    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found.' });
    }

    await appointment.update({ status });

    return res.json({
      success: true,
      message: `Appointment status updated to ${status}.`,
      data: appointment
    });
  } catch (error) {
    next(error);
  }
};

// 5. Get Appointment by ID
exports.getAppointmentById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const appointment = await Appointment.findByPk(id);
    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found.' });
    }

    const [doctor, patient] = await Promise.all([
      authClient.getDoctorById(appointment.doctorId),
      authClient.getPatientById(appointment.patientId)
    ]);

    return res.json({
      success: true,
      data: {
        ...appointment.toJSON(),
        doctor: doctor ? { id: doctor.id, department: doctor.department, roomNumber: doctor.roomNumber, specialization: doctor.specialization, user: { name: doctor.name, email: doctor.email } } : null,
        patient: patient ? { id: patient.id, patientCode: patient.patientCode, user: { name: patient.name, phone: patient.phone } } : null
      }
    });
  } catch (error) {
    next(error);
  }
};
