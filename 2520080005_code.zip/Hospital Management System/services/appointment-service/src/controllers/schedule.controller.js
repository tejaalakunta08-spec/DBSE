const { DoctorSchedule, Appointment } = require('../models');
const { Op } = require('sequelize');

function generateTimeSlots(startTimeStr, endTimeStr, durationMinutes = 20) {
  const slots = [];
  const [startHour, startMin] = startTimeStr.split(':').map(Number);
  const [endHour, endMin] = endTimeStr.split(':').map(Number);

  let current = new Date();
  current.setHours(startHour, startMin, 0, 0);

  const end = new Date();
  end.setHours(endHour, endMin, 0, 0);

  while (current < end) {
    const hours = current.getHours();
    const minutes = current.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const formattedHours = hours % 12 || 12;
    const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
    slots.push(`${formattedHours}:${formattedMinutes} ${ampm}`);

    current = new Date(current.getTime() + durationMinutes * 60000);
  }

  return slots;
}

const DAYS_OF_WEEK = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// 1. Get Doctor Available Time Slots for a Given Date
exports.getDoctorSlots = async (req, res, next) => {
  try {
    const { id: doctorId } = req.params;
    const { date } = req.query;

    if (!date) {
      return res.status(400).json({ success: false, message: 'Date parameter is required (YYYY-MM-DD).' });
    }

    const targetDate = new Date(date);
    const dayOfWeek = DAYS_OF_WEEK[targetDate.getDay()];

    const schedule = await DoctorSchedule.findOne({
      where: {
        doctorId,
        dayOfWeek,
        isAvailable: true
      }
    });

    if (!schedule) {
      return res.json({
        success: true,
        data: {
          doctorId: parseInt(doctorId, 10),
          date,
          dayOfWeek,
          isAvailable: false,
          message: `Doctor is not scheduled to consult on ${dayOfWeek}s.`,
          availableSlots: []
        }
      });
    }

    const allSlots = generateTimeSlots(
      schedule.startTime,
      schedule.endTime,
      schedule.slotDurationMinutes || 20
    );

    const bookedAppointments = await Appointment.findAll({
      where: {
        doctorId,
        appointmentDate: date,
        status: { [Op.in]: ['booked', 'confirmed'] }
      },
      attributes: ['timeSlot']
    });

    const bookedSlotsSet = new Set(bookedAppointments.map(a => a.timeSlot));

    const slotObjects = allSlots.map(slot => ({
      timeSlot: slot,
      isBooked: bookedSlotsSet.has(slot)
    }));

    return res.json({
      success: true,
      data: {
        doctorId: parseInt(doctorId, 10),
        date,
        dayOfWeek,
        isAvailable: true,
        startTime: schedule.startTime,
        endTime: schedule.endTime,
        maxPatients: schedule.maxPatients,
        availableSlots: slotObjects
      }
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Doctor Weekly Schedule
exports.getDoctorSchedule = async (req, res, next) => {
  try {
    const { id: doctorId } = req.params;
    const schedules = await DoctorSchedule.findAll({
      where: { doctorId },
      order: [['id', 'ASC']]
    });

    return res.json({
      success: true,
      data: schedules
    });
  } catch (error) {
    next(error);
  }
};

// 3. Update Doctor Schedule
exports.updateSchedule = async (req, res, next) => {
  try {
    const { id: doctorId } = req.params;
    const { schedules } = req.body;

    if (!Array.isArray(schedules)) {
      return res.status(400).json({ success: false, message: 'schedules must be an array.' });
    }

    for (const item of schedules) {
      const { dayOfWeek, startTime, endTime, slotDurationMinutes, maxPatients, isAvailable } = item;
      const existing = await DoctorSchedule.findOne({ where: { doctorId, dayOfWeek } });

      if (existing) {
        await existing.update({
          startTime: startTime || existing.startTime,
          endTime: endTime || existing.endTime,
          slotDurationMinutes: slotDurationMinutes !== undefined ? slotDurationMinutes : existing.slotDurationMinutes,
          maxPatients: maxPatients !== undefined ? maxPatients : existing.maxPatients,
          isAvailable: isAvailable !== undefined ? isAvailable : existing.isAvailable
        });
      } else {
        await DoctorSchedule.create({
          doctorId,
          dayOfWeek,
          startTime: startTime || '09:00:00',
          endTime: endTime || '17:00:00',
          slotDurationMinutes: slotDurationMinutes || 20,
          maxPatients: maxPatients || 25,
          isAvailable: isAvailable !== undefined ? isAvailable : true
        });
      }
    }

    const updated = await DoctorSchedule.findAll({ where: { doctorId } });

    return res.json({
      success: true,
      message: 'Doctor schedule updated successfully.',
      data: updated
    });
  } catch (error) {
    next(error);
  }
};
