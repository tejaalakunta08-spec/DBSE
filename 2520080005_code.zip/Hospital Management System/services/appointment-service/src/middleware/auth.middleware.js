const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'hospital_jwt_super_secret_key_2026_academic_project';

exports.verifyToken = (req, res, next) => {
  try {
    // 1. Check if user information was already injected by API Gateway
    if (req.headers['x-user-id']) {
      req.user = {
        id: parseInt(req.headers['x-user-id'], 10),
        role: req.headers['x-user-role'],
        email: req.headers['x-user-email'],
        name: req.headers['x-user-name'],
        patientProfile: req.headers['x-patient-id'] ? { id: parseInt(req.headers['x-patient-id'], 10) } : null,
        doctorProfile: req.headers['x-doctor-id'] ? { id: parseInt(req.headers['x-doctor-id'], 10) } : null
      };
      return next();
    }

    // 2. Direct Bearer token verification
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'Access denied. Bearer token missing.' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ success: false, message: 'Authentication failed: ' + error.message });
  }
};

exports.requireRoles = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Forbidden: requires one of the following roles: [${roles.join(', ')}]`
      });
    }
    next();
  };
};
