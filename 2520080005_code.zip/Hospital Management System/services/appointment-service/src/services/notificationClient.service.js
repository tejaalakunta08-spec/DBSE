const { notificationServiceUrl } = require('../config/services.config');

exports.sendNotification = async (notificationData) => {
  try {
    const res = await fetch(`${notificationServiceUrl}/internal/send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(notificationData)
    });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data || null;
  } catch (error) {
    console.warn('[Appointment -> Notification Service] SMS notification error:', error.message);
    return null;
  }
};
