const { queueServiceUrl } = require('../config/services.config');

exports.generateToken = async (tokenData) => {
  try {
    const res = await fetch(`${queueServiceUrl}/internal/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(tokenData)
    });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data || null;
  } catch (error) {
    console.warn('[Appointment -> Queue Service] Auto token generation error:', error.message);
    return null;
  }
};
