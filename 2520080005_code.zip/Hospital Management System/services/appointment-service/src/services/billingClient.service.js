const { billingServiceUrl } = require('../config/services.config');

exports.createConsultationBill = async (billData) => {
  try {
    const res = await fetch(`${billingServiceUrl}/internal/create`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(billData)
    });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data || null;
  } catch (error) {
    console.warn('[Appointment -> Billing Service] Auto bill creation error:', error.message);
    return null;
  }
};
