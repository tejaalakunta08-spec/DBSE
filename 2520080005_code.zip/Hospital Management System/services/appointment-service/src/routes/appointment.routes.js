const express = require('express');
const router = express.Router();
const appointmentController = require('../controllers/appointment.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

router.use(verifyToken);

router.post('/', appointmentController.bookAppointment);
router.get('/', appointmentController.getAppointments);
router.get('/my', appointmentController.getAppointments);
router.get('/:id', appointmentController.getAppointmentById);
router.post('/:id/cancel', appointmentController.cancelAppointment);
router.put('/:id/status', requireRoles('admin', 'doctor'), appointmentController.updateAppointmentStatus);

module.exports = router;
