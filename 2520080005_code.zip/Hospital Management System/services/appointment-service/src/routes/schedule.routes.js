const express = require('express');
const router = express.Router();
const scheduleController = require('../controllers/schedule.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

// Public slots lookup for booking
router.get('/:id/slots', scheduleController.getDoctorSlots);
router.get('/:id/schedule', scheduleController.getDoctorSchedule);

// Protected schedule update
router.put('/:id/schedule', verifyToken, requireRoles('doctor', 'admin'), scheduleController.updateSchedule);

module.exports = router;
