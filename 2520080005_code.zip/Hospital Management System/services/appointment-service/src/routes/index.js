const express = require('express');
const router = express.Router();

const appointmentRoutes = require('./appointment.routes');
const scheduleRoutes = require('./schedule.routes');
const internalRoutes = require('./internal.routes');

router.use('/appointments', appointmentRoutes);
router.use('/doctors', scheduleRoutes);
router.use('/internal', internalRoutes);

module.exports = router;
