const express = require('express');
const router = express.Router();
const internalController = require('../controllers/internal.controller');

// Inter-service endpoints
router.get('/appointments/:id', internalController.getAppointmentById);
router.get('/stats', internalController.getStatsInternal);

module.exports = router;
