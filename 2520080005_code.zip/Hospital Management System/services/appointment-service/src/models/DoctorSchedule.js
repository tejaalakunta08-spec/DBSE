const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const DoctorSchedule = sequelize.define('DoctorSchedule', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  dayOfWeek: {
    type: DataTypes.ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
    allowNull: false
  },
  startTime: {
    type: DataTypes.TIME,
    allowNull: false
  },
  endTime: {
    type: DataTypes.TIME,
    allowNull: false
  },
  slotDurationMinutes: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 20
  },
  maxPatients: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 25
  },
  isAvailable: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
}, {
  tableName: 'doctor_schedules',
  indexes: [
    { fields: ['doctorId', 'dayOfWeek'] }
  ]
});

module.exports = DoctorSchedule;
