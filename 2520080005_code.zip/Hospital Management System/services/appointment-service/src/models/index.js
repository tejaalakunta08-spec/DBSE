const { sequelize } = require('../config/db.config');
const Appointment = require('./Appointment');
const DoctorSchedule = require('./DoctorSchedule');

module.exports = {
  sequelize,
  Appointment,
  DoctorSchedule
};
