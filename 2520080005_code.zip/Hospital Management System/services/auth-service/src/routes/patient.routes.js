const express = require('express');
const router = express.Router();
const patientController = require('../controllers/patient.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

router.use(verifyToken);

router.get('/', requireRoles('admin', 'doctor'), patientController.getAllPatients);
router.get('/:id', patientController.getPatientById);
router.put('/:id', patientController.updatePatientProfile);

module.exports = router;
