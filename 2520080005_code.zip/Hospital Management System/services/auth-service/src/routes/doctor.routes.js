const express = require('express');
const router = express.Router();
const doctorController = require('../controllers/doctor.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

router.get('/', doctorController.getAllDoctors);
router.get('/departments', doctorController.getDepartments);
router.get('/:id', doctorController.getDoctorById);
router.put('/:id/availability', verifyToken, requireRoles('doctor', 'admin'), doctorController.updateDoctorAvailability);

module.exports = router;
