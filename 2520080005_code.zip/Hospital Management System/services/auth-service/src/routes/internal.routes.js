const express = require('express');
const router = express.Router();
const internalController = require('../controllers/internal.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

// Unprotected inter-service endpoints for internal microservice communication
router.get('/patients/:id', internalController.getPatientInternal);
router.get('/doctors/:id', internalController.getDoctorInternal);
router.get('/users/:id', internalController.getUserInternal);
router.get('/stats', internalController.getStatsInternal);

// Admin-level endpoints routed through Gateway
router.get('/audit-logs', verifyToken, requireRoles('admin'), internalController.getAuditLogs);
router.put('/users/:userId/status', verifyToken, requireRoles('admin'), internalController.updateUserStatus);

module.exports = router;
