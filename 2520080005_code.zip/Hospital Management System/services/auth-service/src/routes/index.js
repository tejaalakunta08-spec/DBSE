const express = require('express');
const router = express.Router();

const authRoutes = require('./auth.routes');
const doctorRoutes = require('./doctor.routes');
const patientRoutes = require('./patient.routes');
const internalRoutes = require('./internal.routes');

router.use('/auth', authRoutes);
router.use('/doctors', doctorRoutes);
router.use('/patients', patientRoutes);
router.use('/internal', internalRoutes);

module.exports = router;
