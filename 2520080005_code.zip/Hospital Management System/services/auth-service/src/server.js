require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { sequelize, ensureDatabaseExists } = require('./config/db.config');
const routes = require('./routes');
const { errorHandler, notFoundHandler } = require('./middleware/error.middleware');

const app = express();
const PORT = process.env.PORT || 5001;

app.use(cors({ origin: '*', credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('dev'));
}

// Health check
app.get('/health', (req, res) => {
  res.json({
    service: 'Auth & User Service',
    status: 'UP',
    port: PORT,
    database: 'hospital_auth_db',
    timestamp: new Date()
  });
});

// Mount Routes (under /api and direct)
app.use('/api', routes);
app.use('/', routes);

app.use(notFoundHandler);
app.use(errorHandler);

async function startServer() {
  try {
    await ensureDatabaseExists();
    await sequelize.authenticate();
    console.log('[Auth Service] Connected to MySQL database: hospital_auth_db');
    await sequelize.sync({ alter: false });
    console.log('[Auth Service] Models synchronized.');

    app.listen(PORT, '0.0.0.0', () => {
      console.log(`🔐 [Auth Service] Running on http://127.0.0.1:${PORT}`);
    });
  } catch (error) {
    console.error('❌ [Auth Service] Failed to start:', error.message);
  }
}

if (require.main === module) {
  startServer();
}

module.exports = app;
