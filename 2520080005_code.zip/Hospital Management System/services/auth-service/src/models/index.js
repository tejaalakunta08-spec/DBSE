const { sequelize } = require('../config/db.config');
const User = require('./User');
const Patient = require('./Patient');
const Doctor = require('./Doctor');
const AuditLog = require('./AuditLog');

// 1:1 Associations within Auth & User Service database
User.hasOne(Patient, { foreignKey: 'userId', as: 'patientProfile', onDelete: 'CASCADE' });
Patient.belongsTo(User, { foreignKey: 'userId', as: 'user' });

User.hasOne(Doctor, { foreignKey: 'userId', as: 'doctorProfile', onDelete: 'CASCADE' });
Doctor.belongsTo(User, { foreignKey: 'userId', as: 'user' });

module.exports = {
  sequelize,
  User,
  Patient,
  Doctor,
  AuditLog
};
