const { User, Patient, Doctor, AuditLog } = require('../models');

// Inter-Service: Get Patient Details by Patient Profile ID
exports.getPatientInternal = async (req, res, next) => {
  try {
    const { id } = req.params;
    const patient = await Patient.findByPk(id, {
      include: [{ model: User, as: 'user', attributes: ['id', 'name', 'email', 'phone'] }]
    });

    if (!patient) {
      return res.status(404).json({ success: false, message: 'Patient not found.' });
    }

    return res.json({
      success: true,
      data: {
        id: patient.id,
        userId: patient.userId,
        name: patient.user?.name,
        email: patient.user?.email,
        phone: patient.user?.phone,
        patientCode: patient.patientCode,
        insuranceProvider: patient.insuranceProvider,
        insurancePolicyNumber: patient.insurancePolicyNumber,
        bloodGroup: patient.bloodGroup
      }
    });
  } catch (error) {
    next(error);
  }
};

// Inter-Service: Get Doctor Details by Doctor Profile ID
exports.getDoctorInternal = async (req, res, next) => {
  try {
    const { id } = req.params;
    const doctor = await Doctor.findByPk(id, {
      include: [{ model: User, as: 'user', attributes: ['id', 'name', 'email', 'phone'] }]
    });

    if (!doctor) {
      return res.status(404).json({ success: false, message: 'Doctor not found.' });
    }

    return res.json({
      success: true,
      data: {
        id: doctor.id,
        userId: doctor.userId,
        name: doctor.user?.name,
        email: doctor.user?.email,
        phone: doctor.user?.phone,
        department: doctor.department,
        specialization: doctor.specialization,
        consultationFee: doctor.consultationFee,
        roomNumber: doctor.roomNumber,
        isAvailableToday: doctor.isAvailableToday
      }
    });
  } catch (error) {
    next(error);
  }
};

// Inter-Service: Get User Details by User ID
exports.getUserInternal = async (req, res, next) => {
  try {
    const { id } = req.params;
    const user = await User.findByPk(id, {
      attributes: ['id', 'name', 'email', 'phone', 'role', 'status'],
      include: [
        { model: Patient, as: 'patientProfile' },
        { model: Doctor, as: 'doctorProfile' }
      ]
    });

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    return res.json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// Inter-Service: Counts for Dashboard Stats
exports.getStatsInternal = async (req, res, next) => {
  try {
    const [totalPatients, totalDoctors] = await Promise.all([
      Patient.count(),
      Doctor.count()
    ]);

    return res.json({
      success: true,
      data: {
        totalPatients,
        totalDoctors
      }
    });
  } catch (error) {
    next(error);
  }
};

// Admin: Get Audit Logs
exports.getAuditLogs = async (req, res, next) => {
  try {
    const { limit = 50, action } = req.query;
    const where = {};
    if (action) where.action = action;

    const logs = await AuditLog.findAll({
      where,
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit, 10)
    });

    return res.json({
      success: true,
      data: logs
    });
  } catch (error) {
    next(error);
  }
};

// Admin: Update User Status (Activate/Deactivate)
exports.updateUserStatus = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { status } = req.body;

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    await user.update({ status });

    await AuditLog.create({
      userId: req.user?.id || null,
      userName: req.user?.name || 'Admin',
      userRole: req.user?.role || 'admin',
      action: 'USER_STATUS_CHANGE',
      entity: 'User',
      entityId: String(user.id),
      details: `User status changed to ${status} for ${user.name}`,
      ipAddress: req.ip
    });

    return res.json({
      success: true,
      message: `User status updated to ${status}.`,
      data: user
    });
  } catch (error) {
    next(error);
  }
};
