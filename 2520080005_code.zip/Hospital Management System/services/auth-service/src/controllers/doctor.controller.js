const { Doctor, User, sequelize } = require('../models');

// 1. Get All Active Doctors
exports.getAllDoctors = async (req, res, next) => {
  try {
    const { department, search } = req.query;
    const where = {};
    if (department) where.department = department;

    const doctors = await Doctor.findAll({
      where,
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'status', 'avatar']
        }
      ],
      order: [['department', 'ASC'], ['id', 'ASC']]
    });

    let filtered = doctors;
    if (search) {
      const q = search.toLowerCase();
      filtered = doctors.filter(d =>
        d.user?.name.toLowerCase().includes(q) ||
        d.specialization.toLowerCase().includes(q) ||
        d.department.toLowerCase().includes(q)
      );
    }

    return res.json({
      success: true,
      data: filtered
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Distinct Hospital Departments
exports.getDepartments = async (req, res, next) => {
  try {
    const departments = await Doctor.findAll({
      attributes: [[sequelize.fn('DISTINCT', sequelize.col('department')), 'department']]
    });

    return res.json({
      success: true,
      data: departments.map(d => d.department).filter(Boolean)
    });
  } catch (error) {
    next(error);
  }
};

// 3. Get Doctor Profile by ID
exports.getDoctorById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const doctor = await Doctor.findByPk(id, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'status', 'avatar']
        }
      ]
    });

    if (!doctor) {
      return res.status(404).json({ success: false, message: 'Doctor not found.' });
    }

    return res.json({
      success: true,
      data: doctor
    });
  } catch (error) {
    next(error);
  }
};

// 4. Update Doctor Availability
exports.updateDoctorAvailability = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { isAvailableToday } = req.body;

    const doctor = await Doctor.findByPk(id);
    if (!doctor) {
      return res.status(404).json({ success: false, message: 'Doctor not found.' });
    }

    await doctor.update({ isAvailableToday });

    return res.json({
      success: true,
      message: 'Doctor availability updated.',
      data: doctor
    });
  } catch (error) {
    next(error);
  }
};
