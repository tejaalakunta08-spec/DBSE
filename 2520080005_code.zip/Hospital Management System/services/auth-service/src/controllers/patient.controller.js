const { Patient, User, AuditLog } = require('../models');

// 1. Get All Patients (Admin & Doctors)
exports.getAllPatients = async (req, res, next) => {
  try {
    const { search } = req.query;

    const patients = await Patient.findAll({
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'status', 'avatar', 'createdAt']
        }
      ],
      order: [['id', 'DESC']]
    });

    let filtered = patients;
    if (search) {
      const q = search.toLowerCase();
      filtered = patients.filter(p =>
        p.user?.name.toLowerCase().includes(q) ||
        p.patientCode.toLowerCase().includes(q) ||
        p.user?.phone?.includes(q) ||
        p.user?.email.toLowerCase().includes(q)
      );
    }

    return res.json({
      success: true,
      data: filtered
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Patient by ID
exports.getPatientById = async (req, res, next) => {
  try {
    const { id } = req.params;

    const patient = await Patient.findByPk(id, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'status', 'avatar', 'createdAt']
        }
      ]
    });

    if (!patient) {
      return res.status(404).json({ success: false, message: 'Patient profile not found.' });
    }

    // Role check: Patient can only view their own profile
    if (req.user.role === 'patient' && req.user.patientProfile?.id !== patient.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized: cannot view other patient records.' });
    }

    return res.json({
      success: true,
      data: patient
    });
  } catch (error) {
    next(error);
  }
};

// 3. Update Patient Profile
exports.updatePatientProfile = async (req, res, next) => {
  try {
    const { id } = req.params;

    const patient = await Patient.findByPk(id, {
      include: [{ model: User, as: 'user' }]
    });

    if (!patient) {
      return res.status(404).json({ success: false, message: 'Patient profile not found.' });
    }

    if (req.user.role === 'patient' && req.user.patientProfile?.id !== patient.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized: cannot update other patient records.' });
    }

    const {
      name,
      phone,
      dob,
      gender,
      bloodGroup,
      address,
      emergencyContactName,
      emergencyContactPhone,
      allergies,
      chronicConditions,
      insuranceProvider,
      insurancePolicyNumber
    } = req.body;

    if (name || phone) {
      await patient.user.update({
        ...(name && { name }),
        ...(phone && { phone })
      });
    }

    await patient.update({
      dob,
      gender,
      bloodGroup,
      address,
      emergencyContactName,
      emergencyContactPhone,
      allergies,
      chronicConditions,
      insuranceProvider,
      insurancePolicyNumber
    });

    await AuditLog.create({
      userId: req.user.id,
      userName: req.user.name,
      userRole: req.user.role,
      action: 'PATIENT_PROFILE_UPDATE',
      entity: 'Patient',
      entityId: String(patient.id),
      details: `Profile updated for patient ${patient.user.name}`,
      ipAddress: req.ip
    });

    return res.json({
      success: true,
      message: 'Patient profile updated successfully.',
      data: patient
    });
  } catch (error) {
    next(error);
  }
};
