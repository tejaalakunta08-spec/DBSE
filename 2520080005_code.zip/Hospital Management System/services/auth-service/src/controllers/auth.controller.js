const jwt = require('jsonwebtoken');
const { User, Patient, Doctor, AuditLog } = require('../models');
const { secret, expiresIn } = require('../config/jwt.config');

function generateToken(user) {
  const pProfile = user.patientProfile || (user.Patient ? user.Patient : null);
  const dProfile = user.doctorProfile || (user.Doctor ? user.Doctor : null);

  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
      patientProfile: pProfile ? { id: pProfile.id, patientCode: pProfile.patientCode } : null,
      doctorProfile: dProfile ? { id: dProfile.id, doctorCode: dProfile.doctorCode } : null
    },
    secret,
    { expiresIn }
  );
}

// 1. Patient Registration
exports.register = async (req, res, next) => {
  try {
    const {
      name,
      email,
      password,
      phone,
      dob,
      gender,
      bloodGroup,
      address,
      emergencyContactName,
      emergencyContactPhone,
      allergies,
      chronicConditions,
      insuranceProvider,
      insurancePolicyNumber
    } = req.body;

    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'Email already registered.' });
    }

    const user = await User.create({
      name,
      email,
      password,
      phone,
      role: 'patient',
      status: 'active'
    });

    const patientCode = `PAT-${Math.floor(100000 + Math.random() * 900000)}`;
    const patientProfile = await Patient.create({
      userId: user.id,
      patientCode,
      dob,
      gender,
      bloodGroup,
      address,
      emergencyContactName,
      emergencyContactPhone,
      allergies,
      chronicConditions,
      insuranceProvider,
      insurancePolicyNumber
    });

    await AuditLog.create({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'USER_REGISTER',
      entity: 'User',
      entityId: String(user.id),
      details: `New patient registered: ${user.name} (${user.email})`,
      ipAddress: req.ip
    });

    user.patientProfile = patientProfile;
    const token = generateToken(user);

    return res.status(201).json({
      success: true,
      message: 'Registration successful!',
      data: {
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          patientProfile,
          doctorProfile: null
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

// 2. User Login
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }

    const user = await User.findOne({
      where: { email },
      include: [
        { model: Patient, as: 'patientProfile' },
        { model: Doctor, as: 'doctorProfile' }
      ]
    });

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    if (user.status !== 'active') {
      return res.status(403).json({ success: false, message: `Account is ${user.status}. Please contact hospital admin.` });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const token = generateToken(user);

    await AuditLog.create({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'USER_LOGIN',
      entity: 'User',
      entityId: String(user.id),
      details: `User login successful: ${user.name} (${user.role})`,
      ipAddress: req.ip
    });

    return res.json({
      success: true,
      message: `Welcome back, ${user.name}!`,
      data: {
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          patientProfile: user.patientProfile,
          doctorProfile: user.doctorProfile
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

// 3. Current User Profile
exports.getMe = async (req, res) => {
  const profile = {
    id: req.user.id,
    name: req.user.name,
    email: req.user.email,
    role: req.user.role,
    phone: req.user.phone,
    status: req.user.status,
    patientProfile: req.user.patientProfile,
    doctorProfile: req.user.doctorProfile
  };

  return res.json({
    success: true,
    data: profile
  });
};

// 4. Register Doctor (Admin Only)
exports.registerDoctor = async (req, res, next) => {
  try {
    const {
      name,
      email,
      password,
      phone,
      department,
      specialization,
      qualification,
      experienceYears,
      consultationFee,
      roomNumber,
      bio
    } = req.body;

    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'Doctor email already registered.' });
    }

    const cleanName = name.replace(/^(Dr\.\s*|Dr\s+)+/i, '').trim();

    const user = await User.create({
      name: cleanName,
      email,
      password: password || 'Doctor@123',
      phone,
      role: 'doctor',
      status: 'active'
    });

    const deptPrefix = department ? department.substring(0, 3).toUpperCase() : 'DOC';
    const doctorCode = `DOC-${deptPrefix}-${Math.floor(100 + Math.random() * 900)}`;

    const doctorProfile = await Doctor.create({
      userId: user.id,
      doctorCode,
      department,
      specialization,
      qualification,
      experienceYears: experienceYears || 1,
      consultationFee: consultationFee || 500.00,
      roomNumber: roomNumber || 'OPD-101',
      bio: bio || '',
      isAvailableToday: true
    });

    await AuditLog.create({
      userId: req.user.id,
      userName: req.user.name,
      userRole: req.user.role,
      action: 'DOCTOR_REGISTER',
      entity: 'Doctor',
      entityId: String(doctorProfile.id),
      details: `Admin created doctor account for Dr. ${cleanName} (${department})`,
      ipAddress: req.ip
    });

    return res.status(201).json({
      success: true,
      message: `Doctor Dr. ${cleanName} created successfully!`,
      data: {
        user,
        doctorProfile
      }
    });
  } catch (error) {
    next(error);
  }
};
