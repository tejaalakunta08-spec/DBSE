const jwt = require('jsonwebtoken');
const { secret } = require('../config/jwt.config');
const { User, Patient, Doctor } = require('../models');

exports.verifyToken = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'Access denied. Bearer token missing.' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, secret);

    const user = await User.findByPk(decoded.id, {
      include: [
        { model: Patient, as: 'patientProfile' },
        { model: Doctor, as: 'doctorProfile' }
      ]
    });

    if (!user || user.status !== 'active') {
      return res.status(401).json({ success: false, message: 'Invalid token or inactive account.' });
    }

    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ success: false, message: 'Token verification failed: ' + error.message });
  }
};

exports.requireRoles = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Forbidden: requires one of the following roles: [${roles.join(', ')}]`
      });
    }
    next();
  };
};
