exports.notFoundHandler = (req, res, next) => {
  res.status(404).json({
    success: false,
    message: `API Route Not Found on Auth Service: [${req.method}] ${req.originalUrl}`
  });
};

exports.errorHandler = (err, req, res, next) => {
  console.error('[Auth Service Error]:', err);
  const status = err.status || 500;
  res.status(status).json({
    success: false,
    message: err.message || 'Internal Server Error on Auth Service',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
};
