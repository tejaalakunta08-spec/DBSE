const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const LabTest = sequelize.define('LabTest', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  testCode: {
    type: DataTypes.STRING(30),
    allowNull: false,
    unique: true
  },
  name: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  category: {
    type: DataTypes.STRING(80),
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 300.00
  },
  turnaroundTimeHours: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 24
  },
  sampleRequired: {
    type: DataTypes.STRING(100),
    allowNull: false,
    defaultValue: 'Blood'
  },
  normalRange: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  units: {
    type: DataTypes.STRING(30),
    allowNull: true
  }
}, {
  tableName: 'lab_tests'
});

module.exports = LabTest;
