const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const LabReport = sequelize.define('LabReport', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  reportNumber: {
    type: DataTypes.STRING(40),
    allowNull: false,
    unique: true
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  labTestId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  appointmentId: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  status: {
    type: DataTypes.ENUM('ordered', 'sample_collected', 'in_progress', 'completed', 'cancelled'),
    allowNull: false,
    defaultValue: 'ordered'
  },
  sampleCollectedAt: {
    type: DataTypes.DATE,
    allowNull: true
  },
  resultValue: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  isAbnormal: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  remarks: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  technicianNotes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  doctorNotes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  completedAt: {
    type: DataTypes.DATE,
    allowNull: true
  },
  prescribedDate: {
    type: DataTypes.DATEONLY,
    allowNull: false,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'lab_reports',
  indexes: [
    { fields: ['patientId'] },
    { fields: ['doctorId'] },
    { fields: ['status'] }
  ]
});

module.exports = LabReport;
