const { sequelize } = require('../config/db.config');
const LabTest = require('./LabTest');
const LabReport = require('./LabReport');

LabTest.hasMany(LabReport, { foreignKey: 'labTestId', as: 'reports', onDelete: 'CASCADE' });
LabReport.belongsTo(LabTest, { foreignKey: 'labTestId', as: 'test' });

module.exports = {
  sequelize,
  LabTest,
  LabReport
};
