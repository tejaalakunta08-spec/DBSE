const { LabReport } = require('../models');
const { Op } = require('sequelize');

// Inter-Service: Get Pending Lab Tests Count
exports.getStatsInternal = async (req, res, next) => {
  try {
    const pendingLabTestsCount = await LabReport.count({
      where: {
        status: { [Op.in]: ['ordered', 'sample_collected', 'in_progress'] }
      }
    });

    return res.json({
      success: true,
      data: { pendingLabTestsCount }
    });
  } catch (error) {
    next(error);
  }
};
