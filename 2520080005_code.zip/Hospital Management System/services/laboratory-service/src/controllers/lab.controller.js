const { LabTest, LabReport } = require('../models');
const authClient = require('../services/authClient.service');
const billingClient = require('../services/billingClient.service');
const notificationClient = require('../services/notificationClient.service');

// 1. Get Diagnostic Tests Catalog
exports.getLabTests = async (req, res, next) => {
  try {
    const { category } = req.query;
    const where = {};
    if (category) where.category = category;

    const tests = await LabTest.findAll({
      where,
      order: [['category', 'ASC'], ['name', 'ASC']]
    });

    return res.json({
      success: true,
      data: tests
    });
  } catch (error) {
    next(error);
  }
};

// 2. Create Diagnostic Test (Admin Only)
exports.createLabTest = async (req, res, next) => {
  try {
    const {
      name,
      category,
      description,
      price,
      turnaroundTimeHours,
      sampleRequired,
      normalRange,
      units
    } = req.body;

    const testCode = `TEST-${category ? category.substring(0, 3).toUpperCase() : 'LAB'}-${Math.floor(100 + Math.random() * 900)}`;

    const test = await LabTest.create({
      testCode,
      name,
      category: category || 'Biochemistry',
      description,
      price: price || 350.00,
      turnaroundTimeHours: turnaroundTimeHours || 24,
      sampleRequired: sampleRequired || 'Blood',
      normalRange,
      units
    });

    return res.status(201).json({
      success: true,
      message: `Diagnostic test ${test.name} added to hospital catalog.`,
      data: test
    });
  } catch (error) {
    next(error);
  }
};

// 3. Order Lab Test (Doctor / Admin)
exports.orderTest = async (req, res, next) => {
  try {
    const { labTestId, patientId, appointmentId, doctorNotes } = req.body;
    let doctorId = req.body.doctorId;

    if (req.user.role === 'doctor' && req.user.doctorProfile?.id) {
      doctorId = req.user.doctorProfile.id;
    }

    const test = await LabTest.findByPk(labTestId);
    if (!test) {
      return res.status(404).json({ success: false, message: 'Lab test not found.' });
    }

    const today = new Date().toISOString().split('T')[0];
    const reportNumber = `LAB-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;

    const report = await LabReport.create({
      reportNumber,
      labTestId,
      patientId: parseInt(patientId, 10),
      doctorId: doctorId ? parseInt(doctorId, 10) : 1,
      appointmentId: appointmentId ? parseInt(appointmentId, 10) : null,
      status: 'ordered',
      doctorNotes,
      prescribedDate: today
    });

    // Inter-Service 1: Add lab test charge to Billing Service
    await billingClient.createLabBill({
      patientId: parseInt(patientId, 10),
      appointmentId: appointmentId ? parseInt(appointmentId, 10) : null,
      consultationFee: 0.00,
      medicineCharges: 0.00,
      labCharges: parseFloat(test.price),
      billDate: today
    });

    // Inter-Service 2: Send SMS notification to patient
    const patientData = await authClient.getPatientById(patientId);
    if (patientData?.phone) {
      await notificationClient.sendNotification({
        userId: patientData.userId,
        phone: patientData.phone,
        title: 'Diagnostic Test Prescribed',
        message: `Dr. prescribed [${test.name}]. Please visit Laboratory collection counter with Report #${reportNumber}.`,
        channel: 'both',
        eventType: 'lab_ordered'
      });
    }

    return res.status(201).json({
      success: true,
      message: `Diagnostic test ${test.name} ordered. Report #${reportNumber} generated.`,
      data: report
    });
  } catch (error) {
    next(error);
  }
};

// 4. Get Lab Reports (Patient sees own, Doctor/Admin sees hospital)
exports.getLabReports = async (req, res, next) => {
  try {
    const where = {};
    if (req.user.role === 'patient') {
      const patientId = req.user.patientProfile?.id;
      if (patientId) where.patientId = patientId;
    } else if (req.user.role === 'doctor') {
      const doctorId = req.user.doctorProfile?.id;
      if (doctorId) where.doctorId = doctorId;
    }

    const reports = await LabReport.findAll({
      where,
      include: [{ model: LabTest, as: 'test' }],
      order: [['prescribedDate', 'DESC'], ['id', 'DESC']]
    });

    // Enrich with Patient and Doctor info from Auth Service
    const enriched = await Promise.all(
      reports.map(async (rep) => {
        const [patient, doctor] = await Promise.all([
          authClient.getPatientById(rep.patientId),
          authClient.getDoctorById(rep.doctorId)
        ]);

        return {
          ...rep.toJSON(),
          patient: patient ? { id: patient.id, patientCode: patient.patientCode, user: { name: patient.name, phone: patient.phone } } : null,
          doctor: doctor ? { id: doctor.id, department: doctor.department, user: { name: doctor.name } } : null
        };
      })
    );

    return res.json({
      success: true,
      data: enriched
    });
  } catch (error) {
    next(error);
  }
};

// 5. Update Lab Report Results (Lab Tech / Admin)
exports.updateReport = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, resultValue, isAbnormal, remarks } = req.body;

    const report = await LabReport.findByPk(id, {
      include: [{ model: LabTest, as: 'test' }]
    });

    if (!report) {
      return res.status(404).json({ success: false, message: 'Lab report not found.' });
    }

    const updates = {
      status: status || report.status,
      resultValue: resultValue !== undefined ? resultValue : report.resultValue,
      isAbnormal: isAbnormal !== undefined ? isAbnormal : report.isAbnormal,
      remarks: remarks !== undefined ? remarks : report.remarks
    };

    if (status === 'completed') {
      updates.completedAt = new Date();
    }

    await report.update(updates);

    // Inter-Service Notification: Send alert if completed
    if (status === 'completed') {
      const patientData = await authClient.getPatientById(report.patientId);
      if (patientData?.phone) {
        await notificationClient.sendNotification({
          userId: patientData.userId,
          phone: patientData.phone,
          title: 'Lab Report Ready',
          message: `Your diagnostic report for ${report.test?.name} (#${report.reportNumber}) is now available in your portal.`,
          channel: 'both',
          eventType: 'lab_completed'
        });
      }
    }

    return res.json({
      success: true,
      message: 'Lab report updated successfully.',
      data: report
    });
  } catch (error) {
    next(error);
  }
};
