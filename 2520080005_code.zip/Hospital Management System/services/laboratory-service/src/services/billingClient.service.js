const { billingServiceUrl } = require('../config/services.config');

exports.createLabBill = async (billData) => {
  try {
    const res = await fetch(`${billingServiceUrl}/internal/billing/create`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(billData)
    });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data || null;
  } catch (error) {
    console.warn('[Lab -> Billing Service] Error creating lab bill:', error.message);
    return null;
  }
};
