const express = require('express');
const router = express.Router();
const labController = require('../controllers/lab.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

// Public/Doctor/Patient catalog
router.get('/tests', labController.getLabTests);

// Protected routes
router.use(verifyToken);
router.post('/tests', requireRoles('admin'), labController.createLabTest);
router.post('/order', requireRoles('doctor', 'admin'), labController.orderTest);
router.get('/reports', labController.getLabReports);
router.put('/reports/:id', requireRoles('doctor', 'admin'), labController.updateReport);

module.exports = router;
