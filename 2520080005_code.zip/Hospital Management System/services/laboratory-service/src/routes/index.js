const express = require('express');
const router = express.Router();

const labRoutes = require('./lab.routes');
const internalRoutes = require('./internal.routes');

router.use('/lab', labRoutes);
router.use('/internal', internalRoutes);

module.exports = router;
