const express = require('express');
const router = express.Router();
const internalController = require('../controllers/internal.controller');

router.post('/send', internalController.sendNotificationInternal);
router.post('/notifications/send', internalController.sendNotificationInternal);

module.exports = router;
