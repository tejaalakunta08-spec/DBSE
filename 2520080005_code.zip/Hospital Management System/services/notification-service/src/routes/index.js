const express = require('express');
const router = express.Router();

const notificationRoutes = require('./notification.routes');
const internalRoutes = require('./internal.routes');

router.use('/notifications', notificationRoutes);
router.use('/internal', internalRoutes);

module.exports = router;
