const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notification.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

router.use(verifyToken);

router.get('/my', notificationController.getMyNotifications);
router.put('/:id/read', notificationController.markAsRead);
router.put('/read-all', notificationController.markAllAsRead);
router.post('/test-sms', requireRoles('admin'), notificationController.testTwilioSms);

module.exports = router;
