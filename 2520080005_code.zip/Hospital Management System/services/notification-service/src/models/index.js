const { sequelize } = require('../config/db.config');
const Notification = require('./Notification');

module.exports = {
  sequelize,
  Notification
};
