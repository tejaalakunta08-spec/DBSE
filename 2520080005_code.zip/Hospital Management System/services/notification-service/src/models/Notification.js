const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const Notification = sequelize.define('Notification', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  phone: {
    type: DataTypes.STRING(20),
    allowNull: true
  },
  email: {
    type: DataTypes.STRING(120),
    allowNull: true
  },
  title: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  message: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  channel: {
    type: DataTypes.ENUM('sms', 'in_app', 'both'),
    allowNull: false,
    defaultValue: 'both'
  },
  eventType: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  isRead: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  deliveryStatus: {
    type: DataTypes.STRING(30),
    defaultValue: 'pending'
  },
  twilioSid: {
    type: DataTypes.STRING(60),
    allowNull: true
  }
}, {
  tableName: 'notifications',
  indexes: [
    { fields: ['userId', 'isRead'] }
  ]
});

module.exports = Notification;
