require('dotenv').config();

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const fromPhone = process.env.TWILIO_PHONE_NUMBER;

const isConfigured = Boolean(
  accountSid &&
  accountSid.startsWith('AC') &&
  authToken &&
  fromPhone
);

let client = null;
if (isConfigured) {
  try {
    const twilio = require('twilio');
    client = twilio(accountSid, authToken);
    console.log('[Twilio Notification Service] Initialized with live Twilio credentials.');
  } catch (error) {
    console.warn('[Twilio Notification Service] Failed to initialize live client:', error.message);
  }
} else {
  console.log('[Twilio Notification Service] Running in mock/simulation mode (no credentials provided). SMS alerts will be simulated and saved to MySQL.');
}

async function sendSms(to, message) {
  if (isConfigured && client) {
    try {
      const result = await client.messages.create({
        body: message,
        from: fromPhone,
        to
      });
      return {
        success: true,
        mode: 'live',
        sid: result.sid,
        status: result.status
      };
    } catch (error) {
      console.error('[Twilio Error] Live SMS delivery failed:', error.message);
      return {
        success: false,
        mode: 'live_failed',
        error: error.message
      };
    }
  }

  // Graceful Mock Fallback Simulation
  const mockSid = `MOCK_SMS_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;
  console.log(`\n================== [MOCK SMS SIMULATION] ==================`);
  console.log(`📱 TO: ${to}`);
  console.log(`💬 MESSAGE: ${message}`);
  console.log(`🆔 MOCK SID: ${mockSid}`);
  console.log(`============================================================\n`);

  return {
    success: true,
    mode: 'simulated',
    sid: mockSid,
    status: 'delivered'
  };
}

module.exports = {
  sendSms,
  isConfigured
};
