const { Notification } = require('../models');
const { sendSms, isConfigured } = require('../config/twilio.config');

// 1. Get Logged-In User Notifications
exports.getMyNotifications = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const notifications = await Notification.findAll({
      where: { userId },
      order: [['createdAt', 'DESC']],
      limit: 30
    });

    const unreadCount = await Notification.count({
      where: { userId, isRead: false }
    });

    return res.json({
      success: true,
      data: {
        notifications,
        unreadCount
      }
    });
  } catch (error) {
    next(error);
  }
};

// 2. Mark Single Notification as Read
exports.markAsRead = async (req, res, next) => {
  try {
    const { id } = req.params;
    const notification = await Notification.findOne({
      where: { id, userId: req.user.id }
    });

    if (!notification) {
      return res.status(404).json({ success: false, message: 'Notification not found.' });
    }

    await notification.update({ isRead: true });

    return res.json({
      success: true,
      message: 'Notification marked as read.',
      data: notification
    });
  } catch (error) {
    next(error);
  }
};

// 3. Mark All Notifications as Read
exports.markAllAsRead = async (req, res, next) => {
  try {
    await Notification.update(
      { isRead: true },
      { where: { userId: req.user.id, isRead: false } }
    );

    return res.json({
      success: true,
      message: 'All notifications marked as read.'
    });
  } catch (error) {
    next(error);
  }
};

// 4. Test Twilio SMS (Admin Settings)
exports.testTwilioSms = async (req, res, next) => {
  try {
    const { phoneNumber, message } = req.body;

    if (!phoneNumber) {
      return res.status(400).json({ success: false, message: 'Phone number is required.' });
    }

    const text = message || 'Hospital Management System: This is a test SMS alert from Twilio integration.';
    const smsResult = await sendSms(phoneNumber, text);

    const record = await Notification.create({
      userId: req.user.id,
      phone: phoneNumber,
      title: 'Admin Test SMS',
      message: text,
      channel: 'sms',
      eventType: 'admin_test_sms',
      deliveryStatus: smsResult.status || 'delivered',
      twilioSid: smsResult.sid || null
    });

    return res.json({
      success: smsResult.success,
      message: smsResult.mode === 'live' ? 'Live SMS sent via Twilio!' : 'Mock SMS simulated (saved in MySQL and console).',
      data: {
        smsResult,
        record,
        twilioConfigured: isConfigured
      }
    });
  } catch (error) {
    next(error);
  }
};
