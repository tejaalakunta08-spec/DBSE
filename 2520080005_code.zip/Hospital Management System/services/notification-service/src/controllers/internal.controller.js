const { Notification } = require('../models');
const { sendSms } = require('../config/twilio.config');

// Inter-Service: Send SMS and save Notification
exports.sendNotificationInternal = async (req, res, next) => {
  try {
    const { userId, phone, email, title, message, channel, eventType } = req.body;

    let smsResult = null;
    if (phone && (channel === 'sms' || channel === 'both')) {
      smsResult = await sendSms(phone, message);
    }

    const notification = await Notification.create({
      userId: userId ? parseInt(userId, 10) : null,
      phone,
      email,
      title: title || 'Hospital Alert',
      message,
      channel: channel || 'both',
      eventType: eventType || 'general',
      isRead: false,
      deliveryStatus: smsResult ? smsResult.status : 'delivered',
      twilioSid: smsResult ? smsResult.sid : null
    });

    return res.status(201).json({
      success: true,
      data: {
        notification,
        smsResult
      }
    });
  } catch (error) {
    next(error);
  }
};
