const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db.config');

const QueueToken = sequelize.define('QueueToken', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  tokenNumber: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  tokenCode: {
    type: DataTypes.STRING(30),
    allowNull: false
  },
  appointmentId: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  tokenDate: {
    type: DataTypes.DATEONLY,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  queueDate: {
    type: DataTypes.DATEONLY,
    allowNull: true
  },
  status: {
    type: DataTypes.ENUM('waiting', 'serving', 'completed', 'skipped', 'cancelled'),
    allowNull: false,
    defaultValue: 'waiting'
  },
  estimatedTime: {
    type: DataTypes.STRING(30),
    allowNull: true
  },
  calledAt: {
    type: DataTypes.DATE,
    allowNull: true
  },
  completedAt: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  tableName: 'queue_tokens',
  indexes: [
    { fields: ['tokenDate', 'doctorId'] },
    { fields: ['patientId'] },
    { fields: ['status'] }
  ],
  hooks: {
    beforeValidate: (token) => {
      if (!token.tokenDate && token.queueDate) {
        token.tokenDate = token.queueDate;
      }
      if (!token.queueDate && token.tokenDate) {
        token.queueDate = token.tokenDate;
      }
    }
  }
});

module.exports = QueueToken;
