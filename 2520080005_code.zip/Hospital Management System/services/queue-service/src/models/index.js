const { sequelize } = require('../config/db.config');
const QueueToken = require('./QueueToken');

module.exports = {
  sequelize,
  QueueToken
};
