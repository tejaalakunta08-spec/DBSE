exports.notFoundHandler = (req, res, next) => {
  res.status(404).json({
    success: false,
    message: `API Route Not Found on Queue Service: [${req.method}] ${req.originalUrl}`
  });
};

exports.errorHandler = (err, req, res, next) => {
  console.error('[Queue Service Error]:', err);
  const status = err.status || 500;
  res.status(status).json({
    success: false,
    message: err.message || 'Internal Server Error on Queue Service',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
};
