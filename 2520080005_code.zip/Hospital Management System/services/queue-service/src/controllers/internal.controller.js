const { QueueToken } = require('../models');
const { Op } = require('sequelize');

// Inter-Service: Generate Token (Called by Appointment Service)
exports.generateTokenInternal = async (req, res, next) => {
  try {
    const { appointmentId, patientId, doctorId, queueDate, estimatedTime } = req.body;
    const date = queueDate || new Date().toISOString().split('T')[0];

    // Determine the next sequential token number for this doctor on this day
    const lastToken = await QueueToken.findOne({
      where: { doctorId, queueDate: date },
      order: [['tokenNumber', 'DESC']]
    });

    const tokenNumber = lastToken ? lastToken.tokenNumber + 1 : 1;
    const tokenCode = `OPD-DOC-${doctorId}-${String(tokenNumber).padStart(3, '0')}`;

    const token = await QueueToken.create({
      tokenNumber,
      tokenCode,
      appointmentId: appointmentId || null,
      patientId: parseInt(patientId, 10),
      doctorId: parseInt(doctorId, 10),
      queueDate: date,
      status: 'waiting',
      estimatedTime: estimatedTime || '09:00 AM'
    });

    return res.status(201).json({
      success: true,
      data: token
    });
  } catch (error) {
    next(error);
  }
};

// Inter-Service: Get Active Queue Count for Today
exports.getStatsInternal = async (req, res, next) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const activeQueueCount = await QueueToken.count({
      where: {
        queueDate: today,
        status: { [Op.in]: ['waiting', 'serving'] }
      }
    });

    return res.json({
      success: true,
      data: { activeQueueCount }
    });
  } catch (error) {
    next(error);
  }
};
