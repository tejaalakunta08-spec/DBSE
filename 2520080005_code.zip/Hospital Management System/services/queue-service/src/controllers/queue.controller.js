const { QueueToken } = require('../models');
const { Op } = require('sequelize');
const authClient = require('../services/authClient.service');
const notificationClient = require('../services/notificationClient.service');

// 1. Get Live Queue Status for Logged-In Patient
exports.getMyQueueStatus = async (req, res, next) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    let patientId = req.user.patientProfile?.id || (req.headers['x-patient-id'] ? parseInt(req.headers['x-patient-id'], 10) : null);

    if (!patientId && req.user.id) {
      const userProfile = await authClient.getUserById(req.user.id);
      patientId = userProfile?.patientProfile?.id;
    }

    if (!patientId) {
      return res.status(400).json({ success: false, message: 'Patient profile not found.' });
    }

    const myToken = await QueueToken.findOne({
      where: {
        patientId,
        queueDate: today,
        status: { [Op.in]: ['waiting', 'serving', 'completed'] }
      },
      order: [['id', 'DESC']]
    });

    if (!myToken) {
      return res.json({
        success: true,
        message: 'No active token for today.',
        data: null
      });
    }

    // Find currently serving token for this doctor
    const currentlyServing = await QueueToken.findOne({
      where: {
        doctorId: myToken.doctorId,
        queueDate: today,
        status: 'serving'
      }
    });

    // Count how many waiting patients are ahead
    const patientsAhead = await QueueToken.count({
      where: {
        doctorId: myToken.doctorId,
        queueDate: today,
        status: 'waiting',
        tokenNumber: { [Op.lt]: myToken.tokenNumber }
      }
    });

    const doctor = await authClient.getDoctorById(myToken.doctorId);

    return res.json({
      success: true,
      data: {
        myToken: {
          ...myToken.toJSON(),
          doctor: doctor ? { id: doctor.id, department: doctor.department, roomNumber: doctor.roomNumber, user: { name: doctor.name } } : null
        },
        currentlyServingTokenNumber: currentlyServing ? currentlyServing.tokenNumber : null,
        patientsAhead,
        estimatedWaitMinutes: patientsAhead * 15
      }
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Live OPD Queue (Doctor Queue & Admin Hospital Queue)
exports.getLiveQueue = async (req, res, next) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const where = { queueDate: today };

    if (req.user.role === 'doctor') {
      const doctorId = req.user.doctorProfile?.id;
      if (doctorId) where.doctorId = doctorId;
    } else if (req.user.role === 'admin') {
      const { doctorId } = req.query;
      if (doctorId) where.doctorId = doctorId;
    }

    const tokens = await QueueToken.findAll({
      where,
      order: [['tokenNumber', 'ASC']]
    });

    // Enrich with Patient and Doctor details from Auth Service
    const enriched = await Promise.all(
      tokens.map(async (tok) => {
        const [patient, doctor] = await Promise.all([
          authClient.getPatientById(tok.patientId),
          authClient.getDoctorById(tok.doctorId)
        ]);

        return {
          ...tok.toJSON(),
          patient: patient ? { id: patient.id, patientCode: patient.patientCode, user: { name: patient.name, phone: patient.phone } } : null,
          doctor: doctor ? { id: doctor.id, department: doctor.department, roomNumber: doctor.roomNumber, user: { name: doctor.name } } : null
        };
      })
    );

    return res.json({
      success: true,
      data: enriched
    });
  } catch (error) {
    next(error);
  }
};

// 3. Call Next Patient (Doctor OPD Console)
exports.callNextPatient = async (req, res, next) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    let doctorId = req.body.doctorId;

    if (req.user.role === 'doctor' && req.user.doctorProfile?.id) {
      doctorId = req.user.doctorProfile.id;
    }

    if (!doctorId) {
      return res.status(400).json({ success: false, message: 'doctorId is required.' });
    }

    // Complete any token currently in 'serving' state for this doctor
    await QueueToken.update(
      { status: 'completed', completedAt: new Date() },
      { where: { doctorId, queueDate: today, status: 'serving' } }
    );

    // Find next waiting token
    const nextToken = await QueueToken.findOne({
      where: { doctorId, queueDate: today, status: 'waiting' },
      order: [['tokenNumber', 'ASC']]
    });

    if (!nextToken) {
      return res.json({
        success: true,
        message: 'No more waiting patients in queue for today.',
        data: null
      });
    }

    await nextToken.update({
      status: 'serving',
      calledAt: new Date()
    });

    // Inter-Service Notification: Send SMS alert to patient that their token is called!
    const [patient, doctor] = await Promise.all([
      authClient.getPatientById(nextToken.patientId),
      authClient.getDoctorById(doctorId)
    ]);

    if (patient?.phone) {
      const docName = doctor?.name ? `Dr. ${doctor.name}` : 'your doctor';
      await notificationClient.sendNotification({
        userId: patient.userId,
        phone: patient.phone,
        title: 'Now Calling Your OPD Token',
        message: `It is your turn! Token #${nextToken.tokenNumber} is now being served by ${docName} in Room ${doctor?.roomNumber || 'OPD-101'}.`,
        channel: 'both',
        eventType: 'queue_called'
      });
    }

    return res.json({
      success: true,
      message: `Token #${nextToken.tokenNumber} is now serving!`,
      data: {
        ...nextToken.toJSON(),
        patient: patient ? { id: patient.id, user: { name: patient.name, phone: patient.phone } } : null,
        doctor: doctor ? { id: doctor.id, department: doctor.department, roomNumber: doctor.roomNumber, user: { name: doctor.name } } : null
      }
    });
  } catch (error) {
    next(error);
  }
};

// 4. Update Token Status (Doctor / Admin)
exports.updateTokenStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const token = await QueueToken.findByPk(id);
    if (!token) {
      return res.status(404).json({ success: false, message: 'Queue token not found.' });
    }

    const updates = { status };
    if (status === 'serving') updates.calledAt = new Date();
    if (status === 'completed') updates.completedAt = new Date();

    await token.update(updates);

    return res.json({
      success: true,
      message: `Token status updated to ${status}.`,
      data: token
    });
  } catch (error) {
    next(error);
  }
};
