const { authServiceUrl } = require('../config/services.config');

const cache = new Map();

exports.getPatientById = async (patientId) => {
  const cacheKey = `patient_${patientId}`;
  if (cache.has(cacheKey)) return cache.get(cacheKey);

  try {
    const res = await fetch(`${authServiceUrl}/internal/patients/${patientId}`);
    if (!res.ok) return null;
    const json = await res.json();
    if (json.success) {
      cache.set(cacheKey, json.data);
      setTimeout(() => cache.delete(cacheKey), 30000);
      return json.data;
    }
    return null;
  } catch (error) {
    console.warn(`[Queue -> Auth Service] Error fetching patient ${patientId}:`, error.message);
    return null;
  }
};

exports.getDoctorById = async (doctorId) => {
  const cacheKey = `doctor_${doctorId}`;
  if (cache.has(cacheKey)) return cache.get(cacheKey);

  try {
    const res = await fetch(`${authServiceUrl}/internal/doctors/${doctorId}`);
    if (!res.ok) return null;
    const json = await res.json();
    if (json.success) {
      cache.set(cacheKey, json.data);
      setTimeout(() => cache.delete(cacheKey), 30000);
      return json.data;
    }
    return null;
  } catch (error) {
    console.warn(`[Queue -> Auth Service] Error fetching doctor ${doctorId}:`, error.message);
    return null;
  }
};

exports.getUserById = async (userId) => {
  const cacheKey = `user_${userId}`;
  if (cache.has(cacheKey)) return cache.get(cacheKey);

  try {
    const res = await fetch(`${authServiceUrl}/internal/users/${userId}`);
    if (!res.ok) return null;
    const json = await res.json();
    if (json.success) {
      cache.set(cacheKey, json.data);
      setTimeout(() => cache.delete(cacheKey), 30000);
      return json.data;
    }
    return null;
  } catch (error) {
    console.warn(`[Queue -> Auth Service] Error fetching user ${userId}:`, error.message);
    return null;
  }
};
