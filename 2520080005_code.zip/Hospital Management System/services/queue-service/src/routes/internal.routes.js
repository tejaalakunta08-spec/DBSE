const express = require('express');
const router = express.Router();
const internalController = require('../controllers/internal.controller');

router.post('/generate', internalController.generateTokenInternal);
router.post('/queue/generate', internalController.generateTokenInternal);
router.get('/stats', internalController.getStatsInternal);

module.exports = router;
