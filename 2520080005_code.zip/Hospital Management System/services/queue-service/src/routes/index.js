const express = require('express');
const router = express.Router();

const queueRoutes = require('./queue.routes');
const internalRoutes = require('./internal.routes');

router.use('/queue', queueRoutes);
router.use('/internal', internalRoutes);

module.exports = router;
