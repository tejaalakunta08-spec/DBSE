const express = require('express');
const router = express.Router();
const queueController = require('../controllers/queue.controller');
const { verifyToken, requireRoles } = require('../middleware/auth.middleware');

router.use(verifyToken);

router.get('/my-status', queueController.getMyQueueStatus);
router.get('/live', queueController.getLiveQueue);
router.post('/call-next', requireRoles('doctor', 'admin'), queueController.callNextPatient);
router.put('/:id/status', requireRoles('doctor', 'admin'), queueController.updateTokenStatus);

module.exports = router;
